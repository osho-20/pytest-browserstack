# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
from collections import deque
from bstack_utils.constants import *
class bstack1lllllllll_opy_:
    def __init__(self):
        self._1llllll11ll_opy_ = deque()
        self._1lllll1ll1l_opy_ = {}
        self._1lllll1ll11_opy_ = False
    def bstack1llllll1ll1_opy_(self, test_name, bstack1llllll1l1l_opy_):
        bstack1llllll111l_opy_ = self._1lllll1ll1l_opy_.get(test_name, {})
        return bstack1llllll111l_opy_.get(bstack1llllll1l1l_opy_, 0)
    def bstack1llllll11l1_opy_(self, test_name, bstack1llllll1l1l_opy_):
        bstack1llllll1111_opy_ = self.bstack1llllll1ll1_opy_(test_name, bstack1llllll1l1l_opy_)
        self.bstack1lllllll11l_opy_(test_name, bstack1llllll1l1l_opy_)
        return bstack1llllll1111_opy_
    def bstack1lllllll11l_opy_(self, test_name, bstack1llllll1l1l_opy_):
        if test_name not in self._1lllll1ll1l_opy_:
            self._1lllll1ll1l_opy_[test_name] = {}
        bstack1llllll111l_opy_ = self._1lllll1ll1l_opy_[test_name]
        bstack1llllll1111_opy_ = bstack1llllll111l_opy_.get(bstack1llllll1l1l_opy_, 0)
        bstack1llllll111l_opy_[bstack1llllll1l1l_opy_] = bstack1llllll1111_opy_ + 1
    def bstack1ll1l1ll11_opy_(self, bstack1lllll1llll_opy_, bstack1llllll1lll_opy_):
        bstack1llllll1l11_opy_ = self.bstack1llllll11l1_opy_(bstack1lllll1llll_opy_, bstack1llllll1lll_opy_)
        event_name = bstack1111ll11ll_opy_[bstack1llllll1lll_opy_]
        bstack1lllllll111_opy_ = bstack1l1111l_opy_ (u"ࠥࡿࢂ࠳ࡻࡾ࠯ࡾࢁࠧᎥ").format(bstack1lllll1llll_opy_, event_name, bstack1llllll1l11_opy_)
        self._1llllll11ll_opy_.append(bstack1lllllll111_opy_)
    def bstack11l1l11lll_opy_(self):
        return len(self._1llllll11ll_opy_) == 0
    def bstack1l1l1ll1ll_opy_(self):
        bstack1lllll1lll1_opy_ = self._1llllll11ll_opy_.popleft()
        return bstack1lllll1lll1_opy_
    def capturing(self):
        return self._1lllll1ll11_opy_
    def bstack11ll111111_opy_(self):
        self._1lllll1ll11_opy_ = True
    def bstack1l11lll111_opy_(self):
        self._1lllll1ll11_opy_ = False