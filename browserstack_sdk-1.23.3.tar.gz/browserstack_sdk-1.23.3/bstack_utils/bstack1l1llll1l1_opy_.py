# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
import json
class bstack1ll11l1l11l_opy_(object):
  bstack1l111ll1l1_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠫࢃ࠭ᚡ")), bstack1l1111l_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬᚢ"))
  bstack1ll11ll1111_opy_ = os.path.join(bstack1l111ll1l1_opy_, bstack1l1111l_opy_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡳ࠯࡬ࡶࡳࡳ࠭ᚣ"))
  bstack1ll11l1ll1l_opy_ = None
  perform_scan = None
  bstack111ll11ll_opy_ = None
  bstack11lll1ll11_opy_ = None
  bstack1ll11ll111l_opy_ = None
  def __new__(cls):
    if not hasattr(cls, bstack1l1111l_opy_ (u"ࠧࡪࡰࡶࡸࡦࡴࡣࡦࠩᚤ")):
      cls.instance = super(bstack1ll11l1l11l_opy_, cls).__new__(cls)
      cls.instance.bstack1ll11l1l1ll_opy_()
    return cls.instance
  def bstack1ll11l1l1ll_opy_(self):
    try:
      with open(self.bstack1ll11ll1111_opy_, bstack1l1111l_opy_ (u"ࠨࡴࠪᚥ")) as bstack11l11l1ll_opy_:
        bstack1ll11l1ll11_opy_ = bstack11l11l1ll_opy_.read()
        data = json.loads(bstack1ll11l1ll11_opy_)
        if bstack1l1111l_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡶࠫᚦ") in data:
          self.bstack1ll11l1lll1_opy_(data[bstack1l1111l_opy_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡷࠬᚧ")])
        if bstack1l1111l_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷࡷࠬᚨ") in data:
          self.bstack1ll11l1l1l1_opy_(data[bstack1l1111l_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸࡸ࠭ᚩ")])
    except:
      pass
  def bstack1ll11l1l1l1_opy_(self, scripts):
    if scripts != None:
      self.perform_scan = scripts[bstack1l1111l_opy_ (u"࠭ࡳࡤࡣࡱࠫᚪ")]
      self.bstack111ll11ll_opy_ = scripts[bstack1l1111l_opy_ (u"ࠧࡨࡧࡷࡖࡪࡹࡵ࡭ࡶࡶࠫᚫ")]
      self.bstack11lll1ll11_opy_ = scripts[bstack1l1111l_opy_ (u"ࠨࡩࡨࡸࡗ࡫ࡳࡶ࡮ࡷࡷࡘࡻ࡭࡮ࡣࡵࡽࠬᚬ")]
      self.bstack1ll11ll111l_opy_ = scripts[bstack1l1111l_opy_ (u"ࠩࡶࡥࡻ࡫ࡒࡦࡵࡸࡰࡹࡹࠧᚭ")]
  def bstack1ll11l1lll1_opy_(self, bstack1ll11l1ll1l_opy_):
    if bstack1ll11l1ll1l_opy_ != None and len(bstack1ll11l1ll1l_opy_) != 0:
      self.bstack1ll11l1ll1l_opy_ = bstack1ll11l1ll1l_opy_
  def store(self):
    try:
      with open(self.bstack1ll11ll1111_opy_, bstack1l1111l_opy_ (u"ࠪࡻࠬᚮ")) as file:
        json.dump({
          bstack1l1111l_opy_ (u"ࠦࡨࡵ࡭࡮ࡣࡱࡨࡸࠨᚯ"): self.bstack1ll11l1ll1l_opy_,
          bstack1l1111l_opy_ (u"ࠧࡹࡣࡳ࡫ࡳࡸࡸࠨᚰ"): {
            bstack1l1111l_opy_ (u"ࠨࡳࡤࡣࡱࠦᚱ"): self.perform_scan,
            bstack1l1111l_opy_ (u"ࠢࡨࡧࡷࡖࡪࡹࡵ࡭ࡶࡶࠦᚲ"): self.bstack111ll11ll_opy_,
            bstack1l1111l_opy_ (u"ࠣࡩࡨࡸࡗ࡫ࡳࡶ࡮ࡷࡷࡘࡻ࡭࡮ࡣࡵࡽࠧᚳ"): self.bstack11lll1ll11_opy_,
            bstack1l1111l_opy_ (u"ࠤࡶࡥࡻ࡫ࡒࡦࡵࡸࡰࡹࡹࠢᚴ"): self.bstack1ll11ll111l_opy_
          }
        }, file)
    except:
      pass
  def bstack1l1l1ll11_opy_(self, bstack1ll11l1llll_opy_):
    try:
      return any(command.get(bstack1l1111l_opy_ (u"ࠪࡲࡦࡳࡥࠨᚵ")) == bstack1ll11l1llll_opy_ for command in self.bstack1ll11l1ll1l_opy_)
    except:
      return False
bstack1l1llll1l1_opy_ = bstack1ll11l1l11l_opy_()