# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
from browserstack_sdk.bstack1111l11l_opy_ import bstack11l11111_opy_
from browserstack_sdk.bstack1l1l1l1l_opy_ import RobotHandler
def bstack1ll11l111_opy_(framework):
    if framework.lower() == bstack1l1111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᢛ"):
        return bstack11l11111_opy_.version()
    elif framework.lower() == bstack1l1111l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ᢜ"):
        return RobotHandler.version()
    elif framework.lower() == bstack1l1111l_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨᢝ"):
        import behave
        return behave.__version__
    else:
        return bstack1l1111l_opy_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪᢞ")