# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import json
import os
import threading
from bstack_utils.config import Config
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack111l1l1l1l_opy_, bstack1ll111llll_opy_, bstack1l111ll1_opy_, bstack1lllll11l1_opy_, \
    bstack111l1l1l11_opy_
from bstack_utils.measure import measure
def bstack11lll1lll_opy_(bstack111l1l11l1_opy_):
    for driver in bstack111l1l11l1_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack11l111l11l_opy_, stage=STAGE.SINGLE)
def bstack11ll1111ll_opy_(driver, status, reason=bstack1l1111l_opy_ (u"ࠧࠨྲ")):
    bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
    if bstack11l11l11_opy_.bstack111111l1_opy_():
        return
    bstack1l11l1l1l_opy_ = bstack1l11l1lll_opy_(bstack1l1111l_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫླ"), bstack1l1111l_opy_ (u"ࠩࠪྴ"), status, reason, bstack1l1111l_opy_ (u"ࠪࠫྵ"), bstack1l1111l_opy_ (u"ࠫࠬྶ"))
    driver.execute_script(bstack1l11l1l1l_opy_)
@measure(event_name=EVENTS.bstack11l111l11l_opy_, stage=STAGE.SINGLE)
def bstack11l1l1l1ll_opy_(page, status, reason=bstack1l1111l_opy_ (u"ࠬ࠭ྷ")):
    try:
        if page is None:
            return
        bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
        if bstack11l11l11_opy_.bstack111111l1_opy_():
            return
        bstack1l11l1l1l_opy_ = bstack1l11l1lll_opy_(bstack1l1111l_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠩྸ"), bstack1l1111l_opy_ (u"ࠧࠨྐྵ"), status, reason, bstack1l1111l_opy_ (u"ࠨࠩྺ"), bstack1l1111l_opy_ (u"ࠩࠪྻ"))
        page.evaluate(bstack1l1111l_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦྼ"), bstack1l11l1l1l_opy_)
    except Exception as e:
        print(bstack1l1111l_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡷࡪࡺࡴࡪࡰࡪࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥ࡬࡯ࡳࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡻࡾࠤ྽"), e)
def bstack1l11l1lll_opy_(type, name, status, reason, bstack1l1l1l1l1_opy_, bstack11l1l1ll1_opy_):
    bstack1l111l1l1_opy_ = {
        bstack1l1111l_opy_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࠬ྾"): type,
        bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ྿"): {}
    }
    if type == bstack1l1111l_opy_ (u"ࠧࡢࡰࡱࡳࡹࡧࡴࡦࠩ࿀"):
        bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ࿁")][bstack1l1111l_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨ࿂")] = bstack1l1l1l1l1_opy_
        bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭࿃")][bstack1l1111l_opy_ (u"ࠫࡩࡧࡴࡢࠩ࿄")] = json.dumps(str(bstack11l1l1ll1_opy_))
    if type == bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭࿅"):
        bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴ࿆ࠩ")][bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ࿇")] = name
    if type == bstack1l1111l_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫ࿈"):
        bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ࿉")][bstack1l1111l_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ࿊")] = status
        if status == bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ࿋") and str(reason) != bstack1l1111l_opy_ (u"ࠧࠨ࿌"):
            bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ࿍")][bstack1l1111l_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ࿎")] = json.dumps(str(reason))
    bstack1l1l1l1111_opy_ = bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭࿏").format(json.dumps(bstack1l111l1l1_opy_))
    return bstack1l1l1l1111_opy_
def bstack111l1lll1_opy_(url, config, logger, bstack1ll1ll1ll_opy_=False):
    hostname = bstack1ll111llll_opy_(url)
    is_private = bstack1lllll11l1_opy_(hostname)
    try:
        if is_private or bstack1ll1ll1ll_opy_:
            file_path = bstack111l1l1l1l_opy_(bstack1l1111l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩ࿐"), bstack1l1111l_opy_ (u"ࠪ࠲ࡧࡹࡴࡢࡥ࡮࠱ࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩ࿑"), logger)
            if os.environ.get(bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ࿒")) and eval(
                    os.environ.get(bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡑࡕࡃࡂࡎࡢࡒࡔ࡚࡟ࡔࡇࡗࡣࡊࡘࡒࡐࡔࠪ࿓"))):
                return
            if (bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ࿔") in config and not config[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ࿕")]):
                os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡎࡐࡖࡢࡗࡊ࡚࡟ࡆࡔࡕࡓࡗ࠭࿖")] = str(True)
                bstack111l1ll111_opy_ = {bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠫ࿗"): hostname}
                bstack111l1l1l11_opy_(bstack1l1111l_opy_ (u"ࠪ࠲ࡧࡹࡴࡢࡥ࡮࠱ࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩ࿘"), bstack1l1111l_opy_ (u"ࠫࡳࡻࡤࡨࡧࡢࡰࡴࡩࡡ࡭ࠩ࿙"), bstack111l1ll111_opy_, logger)
    except Exception as e:
        pass
def bstack11ll1l11l1_opy_(caps, bstack111l1l1ll1_opy_):
    if bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭࿚") in caps:
        caps[bstack1l1111l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧ࿛")][bstack1l1111l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱ࠭࿜")] = True
        if bstack111l1l1ll1_opy_:
            caps[bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ࿝")][bstack1l1111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ࿞")] = bstack111l1l1ll1_opy_
    else:
        caps[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰࡯ࡳࡨࡧ࡬ࠨ࿟")] = True
        if bstack111l1l1ll1_opy_:
            caps[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ࿠")] = bstack111l1l1ll1_opy_
def bstack111l1l1lll_opy_(bstack1ll111l1_opy_):
    bstack111l1l11ll_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡺࡥࡴࡶࡖࡸࡦࡺࡵࡴࠩ࿡"), bstack1l1111l_opy_ (u"࠭ࠧ࿢"))
    if bstack111l1l11ll_opy_ == bstack1l1111l_opy_ (u"ࠧࠨ࿣") or bstack111l1l11ll_opy_ == bstack1l1111l_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩ࿤"):
        threading.current_thread().testStatus = bstack1ll111l1_opy_
    else:
        if bstack1ll111l1_opy_ == bstack1l1111l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ࿥"):
            threading.current_thread().testStatus = bstack1ll111l1_opy_