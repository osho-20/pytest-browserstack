# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import threading
import logging
import bstack_utils.accessibility as bstack1111ll11_opy_
from bstack_utils.helper import bstack1l111ll1_opy_
logger = logging.getLogger(__name__)
def bstack1l11111l1_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False
def bstack1lll111l1_opy_(context, *args):
    tags = getattr(args[0], bstack1l1111l_opy_ (u"࠭ࡴࡢࡩࡶࠫ᎓"), [])
    bstack1lll111lll_opy_ = bstack1111ll11_opy_.bstack1llll1l1l1_opy_(tags)
    threading.current_thread().isA11yTest = bstack1lll111lll_opy_
    try:
      bstack11l1ll11l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11111l1_opy_(bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡓࡦࡵࡶ࡭ࡴࡴࡄࡳ࡫ࡹࡩࡷ࠭᎔")) else context.browser
      if bstack11l1ll11l1_opy_ and bstack11l1ll11l1_opy_.session_id and bstack1lll111lll_opy_ and bstack1l111ll1_opy_(
              threading.current_thread(), bstack1l1111l_opy_ (u"ࠨࡣ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳࠧ᎕"), None):
          threading.current_thread().isA11yTest = bstack1111ll11_opy_.bstack111lllll1_opy_(bstack11l1ll11l1_opy_, bstack1lll111lll_opy_)
    except Exception as e:
       logger.debug(bstack1l1111l_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡦ࠷࠱ࡺࠢ࡬ࡲࠥࡨࡥࡩࡣࡹࡩ࠿ࠦࡻࡾࠩ᎖").format(str(e)))
def bstack1l1111lll_opy_(bstack11l1ll11l1_opy_):
    if bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠪ࡭ࡸࡇ࠱࠲ࡻࡗࡩࡸࡺࠧ᎗"), None) and bstack1l111ll1_opy_(
      threading.current_thread(), bstack1l1111l_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪ᎘"), None) and not bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡧ࠱࠲ࡻࡢࡷࡹࡵࡰࠨ᎙"), False):
      threading.current_thread().a11y_stop = True
      bstack1111ll11_opy_.bstack111llll1_opy_(bstack11l1ll11l1_opy_, name=bstack1l1111l_opy_ (u"ࠨࠢ᎚"), path=bstack1l1111l_opy_ (u"ࠢࠣ᎛"))