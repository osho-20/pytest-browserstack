# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
from _pytest import fixtures
from _pytest.python import _call_with_optional_argument
from pytest import Module, Class
from bstack_utils.helper import Result, bstack1111lll111_opy_
from browserstack_sdk.bstack1111l11l_opy_ import bstack11l11111_opy_
def _111l111l11_opy_(method, this, arg):
    arg_count = method.__code__.co_argcount
    if arg_count > 1:
        method(this, arg)
    else:
        method(this)
class bstack111l11l11l_opy_:
    def __init__(self, handler):
        self._111l111111_opy_ = {}
        self._1111llllll_opy_ = {}
        self.handler = handler
        self.patch()
        pass
    def patch(self):
        pytest_version = bstack11l11111_opy_.version()
        if bstack1111lll111_opy_(pytest_version, bstack1l1111l_opy_ (u"ࠨ࠸࠯࠳࠱࠵ࠧဌ")) >= 0:
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠪဍ")] = Module._register_setup_function_fixture
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠨ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩဎ")] = Module._register_setup_module_fixture
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠩࡦࡰࡦࡹࡳࡠࡨ࡬ࡼࡹࡻࡲࡦࠩဏ")] = Class._register_setup_class_fixture
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࡢࡪ࡮ࡾࡴࡶࡴࡨࠫတ")] = Class._register_setup_method_fixture
            Module._register_setup_function_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥࡦࡪࡺࡷࡹࡷ࡫ࠧထ"))
            Module._register_setup_module_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"ࠬࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ဒ"))
            Class._register_setup_class_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"࠭ࡣ࡭ࡣࡶࡷࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ဓ"))
            Class._register_setup_method_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨန"))
        else:
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࡢࡪ࡮ࡾࡴࡶࡴࡨࠫပ")] = Module._inject_setup_function_fixture
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠩࡰࡳࡩࡻ࡬ࡦࡡࡩ࡭ࡽࡺࡵࡳࡧࠪဖ")] = Module._inject_setup_module_fixture
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠪࡧࡱࡧࡳࡴࡡࡩ࡭ࡽࡺࡵࡳࡧࠪဗ")] = Class._inject_setup_class_fixture
            self._111l111111_opy_[bstack1l1111l_opy_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫࡯ࡸࡵࡷࡵࡩࠬဘ")] = Class._inject_setup_method_fixture
            Module._inject_setup_function_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨမ"))
            Module._inject_setup_module_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"࠭࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫ࠧယ"))
            Class._inject_setup_class_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"ࠧࡤ࡮ࡤࡷࡸࡥࡦࡪࡺࡷࡹࡷ࡫ࠧရ"))
            Class._inject_setup_method_fixture = self.bstack1111lllll1_opy_(bstack1l1111l_opy_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨ࡬ࡼࡹࡻࡲࡦࠩလ"))
    def bstack1111lll1ll_opy_(self, bstack1111lll11l_opy_, hook_type):
        bstack111l111lll_opy_ = id(bstack1111lll11l_opy_.__class__)
        if (bstack111l111lll_opy_, hook_type) in self._1111llllll_opy_:
            return
        meth = getattr(bstack1111lll11l_opy_, hook_type, None)
        if meth is not None and fixtures.getfixturemarker(meth) is None:
            self._1111llllll_opy_[(bstack111l111lll_opy_, hook_type)] = meth
            setattr(bstack1111lll11l_opy_, hook_type, self.bstack1111lll1l1_opy_(hook_type, bstack111l111lll_opy_))
    def bstack111l11l111_opy_(self, instance, bstack111l111ll1_opy_):
        if bstack111l111ll1_opy_ == bstack1l1111l_opy_ (u"ࠤࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠧဝ"):
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠥࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࠦသ"))
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠣဟ"))
        if bstack111l111ll1_opy_ == bstack1l1111l_opy_ (u"ࠧࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪࠨဠ"):
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠨࡳࡦࡶࡸࡴࡤࡳ࡯ࡥࡷ࡯ࡩࠧအ"))
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠢࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡰࡳࡩࡻ࡬ࡦࠤဢ"))
        if bstack111l111ll1_opy_ == bstack1l1111l_opy_ (u"ࠣࡥ࡯ࡥࡸࡹ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠣဣ"):
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠤࡶࡩࡹࡻࡰࡠࡥ࡯ࡥࡸࡹࠢဤ"))
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠥࡸࡪࡧࡲࡥࡱࡺࡲࡤࡩ࡬ࡢࡵࡶࠦဥ"))
        if bstack111l111ll1_opy_ == bstack1l1111l_opy_ (u"ࠦࡲ࡫ࡴࡩࡱࡧࡣ࡫࡯ࡸࡵࡷࡵࡩࠧဦ"):
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠧࡹࡥࡵࡷࡳࡣࡲ࡫ࡴࡩࡱࡧࠦဧ"))
            self.bstack1111lll1ll_opy_(instance.obj, bstack1l1111l_opy_ (u"ࠨࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡨࡸ࡭ࡵࡤࠣဨ"))
    @staticmethod
    def bstack111l11111l_opy_(hook_type, func, args):
        if hook_type in [bstack1l1111l_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥ࡭ࡦࡶ࡫ࡳࡩ࠭ဩ"), bstack1l1111l_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡱࡪࡺࡨࡰࡦࠪဪ")]:
            _111l111l11_opy_(func, args[0], args[1])
            return
        _call_with_optional_argument(func, args[0])
    def bstack1111lll1l1_opy_(self, hook_type, bstack111l111lll_opy_):
        def bstack1111llll11_opy_(arg=None):
            self.handler(hook_type, bstack1l1111l_opy_ (u"ࠩࡥࡩ࡫ࡵࡲࡦࠩါ"))
            result = None
            try:
                bstack111l1111ll_opy_ = self._1111llllll_opy_[(bstack111l111lll_opy_, hook_type)]
                self.bstack111l11111l_opy_(hook_type, bstack111l1111ll_opy_, (arg,))
                result = Result(result=bstack1l1111l_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪာ"))
            except Exception as e:
                result = Result(result=bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫိ"), exception=e)
                self.handler(hook_type, bstack1l1111l_opy_ (u"ࠬࡧࡦࡵࡧࡵࠫီ"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1l1111l_opy_ (u"࠭ࡡࡧࡶࡨࡶࠬု"), result)
        def bstack111l111l1l_opy_(this, arg=None):
            self.handler(hook_type, bstack1l1111l_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫ࠧူ"))
            result = None
            exception = None
            try:
                self.bstack111l11111l_opy_(hook_type, self._1111llllll_opy_[hook_type], (this, arg))
                result = Result(result=bstack1l1111l_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨေ"))
            except Exception as e:
                result = Result(result=bstack1l1111l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩဲ"), exception=e)
                self.handler(hook_type, bstack1l1111l_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࠩဳ"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1l1111l_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࠪဴ"), result)
        if hook_type in [bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲ࡫ࡴࡩࡱࡧࠫဵ"), bstack1l1111l_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡨࡸ࡭ࡵࡤࠨံ")]:
            return bstack111l111l1l_opy_
        return bstack1111llll11_opy_
    def bstack1111lllll1_opy_(self, bstack111l111ll1_opy_):
        def bstack111l1111l1_opy_(this, *args, **kwargs):
            self.bstack111l11l111_opy_(this, bstack111l111ll1_opy_)
            self._111l111111_opy_[bstack111l111ll1_opy_](this, *args, **kwargs)
        return bstack111l1111l1_opy_