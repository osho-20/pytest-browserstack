# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
import json
import logging
import datetime
import threading
from bstack_utils.helper import bstack1lll11l11ll_opy_, bstack11l11llll1_opy_, get_host_info, bstack1llll111l11_opy_, \
 bstack1l11lll11_opy_, bstack1l111ll1_opy_, bstack11llllll_opy_, bstack1lll11l11l1_opy_, bstack1llll111_opy_
import bstack_utils.accessibility as bstack1111ll11_opy_
from bstack_utils.bstack11ll1l1l_opy_ import bstack1l11l1ll_opy_
from bstack_utils.percy import bstack1111l1ll1_opy_
from bstack_utils.config import Config
bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
logger = logging.getLogger(__name__)
percy = bstack1111l1ll1_opy_()
@bstack11llllll_opy_(class_method=False)
def bstack1l1llllll11_opy_(bs_config, bstack1lll1lll11_opy_):
  try:
    data = {
        bstack1l1111l_opy_ (u"ࠧࡧࡱࡵࡱࡦࡺࠧᡝ"): bstack1l1111l_opy_ (u"ࠨ࡬ࡶࡳࡳ࠭ᡞ"),
        bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡢࡲࡦࡳࡥࠨᡟ"): bs_config.get(bstack1l1111l_opy_ (u"ࠪࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠨᡠ"), bstack1l1111l_opy_ (u"ࠫࠬᡡ")),
        bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᡢ"): bs_config.get(bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩᡣ"), os.path.basename(os.path.abspath(os.getcwd()))),
        bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪᡤ"): bs_config.get(bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪᡥ")),
        bstack1l1111l_opy_ (u"ࠩࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧᡦ"): bs_config.get(bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ᡧ"), bstack1l1111l_opy_ (u"ࠫࠬᡨ")),
        bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᡩ"): bstack1llll111_opy_(),
        bstack1l1111l_opy_ (u"࠭ࡴࡢࡩࡶࠫᡪ"): bstack1llll111l11_opy_(bs_config),
        bstack1l1111l_opy_ (u"ࠧࡩࡱࡶࡸࡤ࡯࡮ࡧࡱࠪᡫ"): get_host_info(),
        bstack1l1111l_opy_ (u"ࠨࡥ࡬ࡣ࡮ࡴࡦࡰࠩᡬ"): bstack11l11llll1_opy_(),
        bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡴࡸࡲࡤ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩᡭ"): os.environ.get(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅ࡙ࡎࡒࡄࡠࡔࡘࡒࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩᡮ")),
        bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࡣࡹ࡫ࡳࡵࡵࡢࡶࡪࡸࡵ࡯ࠩᡯ"): os.environ.get(bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡗࡋࡒࡖࡐࠪᡰ"), False),
        bstack1l1111l_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴ࡟ࡤࡱࡱࡸࡷࡵ࡬ࠨᡱ"): bstack1lll11l11ll_opy_(),
        bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᡲ"): bstack1l1lll1ll11_opy_(),
        bstack1l1111l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡩ࡫ࡴࡢ࡫࡯ࡷࠬᡳ"): bstack1l1lll1l1ll_opy_(bstack1lll1lll11_opy_),
        bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࡢࡱࡦࡶࠧᡴ"): bstack1l1ll11l1l_opy_(bs_config, bstack1lll1lll11_opy_.get(bstack1l1111l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡵࡴࡧࡧࠫᡵ"), bstack1l1111l_opy_ (u"ࠫࠬᡶ"))),
        bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧᡷ"): bstack1l11lll11_opy_(bs_config),
    }
    return data
  except Exception as error:
    logger.error(bstack1l1111l_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡴࡦࡿ࡬ࡰࡣࡧࠤ࡫ࡵࡲࠡࡖࡨࡷࡹࡎࡵࡣ࠼ࠣࠤࢀࢃࠢᡸ").format(str(error)))
    return None
def bstack1l1lll1l1ll_opy_(framework):
  return {
    bstack1l1111l_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡑࡥࡲ࡫ࠧ᡹"): framework.get(bstack1l1111l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡳࡧ࡭ࡦࠩ᡺"), bstack1l1111l_opy_ (u"ࠩࡓࡽࡹ࡫ࡳࡵࠩ᡻")),
    bstack1l1111l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭᡼"): framework.get(bstack1l1111l_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ᡽")),
    bstack1l1111l_opy_ (u"ࠬࡹࡤ࡬ࡘࡨࡶࡸ࡯࡯࡯ࠩ᡾"): framework.get(bstack1l1111l_opy_ (u"࠭ࡳࡥ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠫ᡿")),
    bstack1l1111l_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩᢀ"): bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨᢁ"),
    bstack1l1111l_opy_ (u"ࠩࡷࡩࡸࡺࡆࡳࡣࡰࡩࡼࡵࡲ࡬ࠩᢂ"): framework.get(bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡇࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪᢃ"))
  }
def bstack1l1ll11l1l_opy_(bs_config, framework):
  bstack1l1l111l1_opy_ = False
  bstack1l11l1ll11_opy_ = False
  bstack1l1lll1llll_opy_ = False
  if bstack1l1111l_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨᢄ") in bs_config:
    bstack1l1lll1llll_opy_ = True
  elif bstack1l1111l_opy_ (u"ࠬࡧࡰࡱࠩᢅ") in bs_config:
    bstack1l1l111l1_opy_ = True
  else:
    bstack1l11l1ll11_opy_ = True
  bstack111lll1l11_opy_ = {
    bstack1l1111l_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ᢆ"): bstack1l11l1ll_opy_.bstack11111l1l11_opy_(bs_config, framework),
    bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᢇ"): bstack1111ll11_opy_.bstack1ll11l11ll1_opy_(bs_config),
    bstack1l1111l_opy_ (u"ࠨࡲࡨࡶࡨࡿࠧᢈ"): bs_config.get(bstack1l1111l_opy_ (u"ࠩࡳࡩࡷࡩࡹࠨᢉ"), False),
    bstack1l1111l_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬᢊ"): bstack1l11l1ll11_opy_,
    bstack1l1111l_opy_ (u"ࠫࡦࡶࡰࡠࡣࡸࡸࡴࡳࡡࡵࡧࠪᢋ"): bstack1l1l111l1_opy_,
    bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡷࡨࡧ࡬ࡦࠩᢌ"): bstack1l1lll1llll_opy_
  }
  return bstack111lll1l11_opy_
@bstack11llllll_opy_(class_method=False)
def bstack1l1lll1ll11_opy_():
  try:
    bstack1l1lll1l1l1_opy_ = json.loads(os.getenv(bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡢࡅࡈࡉࡅࡔࡕࡌࡆࡎࡒࡉࡕ࡛ࡢࡇࡔࡔࡆࡊࡉࡘࡖࡆ࡚ࡉࡐࡐࡢ࡝ࡒࡒࠧᢍ"), bstack1l1111l_opy_ (u"ࠧࡼࡿࠪᢎ")))
    return {
        bstack1l1111l_opy_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵࠪᢏ"): bstack1l1lll1l1l1_opy_
    }
  except Exception as error:
    logger.error(bstack1l1111l_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡽࡨࡪ࡮ࡨࠤࡨࡸࡥࡢࡶ࡬ࡲ࡬ࠦࡧࡦࡶࡢࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡢࡷࡪࡺࡴࡪࡰࡪࡷࠥ࡬࡯ࡳࠢࡗࡩࡸࡺࡈࡶࡤ࠽ࠤࠥࢁࡽࠣᢐ").format(str(error)))
    return {}
def bstack1ll1111l111_opy_(array, bstack1l1llll11l1_opy_, bstack1l1lll1ll1l_opy_):
  result = {}
  for o in array:
    key = o[bstack1l1llll11l1_opy_]
    result[key] = o[bstack1l1lll1ll1l_opy_]
  return result
def bstack1ll1111lll1_opy_(bstack11llllll11_opy_=bstack1l1111l_opy_ (u"ࠪࠫᢑ")):
  bstack1l1lll1lll1_opy_ = bstack1111ll11_opy_.on()
  bstack1l1llll111l_opy_ = bstack1l11l1ll_opy_.on()
  bstack1l1llll11ll_opy_ = percy.bstack1l1ll1l11l_opy_()
  if bstack1l1llll11ll_opy_ and not bstack1l1llll111l_opy_ and not bstack1l1lll1lll1_opy_:
    return bstack11llllll11_opy_ not in [bstack1l1111l_opy_ (u"ࠫࡈࡈࡔࡔࡧࡶࡷ࡮ࡵ࡮ࡄࡴࡨࡥࡹ࡫ࡤࠨᢒ"), bstack1l1111l_opy_ (u"ࠬࡒ࡯ࡨࡅࡵࡩࡦࡺࡥࡥࠩᢓ")]
  elif bstack1l1lll1lll1_opy_ and not bstack1l1llll111l_opy_:
    return bstack11llllll11_opy_ not in [bstack1l1111l_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᢔ"), bstack1l1111l_opy_ (u"ࠧࡉࡱࡲ࡯ࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩᢕ"), bstack1l1111l_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨࠬᢖ")]
  return bstack1l1lll1lll1_opy_ or bstack1l1llll111l_opy_ or bstack1l1llll11ll_opy_
@bstack11llllll_opy_(class_method=False)
def bstack1l1lllllll1_opy_(bstack11llllll11_opy_, test=None):
  bstack1l1llll1111_opy_ = bstack1111ll11_opy_.on()
  if not bstack1l1llll1111_opy_ or bstack11llllll11_opy_ not in [bstack1l1111l_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᢗ")] or test == None:
    return None
  return {
    bstack1l1111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᢘ"): bstack1l1llll1111_opy_ and bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪᢙ"), None) == True and bstack1111ll11_opy_.bstack1llll1l1l1_opy_(test[bstack1l1111l_opy_ (u"ࠬࡺࡡࡨࡵࠪᢚ")])
  }