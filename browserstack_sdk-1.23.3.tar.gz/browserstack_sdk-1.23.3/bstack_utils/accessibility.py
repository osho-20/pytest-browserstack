# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
import json
import requests
import logging
import threading
from urllib.parse import urlparse
from bstack_utils.constants import bstack1111l1l11l_opy_ as bstack1ll111ll11l_opy_, EVENTS
from bstack_utils.bstack1l1llll1l1_opy_ import bstack1l1llll1l1_opy_
from bstack_utils.helper import bstack1llll111_opy_, bstack1l1l1ll1_opy_, bstack1l11lll11_opy_, bstack1lll1l11l11_opy_, \
  bstack1lll11l1l1l_opy_, bstack11l11llll1_opy_, get_host_info, bstack1lll11l11ll_opy_, bstack1ll1l11111_opy_, bstack11llllll_opy_
from browserstack_sdk._version import __version__
from bstack_utils.bstack11lll111ll_opy_ import get_logger
from bstack_utils.bstack1ll1111ll1_opy_ import bstack111ll11ll1_opy_
logger = get_logger(__name__)
bstack1ll1111ll1_opy_ = bstack111ll11ll1_opy_()
@bstack11llllll_opy_(class_method=False)
def _1ll11l11lll_opy_(driver, bstack1111ll1l_opy_):
  response = {}
  try:
    caps = driver.capabilities
    response = {
        bstack1l1111l_opy_ (u"ࠫࡴࡹ࡟࡯ࡣࡰࡩࠬᚶ"): caps.get(bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠫᚷ"), None),
        bstack1l1111l_opy_ (u"࠭࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠪᚸ"): bstack1111ll1l_opy_.get(bstack1l1111l_opy_ (u"ࠧࡰࡵ࡙ࡩࡷࡹࡩࡰࡰࠪᚹ"), None),
        bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡱࡥࡲ࡫ࠧᚺ"): caps.get(bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧᚻ"), None),
        bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᚼ"): caps.get(bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᚽ"), None)
    }
  except Exception as error:
    logger.debug(bstack1l1111l_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡫࡫ࡴࡤࡪ࡬ࡲ࡬ࠦࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠡࡦࡨࡸࡦ࡯࡬ࡴࠢࡺ࡭ࡹ࡮ࠠࡦࡴࡵࡳࡷࠦ࠺ࠡࠩᚾ") + str(error))
  return response
def on():
    if os.environ.get(bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫᚿ"), None) is None or os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᛀ")] == bstack1l1111l_opy_ (u"ࠣࡰࡸࡰࡱࠨᛁ"):
        return False
    return True
def bstack1ll11l11ll1_opy_(config):
  return config.get(bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᛂ"), False) or any([p.get(bstack1l1111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᛃ"), False) == True for p in config.get(bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧᛄ"), [])])
def bstack111ll111l_opy_(config, bstack1l1l1l111l_opy_):
  try:
    if not bstack1l11lll11_opy_(config):
      return False
    bstack1ll111ll1ll_opy_ = config.get(bstack1l1111l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᛅ"), False)
    if int(bstack1l1l1l111l_opy_) < len(config.get(bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩᛆ"), [])) and config[bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪᛇ")][bstack1l1l1l111l_opy_]:
      bstack1ll11l11l1l_opy_ = config[bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫᛈ")][bstack1l1l1l111l_opy_].get(bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᛉ"), None)
    else:
      bstack1ll11l11l1l_opy_ = config.get(bstack1l1111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᛊ"), None)
    if bstack1ll11l11l1l_opy_ != None:
      bstack1ll111ll1ll_opy_ = bstack1ll11l11l1l_opy_
    bstack1ll111l11ll_opy_ = os.getenv(bstack1l1111l_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᛋ")) is not None and len(os.getenv(bstack1l1111l_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪᛌ"))) > 0 and os.getenv(bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫᛍ")) != bstack1l1111l_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬᛎ")
    return bstack1ll111ll1ll_opy_ and bstack1ll111l11ll_opy_
  except Exception as error:
    logger.debug(bstack1l1111l_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡷࡧࡵ࡭࡫ࡿࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡹ࡬ࡸ࡭ࠦࡥࡳࡴࡲࡶࠥࡀࠠࠨᛏ") + str(error))
  return False
def bstack1llll1l1l1_opy_(test_tags):
  bstack1ll111llll1_opy_ = os.getenv(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡥࡁࡄࡅࡈࡗࡘࡏࡂࡊࡎࡌࡘ࡞ࡥࡃࡐࡐࡉࡍࡌ࡛ࡒࡂࡖࡌࡓࡓࡥ࡙ࡎࡎࠪᛐ"))
  if bstack1ll111llll1_opy_ is None:
    return True
  bstack1ll111llll1_opy_ = json.loads(bstack1ll111llll1_opy_)
  try:
    include_tags = bstack1ll111llll1_opy_[bstack1l1111l_opy_ (u"ࠪ࡭ࡳࡩ࡬ࡶࡦࡨࡘࡦ࡭ࡳࡊࡰࡗࡩࡸࡺࡩ࡯ࡩࡖࡧࡴࡶࡥࠨᛑ")] if bstack1l1111l_opy_ (u"ࠫ࡮ࡴࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩᛒ") in bstack1ll111llll1_opy_ and isinstance(bstack1ll111llll1_opy_[bstack1l1111l_opy_ (u"ࠬ࡯࡮ࡤ࡮ࡸࡨࡪ࡚ࡡࡨࡵࡌࡲ࡙࡫ࡳࡵ࡫ࡱ࡫ࡘࡩ࡯ࡱࡧࠪᛓ")], list) else []
    exclude_tags = bstack1ll111llll1_opy_[bstack1l1111l_opy_ (u"࠭ࡥࡹࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫᛔ")] if bstack1l1111l_opy_ (u"ࠧࡦࡺࡦࡰࡺࡪࡥࡕࡣࡪࡷࡎࡴࡔࡦࡵࡷ࡭ࡳ࡭ࡓࡤࡱࡳࡩࠬᛕ") in bstack1ll111llll1_opy_ and isinstance(bstack1ll111llll1_opy_[bstack1l1111l_opy_ (u"ࠨࡧࡻࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭ᛖ")], list) else []
    excluded = any(tag in exclude_tags for tag in test_tags)
    included = len(include_tags) == 0 or any(tag in include_tags for tag in test_tags)
    return not excluded and included
  except Exception as error:
    logger.debug(bstack1l1111l_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠࡷࡣ࡯࡭ࡩࡧࡴࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫ࠠࡧࡱࡵࠤࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡧ࡫ࡦࡰࡴࡨࠤࡸࡩࡡ࡯ࡰ࡬ࡲ࡬࠴ࠠࡆࡴࡵࡳࡷࠦ࠺ࠡࠤᛗ") + str(error))
  return False
def bstack1ll111l1l1l_opy_(config, frameworkName, bstack1ll11l111ll_opy_, bstack1ll111ll111_opy_):
  bstack1ll111l1l11_opy_ = bstack1lll1l11l11_opy_(config)
  bstack1ll111lll1l_opy_ = bstack1lll11l1l1l_opy_(config)
  if bstack1ll111l1l11_opy_ is None or bstack1ll111lll1l_opy_ is None:
    logger.error(bstack1l1111l_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡵࡧࡶࡸࠥࡸࡵ࡯ࠢࡩࡳࡷࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯࠼ࠣࡑ࡮ࡹࡳࡪࡰࡪࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡺ࡯࡬ࡧࡱࠫᛘ"))
    return [None, None]
  try:
    settings = json.loads(os.getenv(bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡠࡃࡆࡇࡊ࡙ࡓࡊࡄࡌࡐࡎ࡚࡙ࡠࡅࡒࡒࡋࡏࡇࡖࡔࡄࡘࡎࡕࡎࡠ࡛ࡐࡐࠬᛙ"), bstack1l1111l_opy_ (u"ࠬࢁࡽࠨᛚ")))
    data = {
        bstack1l1111l_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠫᛛ"): config[bstack1l1111l_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬᛜ")],
        bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫᛝ"): config.get(bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬᛞ"), os.path.basename(os.getcwd())),
        bstack1l1111l_opy_ (u"ࠪࡷࡹࡧࡲࡵࡖ࡬ࡱࡪ࠭ᛟ"): bstack1llll111_opy_(),
        bstack1l1111l_opy_ (u"ࠫࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩᛠ"): config.get(bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡈࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨᛡ"), bstack1l1111l_opy_ (u"࠭ࠧᛢ")),
        bstack1l1111l_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧᛣ"): {
            bstack1l1111l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡒࡦࡳࡥࠨᛤ"): frameworkName,
            bstack1l1111l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯࡛࡫ࡲࡴ࡫ࡲࡲࠬᛥ"): bstack1ll11l111ll_opy_,
            bstack1l1111l_opy_ (u"ࠪࡷࡩࡱࡖࡦࡴࡶ࡭ࡴࡴࠧᛦ"): __version__,
            bstack1l1111l_opy_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ᛧ"): bstack1l1111l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬᛨ"),
            bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡊࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭ᛩ"): bstack1l1111l_opy_ (u"ࠧࡴࡧ࡯ࡩࡳ࡯ࡵ࡮ࠩᛪ"),
            bstack1l1111l_opy_ (u"ࠨࡶࡨࡷࡹࡌࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ᛫"): bstack1ll111ll111_opy_
        },
        bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶࠫ᛬"): settings,
        bstack1l1111l_opy_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࡇࡴࡴࡴࡳࡱ࡯ࠫ᛭"): bstack1lll11l11ll_opy_(),
        bstack1l1111l_opy_ (u"ࠫࡨ࡯ࡉ࡯ࡨࡲࠫᛮ"): bstack11l11llll1_opy_(),
        bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡴࡶࡌࡲ࡫ࡵࠧᛯ"): get_host_info(),
        bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᛰ"): bstack1l11lll11_opy_(config)
    }
    headers = {
        bstack1l1111l_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᛱ"): bstack1l1111l_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᛲ"),
    }
    config = {
        bstack1l1111l_opy_ (u"ࠩࡤࡹࡹ࡮ࠧᛳ"): (bstack1ll111l1l11_opy_, bstack1ll111lll1l_opy_),
        bstack1l1111l_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫᛴ"): headers
    }
    response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠫࡕࡕࡓࡕࠩᛵ"), bstack1ll111ll11l_opy_ + bstack1l1111l_opy_ (u"ࠬ࠵ࡶ࠳࠱ࡷࡩࡸࡺ࡟ࡳࡷࡱࡷࠬᛶ"), data, config)
    bstack1ll11l11l11_opy_ = response.json()
    if bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧᛷ")]:
      parsed = json.loads(os.getenv(bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨᛸ"), bstack1l1111l_opy_ (u"ࠨࡽࢀࠫ᛹")))
      parsed[bstack1l1111l_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪ᛺")] = bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠪࡨࡦࡺࡡࠨ᛻")][bstack1l1111l_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬ᛼")]
      os.environ[bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭᛽")] = json.dumps(parsed)
      bstack1l1llll1l1_opy_.bstack1ll11l1l1l1_opy_(bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"࠭ࡤࡢࡶࡤࠫ᛾")][bstack1l1111l_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺࡳࠨ᛿")])
      bstack1l1llll1l1_opy_.bstack1ll11l1lll1_opy_(bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠨࡦࡤࡸࡦ࠭ᜀ")][bstack1l1111l_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡶࠫᜁ")])
      bstack1l1llll1l1_opy_.store()
      return bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠪࡨࡦࡺࡡࠨᜂ")][bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡘࡴࡱࡥ࡯ࠩᜃ")], bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠬࡪࡡࡵࡣࠪᜄ")][bstack1l1111l_opy_ (u"࠭ࡩࡥࠩᜅ")]
    else:
      logger.error(bstack1l1111l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡻ࡭࡯࡬ࡦࠢࡵࡹࡳࡴࡩ࡯ࡩࠣࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡀࠠࠨᜆ") + bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᜇ")])
      if bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᜈ")] == bstack1l1111l_opy_ (u"ࠪࡍࡳࡼࡡ࡭࡫ࡧࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡵࡧࡳࡴࡧࡧ࠲ࠬᜉ"):
        for bstack1ll111lll11_opy_ in bstack1ll11l11l11_opy_[bstack1l1111l_opy_ (u"ࠫࡪࡸࡲࡰࡴࡶࠫᜊ")]:
          logger.error(bstack1ll111lll11_opy_[bstack1l1111l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᜋ")])
      return None, None
  except Exception as error:
    logger.error(bstack1l1111l_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡸࡪࡹࡴࠡࡴࡸࡲࠥ࡬࡯ࡳࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲ࠿ࠦࠢᜌ") +  str(error))
    return None, None
def bstack1ll111l11l1_opy_():
  if os.getenv(bstack1l1111l_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᜍ")) is None:
    return {
        bstack1l1111l_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨᜎ"): bstack1l1111l_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨᜏ"),
        bstack1l1111l_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᜐ"): bstack1l1111l_opy_ (u"ࠫࡇࡻࡩ࡭ࡦࠣࡧࡷ࡫ࡡࡵ࡫ࡲࡲࠥ࡮ࡡࡥࠢࡩࡥ࡮ࡲࡥࡥ࠰ࠪᜑ")
    }
  data = {bstack1l1111l_opy_ (u"ࠬ࡫࡮ࡥࡖ࡬ࡱࡪ࠭ᜒ"): bstack1llll111_opy_()}
  headers = {
      bstack1l1111l_opy_ (u"࠭ࡁࡶࡶ࡫ࡳࡷ࡯ࡺࡢࡶ࡬ࡳࡳ࠭ᜓ"): bstack1l1111l_opy_ (u"ࠧࡃࡧࡤࡶࡪࡸࠠࠨ᜔") + os.getenv(bstack1l1111l_opy_ (u"ࠣࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙ࠨ᜕")),
      bstack1l1111l_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ᜖"): bstack1l1111l_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭᜗")
  }
  response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠫࡕ࡛ࡔࠨ᜘"), bstack1ll111ll11l_opy_ + bstack1l1111l_opy_ (u"ࠬ࠵ࡴࡦࡵࡷࡣࡷࡻ࡮ࡴ࠱ࡶࡸࡴࡶࠧ᜙"), data, { bstack1l1111l_opy_ (u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧ᜚"): headers })
  try:
    if response.status_code == 200:
      logger.info(bstack1l1111l_opy_ (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡘࡪࡹࡴࠡࡔࡸࡲࠥࡳࡡࡳ࡭ࡨࡨࠥࡧࡳࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡦࡺࠠࠣ᜛") + bstack1l1l1ll1_opy_().isoformat() + bstack1l1111l_opy_ (u"ࠨ࡜ࠪ᜜"))
      return {bstack1l1111l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ᜝"): bstack1l1111l_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫ᜞"), bstack1l1111l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᜟ"): bstack1l1111l_opy_ (u"ࠬ࠭ᜠ")}
    else:
      response.raise_for_status()
  except requests.RequestException as error:
    logger.error(bstack1l1111l_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡ࡯ࡤࡶࡰ࡯࡮ࡨࠢࡦࡳࡲࡶ࡬ࡦࡶ࡬ࡳࡳࠦ࡯ࡧࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲ࡚ࠥࡥࡴࡶࠣࡖࡺࡴ࠺ࠡࠤᜡ") + str(error))
    return {
        bstack1l1111l_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧᜢ"): bstack1l1111l_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧᜣ"),
        bstack1l1111l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᜤ"): str(error)
    }
def bstack1lll11111_opy_(caps, options, desired_capabilities={}):
  try:
    bstack1ll111l111l_opy_ = caps.get(bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᜥ"), {}).get(bstack1l1111l_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࡒࡦࡳࡥࠨᜦ"), caps.get(bstack1l1111l_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࠬᜧ"), bstack1l1111l_opy_ (u"࠭ࠧᜨ")))
    if bstack1ll111l111l_opy_:
      logger.warn(bstack1l1111l_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡵࡹࡳࠦ࡯࡯࡮ࡼࠤࡴࡴࠠࡅࡧࡶ࡯ࡹࡵࡰࠡࡤࡵࡳࡼࡹࡥࡳࡵ࠱ࠦᜩ"))
      return False
    if options:
      bstack1ll11l111l1_opy_ = options.to_capabilities()
    elif desired_capabilities:
      bstack1ll11l111l1_opy_ = desired_capabilities
    else:
      bstack1ll11l111l1_opy_ = {}
    browser = caps.get(bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭ᜪ"), bstack1l1111l_opy_ (u"ࠩࠪᜫ")).lower() or bstack1ll11l111l1_opy_.get(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨᜬ"), bstack1l1111l_opy_ (u"ࠫࠬᜭ")).lower()
    if browser != bstack1l1111l_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬᜮ"):
      logger.warn(bstack1l1111l_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡻ࡮ࡲ࡬ࠡࡴࡸࡲࠥࡵ࡮࡭ࡻࠣࡳࡳࠦࡃࡩࡴࡲࡱࡪࠦࡢࡳࡱࡺࡷࡪࡸࡳ࠯ࠤᜯ"))
      return False
    browser_version = caps.get(bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᜰ")) or caps.get(bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪᜱ")) or bstack1ll11l111l1_opy_.get(bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᜲ")) or bstack1ll11l111l1_opy_.get(bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᜳ"), {}).get(bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲ᜴ࠬ")) or bstack1ll11l111l1_opy_.get(bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭᜵"), {}).get(bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ᜶"))
    if browser_version and browser_version != bstack1l1111l_opy_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ᜷") and int(browser_version.split(bstack1l1111l_opy_ (u"ࠨ࠰ࠪ᜸"))[0]) <= 98:
      logger.warn(bstack1l1111l_opy_ (u"ࠤࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡷࡪ࡮࡯ࠤࡷࡻ࡮ࠡࡱࡱࡰࡾࠦ࡯࡯ࠢࡆ࡬ࡷࡵ࡭ࡦࠢࡥࡶࡴࡽࡳࡦࡴࠣࡺࡪࡸࡳࡪࡱࡱࠤ࡬ࡸࡥࡢࡶࡨࡶࠥࡺࡨࡢࡰࠣ࠽࠽࠴ࠢ᜹"))
      return False
    if not options:
      bstack1ll11l11111_opy_ = caps.get(bstack1l1111l_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨ᜺")) or bstack1ll11l111l1_opy_.get(bstack1l1111l_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩ᜻"), {})
      if bstack1l1111l_opy_ (u"ࠬ࠳࠭ࡩࡧࡤࡨࡱ࡫ࡳࡴࠩ᜼") in bstack1ll11l11111_opy_.get(bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡶࠫ᜽"), []):
        logger.warn(bstack1l1111l_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡱࡳࡹࠦࡲࡶࡰࠣࡳࡳࠦ࡬ࡦࡩࡤࡧࡾࠦࡨࡦࡣࡧࡰࡪࡹࡳࠡ࡯ࡲࡨࡪ࠴ࠠࡔࡹ࡬ࡸࡨ࡮ࠠࡵࡱࠣࡲࡪࡽࠠࡩࡧࡤࡨࡱ࡫ࡳࡴࠢࡰࡳࡩ࡫ࠠࡰࡴࠣࡥࡻࡵࡩࡥࠢࡸࡷ࡮ࡴࡧࠡࡪࡨࡥࡩࡲࡥࡴࡵࠣࡱࡴࡪࡥ࠯ࠤ᜾"))
        return False
    return True
  except Exception as error:
    logger.debug(bstack1l1111l_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡷࡣ࡯࡭ࡩࡧࡴࡦࠢࡤ࠵࠶ࡿࠠࡴࡷࡳࡴࡴࡸࡴࠡ࠼ࠥ᜿") + str(error))
    return False
def set_capabilities(caps, config):
  try:
    bstack1ll11l1111l_opy_ = config.get(bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩᝀ"), {})
    bstack1ll11l1111l_opy_[bstack1l1111l_opy_ (u"ࠪࡥࡺࡺࡨࡕࡱ࡮ࡩࡳ࠭ᝁ")] = os.getenv(bstack1l1111l_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᝂ"))
    bstack1ll111l1lll_opy_ = json.loads(os.getenv(bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ᝃ"), bstack1l1111l_opy_ (u"࠭ࡻࡾࠩᝄ"))).get(bstack1l1111l_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᝅ"))
    caps[bstack1l1111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᝆ")] = True
    if bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᝇ") in caps:
      caps[bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᝈ")][bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫᝉ")] = bstack1ll11l1111l_opy_
      caps[bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᝊ")][bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᝋ")][bstack1l1111l_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᝌ")] = bstack1ll111l1lll_opy_
    else:
      caps[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧᝍ")] = bstack1ll11l1111l_opy_
      caps[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᝎ")][bstack1l1111l_opy_ (u"ࠪࡷࡨࡧ࡮࡯ࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᝏ")] = bstack1ll111l1lll_opy_
  except Exception as error:
    logger.debug(bstack1l1111l_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡰࡪࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵ࠱ࠤࡊࡸࡲࡰࡴ࠽ࠤࠧᝐ") +  str(error))
def bstack111lllll1_opy_(driver, bstack1ll111lllll_opy_):
  try:
    setattr(driver, bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡆ࠷࠱ࡺࡕ࡫ࡳࡺࡲࡤࡔࡥࡤࡲࠬᝑ"), True)
    session = driver.session_id
    if session:
      bstack1ll11l1l111_opy_ = True
      current_url = driver.current_url
      try:
        url = urlparse(current_url)
      except Exception as e:
        bstack1ll11l1l111_opy_ = False
      bstack1ll11l1l111_opy_ = url.scheme in [bstack1l1111l_opy_ (u"ࠨࡨࡵࡶࡳࠦᝒ"), bstack1l1111l_opy_ (u"ࠢࡩࡶࡷࡴࡸࠨᝓ")]
      if bstack1ll11l1l111_opy_:
        if bstack1ll111lllll_opy_:
          logger.info(bstack1l1111l_opy_ (u"ࠣࡕࡨࡸࡺࡶࠠࡧࡱࡵࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡹ࡫ࡳࡵ࡫ࡱ࡫ࠥ࡮ࡡࡴࠢࡶࡸࡦࡸࡴࡦࡦ࠱ࠤࡆࡻࡴࡰ࡯ࡤࡸࡪࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦࠢࡨࡼࡪࡩࡵࡵ࡫ࡲࡲࠥࡽࡩ࡭࡮ࠣࡦࡪ࡭ࡩ࡯ࠢࡰࡳࡲ࡫࡮ࡵࡣࡵ࡭ࡱࡿ࠮ࠣ᝔"))
      return bstack1ll111lllll_opy_
  except Exception as e:
    logger.error(bstack1l1111l_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡵࡷࡥࡷࡺࡩ࡯ࡩࠣࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡴࡥࡤࡲࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡵࡧࡶࡸࠥࡩࡡࡴࡧ࠽ࠤࠧ᝕") + str(e))
    return False
def bstack111llll1_opy_(driver, name, path):
  try:
    bstack1ll111l1ll1_opy_ = {
        bstack1l1111l_opy_ (u"ࠪࡸ࡭࡚ࡥࡴࡶࡕࡹࡳ࡛ࡵࡪࡦࠪ᝖"): threading.current_thread().current_test_uuid,
        bstack1l1111l_opy_ (u"ࠫࡹ࡮ࡂࡶ࡫࡯ࡨ࡚ࡻࡩࡥࠩ᝗"): os.environ.get(bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪ᝘"), bstack1l1111l_opy_ (u"࠭ࠧ᝙")),
        bstack1l1111l_opy_ (u"ࠧࡵࡪࡍࡻࡹ࡚࡯࡬ࡧࡱࠫ᝚"): os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡊࡘࡆࡤࡐࡗࡕࠩ᝛"), bstack1l1111l_opy_ (u"ࠩࠪ᝜"))
    }
    bstack111ll11lll_opy_ = bstack1ll1111ll1_opy_.bstack111ll11l1l_opy_(EVENTS.bstack1l111l111l_opy_.value)
    bstack1ll1111ll1_opy_.mark(bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥ᝝"))
    logger.debug(bstack1l1111l_opy_ (u"ࠫࡕ࡫ࡲࡧࡱࡵࡱ࡮ࡴࡧࠡࡵࡦࡥࡳࠦࡢࡦࡨࡲࡶࡪࠦࡳࡢࡸ࡬ࡲ࡬ࠦࡲࡦࡵࡸࡰࡹࡹࠧ᝞"))
    try:
      logger.debug(driver.execute_async_script(bstack1l1llll1l1_opy_.perform_scan, {bstack1l1111l_opy_ (u"ࠧࡳࡥࡵࡪࡲࡨࠧ᝟"): name}))
      bstack1ll1111ll1_opy_.end(bstack111ll11lll_opy_, bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠨ࠺ࡴࡶࡤࡶࡹࠨᝠ"), bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠢ࠻ࡧࡱࡨࠧᝡ"), True, None)
    except Exception as error:
      bstack1ll1111ll1_opy_.end(bstack111ll11lll_opy_, bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣᝢ"), bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠤ࠽ࡩࡳࡪࠢᝣ"), False, str(error))
    bstack111ll11lll_opy_ = bstack1ll1111ll1_opy_.bstack111ll11l1l_opy_(EVENTS.bstack1111ll111l_opy_.value)
    bstack1ll1111ll1_opy_.mark(bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥᝤ"))
    try:
      logger.debug(driver.execute_async_script(bstack1l1llll1l1_opy_.bstack1ll11ll111l_opy_, bstack1ll111l1ll1_opy_))
      bstack1ll1111ll1_opy_.end(bstack111ll11lll_opy_, bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠦ࠿ࡹࡴࡢࡴࡷࠦᝥ"), bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠧࡀࡥ࡯ࡦࠥᝦ"),True, None)
    except Exception as error:
      bstack1ll1111ll1_opy_.end(bstack111ll11lll_opy_, bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠨ࠺ࡴࡶࡤࡶࡹࠨᝧ"), bstack111ll11lll_opy_ + bstack1l1111l_opy_ (u"ࠢ࠻ࡧࡱࡨࠧᝨ"),False, str(error))
    logger.info(bstack1l1111l_opy_ (u"ࠣࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡶࡨࡷࡹ࡯࡮ࡨࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫ࠠࡩࡣࡶࠤࡪࡴࡤࡦࡦ࠱ࠦᝩ"))
  except Exception as bstack1ll111ll1l1_opy_:
    logger.error(bstack1l1111l_opy_ (u"ࠤࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡢࡦࠢࡳࡶࡴࡩࡥࡴࡵࡨࡨࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦ࠼ࠣࠦᝪ") + str(path) + bstack1l1111l_opy_ (u"ࠥࠤࡊࡸࡲࡰࡴࠣ࠾ࠧᝫ") + str(bstack1ll111ll1l1_opy_))