# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import sys
import logging
import tarfile
import io
import os
import requests
import re
from requests_toolbelt.multipart.encoder import MultipartEncoder
from bstack_utils.constants import bstack1111l11l1l_opy_, bstack1111l1l1ll_opy_
import tempfile
import json
bstack1ll1llll1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡧࡩࡧࡻࡧ࠯࡮ࡲ࡫ࠬᗇ"))
def get_logger(name=__name__, level=None):
  logger = logging.getLogger(name)
  if level:
    logging.basicConfig(
      level=level,
      format=bstack1l1111l_opy_ (u"ࠫࡡࡴࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤࡠࠫࠨ࡯ࡣࡰࡩ࠮ࡹ࡝࡜ࠧࠫࡰࡪࡼࡥ࡭ࡰࡤࡱࡪ࠯ࡳ࡞ࠢ࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩᗈ"),
      datefmt=bstack1l1111l_opy_ (u"ࠬࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧᗉ"),
      stream=sys.stdout
    )
  return logger
def bstack1ll1lllll11_opy_():
  global bstack1ll1llll1l1_opy_
  if os.path.exists(bstack1ll1llll1l1_opy_):
    os.remove(bstack1ll1llll1l1_opy_)
def bstack1l11ll1lll_opy_():
  for handler in logging.getLogger().handlers:
    logging.getLogger().removeHandler(handler)
def bstack1lllll1lll_opy_(config, log_level):
  bstack1ll1lllll1l_opy_ = log_level
  if bstack1l1111l_opy_ (u"࠭࡬ࡰࡩࡏࡩࡻ࡫࡬ࠨᗊ") in config and config[bstack1l1111l_opy_ (u"ࠧ࡭ࡱࡪࡐࡪࡼࡥ࡭ࠩᗋ")] in bstack1111l11l1l_opy_:
    bstack1ll1lllll1l_opy_ = bstack1111l11l1l_opy_[config[bstack1l1111l_opy_ (u"ࠨ࡮ࡲ࡫ࡑ࡫ࡶࡦ࡮ࠪᗌ")]]
  if config.get(bstack1l1111l_opy_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡄࡹࡹࡵࡃࡢࡲࡷࡹࡷ࡫ࡌࡰࡩࡶࠫᗍ"), False):
    logging.getLogger().setLevel(bstack1ll1lllll1l_opy_)
    return bstack1ll1lllll1l_opy_
  global bstack1ll1llll1l1_opy_
  bstack1l11ll1lll_opy_()
  bstack1lll1111lll_opy_ = logging.Formatter(
    fmt=bstack1l1111l_opy_ (u"ࠪࡠࡳࠫࠨࡢࡵࡦࡸ࡮ࡳࡥࠪࡵࠣ࡟ࠪ࠮࡮ࡢ࡯ࡨ࠭ࡸࡣ࡛ࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࡝ࠡ࠯ࠣࠩ࠭ࡳࡥࡴࡵࡤ࡫ࡪ࠯ࡳࠨᗎ"),
    datefmt=bstack1l1111l_opy_ (u"ࠫࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ᗏ")
  )
  bstack1lll1111111_opy_ = logging.StreamHandler(sys.stdout)
  file_handler = logging.FileHandler(bstack1ll1llll1l1_opy_)
  file_handler.setFormatter(bstack1lll1111lll_opy_)
  bstack1lll1111111_opy_.setFormatter(bstack1lll1111lll_opy_)
  file_handler.setLevel(logging.DEBUG)
  bstack1lll1111111_opy_.setLevel(log_level)
  file_handler.addFilter(lambda r: r.name != bstack1l1111l_opy_ (u"ࠬࡹࡥ࡭ࡧࡱ࡭ࡺࡳ࠮ࡸࡧࡥࡨࡷ࡯ࡶࡦࡴ࠱ࡶࡪࡳ࡯ࡵࡧ࠱ࡶࡪࡳ࡯ࡵࡧࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠧᗐ"))
  logging.getLogger().setLevel(logging.DEBUG)
  bstack1lll1111111_opy_.setLevel(bstack1ll1lllll1l_opy_)
  logging.getLogger().addHandler(bstack1lll1111111_opy_)
  logging.getLogger().addHandler(file_handler)
  return bstack1ll1lllll1l_opy_
def bstack1lll1111ll1_opy_(config):
  try:
    bstack1lll111111l_opy_ = set(bstack1111l1l1ll_opy_)
    bstack1lll1111l1l_opy_ = bstack1l1111l_opy_ (u"࠭ࠧᗑ")
    with open(bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡹ࡮࡮ࠪᗒ")) as bstack1ll1llll1ll_opy_:
      bstack1lll1111l11_opy_ = bstack1ll1llll1ll_opy_.read()
      bstack1lll1111l1l_opy_ = re.sub(bstack1l1111l_opy_ (u"ࡳࠩࡡࠬࡡࡹࠫࠪࡁࠦ࠲࠯ࠪ࡜࡯ࠩᗓ"), bstack1l1111l_opy_ (u"ࠩࠪᗔ"), bstack1lll1111l11_opy_, flags=re.M)
      bstack1lll1111l1l_opy_ = re.sub(
        bstack1l1111l_opy_ (u"ࡵࠫࡣ࠮࡜ࡴ࠭ࠬࡃ࠭࠭ᗕ") + bstack1l1111l_opy_ (u"ࠫࢁ࠭ᗖ").join(bstack1lll111111l_opy_) + bstack1l1111l_opy_ (u"ࠬ࠯࠮ࠫࠦࠪᗗ"),
        bstack1l1111l_opy_ (u"ࡸࠧ࡝࠴࠽ࠤࡠࡘࡅࡅࡃࡆࡘࡊࡊ࡝ࠨᗘ"),
        bstack1lll1111l1l_opy_, flags=re.M | re.I
      )
    def bstack1ll1lllllll_opy_(dic):
      bstack1lll11111ll_opy_ = {}
      for key, value in dic.items():
        if key in bstack1lll111111l_opy_:
          bstack1lll11111ll_opy_[key] = bstack1l1111l_opy_ (u"ࠧ࡜ࡔࡈࡈࡆࡉࡔࡆࡆࡠࠫᗙ")
        else:
          if isinstance(value, dict):
            bstack1lll11111ll_opy_[key] = bstack1ll1lllllll_opy_(value)
          else:
            bstack1lll11111ll_opy_[key] = value
      return bstack1lll11111ll_opy_
    bstack1lll11111ll_opy_ = bstack1ll1lllllll_opy_(config)
    return {
      bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡺ࡯࡯ࠫᗚ"): bstack1lll1111l1l_opy_,
      bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡳࡧ࡬ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬᗛ"): json.dumps(bstack1lll11111ll_opy_)
    }
  except Exception as e:
    return {}
def bstack11lllll1_opy_(config):
  global bstack1ll1llll1l1_opy_
  try:
    if config.get(bstack1l1111l_opy_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡅࡺࡺ࡯ࡄࡣࡳࡸࡺࡸࡥࡍࡱࡪࡷࠬᗜ"), False):
      return
    uuid = os.getenv(bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩᗝ"))
    if not uuid or uuid == bstack1l1111l_opy_ (u"ࠬࡴࡵ࡭࡮ࠪᗞ"):
      return
    bstack1ll1llllll1_opy_ = [bstack1l1111l_opy_ (u"࠭ࡲࡦࡳࡸ࡭ࡷ࡫࡭ࡦࡰࡷࡷ࠳ࡺࡸࡵࠩᗟ"), bstack1l1111l_opy_ (u"ࠧࡑ࡫ࡳࡪ࡮ࡲࡥࠨᗠ"), bstack1l1111l_opy_ (u"ࠨࡲࡼࡴࡷࡵࡪࡦࡥࡷ࠲ࡹࡵ࡭࡭ࠩᗡ"), bstack1ll1llll1l1_opy_]
    bstack1l11ll1lll_opy_()
    logging.shutdown()
    output_file = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠯࡯ࡳ࡬ࡹ࠭ࠨᗢ") + uuid + bstack1l1111l_opy_ (u"ࠪ࠲ࡹࡧࡲ࠯ࡩࡽࠫᗣ"))
    with tarfile.open(output_file, bstack1l1111l_opy_ (u"ࠦࡼࡀࡧࡻࠤᗤ")) as archive:
      for file in filter(lambda f: os.path.exists(f), bstack1ll1llllll1_opy_):
        try:
          archive.add(file,  arcname=os.path.basename(file))
        except:
          pass
      for name, data in bstack1lll1111ll1_opy_(config).items():
        tarinfo = tarfile.TarInfo(name)
        bstack1lll11111l1_opy_ = data.encode()
        tarinfo.size = len(bstack1lll11111l1_opy_)
        archive.addfile(tarinfo, io.BytesIO(bstack1lll11111l1_opy_))
    multipart_data = MultipartEncoder(
      fields= {
        bstack1l1111l_opy_ (u"ࠬࡪࡡࡵࡣࠪᗥ"): (os.path.basename(output_file), open(os.path.abspath(output_file), bstack1l1111l_opy_ (u"࠭ࡲࡣࠩᗦ")), bstack1l1111l_opy_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡨࡼ࡬ࡴࠬᗧ")),
        bstack1l1111l_opy_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡃࡷ࡬ࡰࡩ࡛ࡵࡪࡦࠪᗨ"): uuid
      }
    )
    response = requests.post(
      bstack1l1111l_opy_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡹࡵࡲ࡯ࡢࡦ࠰ࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡣ࡭࡫ࡨࡲࡹ࠳࡬ࡰࡩࡶ࠳ࡺࡶ࡬ࡰࡣࡧࠦᗩ"),
      data=multipart_data,
      headers={bstack1l1111l_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᗪ"): multipart_data.content_type},
      auth=(config[bstack1l1111l_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ᗫ")], config[bstack1l1111l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨᗬ")])
    )
    os.remove(output_file)
    if response.status_code != 200:
      get_logger().debug(bstack1l1111l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥࡻࡰ࡭ࡱࡤࡨࠥࡲ࡯ࡨࡵ࠽ࠤࠬᗭ") + response.status_code)
  except Exception as e:
    get_logger().debug(bstack1l1111l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡦࡰࡧ࡭ࡳ࡭ࠠ࡭ࡱࡪࡷ࠿࠭ᗮ") + str(e))
  finally:
    try:
      bstack1ll1lllll11_opy_()
    except:
      pass