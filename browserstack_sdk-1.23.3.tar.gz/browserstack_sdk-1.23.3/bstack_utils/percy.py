# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
import re
import sys
import json
import time
import shutil
import tempfile
import requests
import subprocess
from threading import Thread
from os.path import expanduser
from bstack_utils.constants import *
from requests.auth import HTTPBasicAuth
from bstack_utils.helper import bstack111l1l1ll_opy_, bstack1ll1l11111_opy_
from bstack_utils.measure import measure
class bstack1111l1ll1_opy_:
  working_dir = os.getcwd()
  bstack1l11ll1ll_opy_ = False
  config = {}
  binary_path = bstack1l1111l_opy_ (u"ࠨࠩᘮ")
  bstack1ll11ll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠩࠪᘯ")
  bstack1111lll11_opy_ = False
  bstack1ll1l1l1111_opy_ = None
  bstack1ll1l1ll111_opy_ = {}
  bstack1ll1l1l1l1l_opy_ = 300
  bstack1ll1l1ll11l_opy_ = False
  logger = None
  bstack1ll11ll11l1_opy_ = False
  bstack1l11ll11l1_opy_ = False
  bstack1ll1l1ll1_opy_ = None
  bstack1ll11ll1ll1_opy_ = bstack1l1111l_opy_ (u"ࠪࠫᘰ")
  bstack1ll1l1l1l11_opy_ = {
    bstack1l1111l_opy_ (u"ࠫࡨ࡮ࡲࡰ࡯ࡨࠫᘱ") : 1,
    bstack1l1111l_opy_ (u"ࠬ࡬ࡩࡳࡧࡩࡳࡽ࠭ᘲ") : 2,
    bstack1l1111l_opy_ (u"࠭ࡥࡥࡩࡨࠫᘳ") : 3,
    bstack1l1111l_opy_ (u"ࠧࡴࡣࡩࡥࡷ࡯ࠧᘴ") : 4
  }
  def __init__(self) -> None: pass
  def bstack1ll1l1lll11_opy_(self):
    bstack1ll11lll11l_opy_ = bstack1l1111l_opy_ (u"ࠨࠩᘵ")
    bstack1ll1ll1111l_opy_ = sys.platform
    bstack1ll11llll1l_opy_ = bstack1l1111l_opy_ (u"ࠩࡳࡩࡷࡩࡹࠨᘶ")
    if re.match(bstack1l1111l_opy_ (u"ࠥࡨࡦࡸࡷࡪࡰࡿࡱࡦࡩࠠࡰࡵࠥᘷ"), bstack1ll1ll1111l_opy_) != None:
      bstack1ll11lll11l_opy_ = bstack1111l1l1l1_opy_ + bstack1l1111l_opy_ (u"ࠦ࠴ࡶࡥࡳࡥࡼ࠱ࡴࡹࡸ࠯ࡼ࡬ࡴࠧᘸ")
      self.bstack1ll11ll1ll1_opy_ = bstack1l1111l_opy_ (u"ࠬࡳࡡࡤࠩᘹ")
    elif re.match(bstack1l1111l_opy_ (u"ࠨ࡭ࡴࡹ࡬ࡲࢁࡳࡳࡺࡵࡿࡱ࡮ࡴࡧࡸࡾࡦࡽ࡬ࡽࡩ࡯ࡾࡥࡧࡨࡽࡩ࡯ࡾࡺ࡭ࡳࡩࡥࡽࡧࡰࡧࢁࡽࡩ࡯࠵࠵ࠦᘺ"), bstack1ll1ll1111l_opy_) != None:
      bstack1ll11lll11l_opy_ = bstack1111l1l1l1_opy_ + bstack1l1111l_opy_ (u"ࠢ࠰ࡲࡨࡶࡨࡿ࠭ࡸ࡫ࡱ࠲ࡿ࡯ࡰࠣᘻ")
      bstack1ll11llll1l_opy_ = bstack1l1111l_opy_ (u"ࠣࡲࡨࡶࡨࡿ࠮ࡦࡺࡨࠦᘼ")
      self.bstack1ll11ll1ll1_opy_ = bstack1l1111l_opy_ (u"ࠩࡺ࡭ࡳ࠭ᘽ")
    else:
      bstack1ll11lll11l_opy_ = bstack1111l1l1l1_opy_ + bstack1l1111l_opy_ (u"ࠥ࠳ࡵ࡫ࡲࡤࡻ࠰ࡰ࡮ࡴࡵࡹ࠰ࡽ࡭ࡵࠨᘾ")
      self.bstack1ll11ll1ll1_opy_ = bstack1l1111l_opy_ (u"ࠫࡱ࡯࡮ࡶࡺࠪᘿ")
    return bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_
  def bstack1ll1l11l1ll_opy_(self):
    try:
      bstack1ll1l1l11ll_opy_ = [os.path.join(expanduser(bstack1l1111l_opy_ (u"ࠧࢄࠢᙀ")), bstack1l1111l_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ᙁ")), self.working_dir, tempfile.gettempdir()]
      for path in bstack1ll1l1l11ll_opy_:
        if(self.bstack1ll1l111l11_opy_(path)):
          return path
      raise bstack1l1111l_opy_ (u"ࠢࡖࡰࡤࡰࡧ࡫ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡶࡥࡳࡥࡼࠤࡧ࡯࡮ࡢࡴࡼࠦᙂ")
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤ࡫࡯࡮ࡥࠢࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡶࡡࡵࡪࠣࡪࡴࡸࠠࡱࡧࡵࡧࡾࠦࡤࡰࡹࡱࡰࡴࡧࡤ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࠳ࠠࡼࡿࠥᙃ").format(e))
  def bstack1ll1l111l11_opy_(self, path):
    try:
      if not os.path.exists(path):
        os.makedirs(path)
      return True
    except:
      return False
  @measure(event_name=EVENTS.bstack1111l111ll_opy_, stage=STAGE.SINGLE)
  def bstack1ll11lll1ll_opy_(self, bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_):
    try:
      bstack1ll1ll111l1_opy_ = self.bstack1ll1l11l1ll_opy_()
      bstack1ll1l11l111_opy_ = os.path.join(bstack1ll1ll111l1_opy_, bstack1l1111l_opy_ (u"ࠩࡳࡩࡷࡩࡹ࠯ࡼ࡬ࡴࠬᙄ"))
      bstack1ll1l111ll1_opy_ = os.path.join(bstack1ll1ll111l1_opy_, bstack1ll11llll1l_opy_)
      if os.path.exists(bstack1ll1l111ll1_opy_):
        self.logger.info(bstack1l1111l_opy_ (u"ࠥࡔࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺࠢࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࢀࢃࠬࠡࡵ࡮࡭ࡵࡶࡩ࡯ࡩࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠧᙅ").format(bstack1ll1l111ll1_opy_))
        return bstack1ll1l111ll1_opy_
      if os.path.exists(bstack1ll1l11l111_opy_):
        self.logger.info(bstack1l1111l_opy_ (u"ࠦࡕ࡫ࡲࡤࡻࠣࡾ࡮ࡶࠠࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࡾࢁ࠱ࠦࡵ࡯ࡼ࡬ࡴࡵ࡯࡮ࡨࠤᙆ").format(bstack1ll1l11l111_opy_))
        return self.bstack1ll1l1llll1_opy_(bstack1ll1l11l111_opy_, bstack1ll11llll1l_opy_)
      self.logger.info(bstack1l1111l_opy_ (u"ࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡴࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺࠢࡩࡶࡴࡳࠠࡼࡿࠥᙇ").format(bstack1ll11lll11l_opy_))
      response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"࠭ࡇࡆࡖࠪᙈ"), bstack1ll11lll11l_opy_, {}, {})
      if response.status_code == 200:
        with open(bstack1ll1l11l111_opy_, bstack1l1111l_opy_ (u"ࠧࡸࡤࠪᙉ")) as file:
          file.write(response.content)
        self.logger.info(bstack1l1111l_opy_ (u"ࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡶࡥࡳࡥࡼࠤࡧ࡯࡮ࡢࡴࡼࠤࡦࡴࡤࠡࡵࡤࡺࡪࡪࠠࡢࡶࠣࡿࢂࠨᙊ").format(bstack1ll1l11l111_opy_))
        return self.bstack1ll1l1llll1_opy_(bstack1ll1l11l111_opy_, bstack1ll11llll1l_opy_)
      else:
        raise(bstack1l1111l_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤ࡫࡯࡬ࡦ࠰ࠣࡗࡹࡧࡴࡶࡵࠣࡧࡴࡪࡥ࠻ࠢࡾࢁࠧᙋ").format(response.status_code))
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡨࡶࡨࡿࠠࡣ࡫ࡱࡥࡷࡿ࠺ࠡࡽࢀࠦᙌ").format(e))
  def bstack1ll1l1l111l_opy_(self, bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_):
    try:
      retry = 2
      bstack1ll1l111ll1_opy_ = None
      bstack1ll1ll11111_opy_ = False
      while retry > 0:
        bstack1ll1l111ll1_opy_ = self.bstack1ll11lll1ll_opy_(bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_)
        bstack1ll1ll11111_opy_ = self.bstack1ll11ll1lll_opy_(bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_, bstack1ll1l111ll1_opy_)
        if bstack1ll1ll11111_opy_:
          break
        retry -= 1
      return bstack1ll1l111ll1_opy_, bstack1ll1ll11111_opy_
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡨࡧࡷࠤࡵ࡫ࡲࡤࡻࠣࡦ࡮ࡴࡡࡳࡻࠣࡴࡦࡺࡨࠣᙍ").format(e))
    return bstack1ll1l111ll1_opy_, False
  def bstack1ll11ll1lll_opy_(self, bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_, bstack1ll1l111ll1_opy_, bstack1ll1l1111l1_opy_ = 0):
    if bstack1ll1l1111l1_opy_ > 1:
      return False
    if bstack1ll1l111ll1_opy_ == None or os.path.exists(bstack1ll1l111ll1_opy_) == False:
      self.logger.warn(bstack1l1111l_opy_ (u"ࠧࡖࡥࡳࡥࡼࠤࡵࡧࡴࡩࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠱ࠦࡲࡦࡶࡵࡽ࡮ࡴࡧࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠥᙎ"))
      return False
    bstack1ll1l11ll11_opy_ = bstack1l1111l_opy_ (u"ࠨ࡞࠯ࠬࡃࡴࡪࡸࡣࡺ࡞࠲ࡧࡱ࡯ࠠ࡝ࡦ࠱ࡠࡩ࠱࠮࡝ࡦ࠮ࠦᙏ")
    command = bstack1l1111l_opy_ (u"ࠧࡼࡿࠣ࠱࠲ࡼࡥࡳࡵ࡬ࡳࡳ࠭ᙐ").format(bstack1ll1l111ll1_opy_)
    bstack1ll1l111l1l_opy_ = subprocess.check_output(command, shell=True, text=True)
    if re.match(bstack1ll1l11ll11_opy_, bstack1ll1l111l1l_opy_) != None:
      return True
    else:
      self.logger.error(bstack1l1111l_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡷࡧࡵࡷ࡮ࡵ࡮ࠡࡥ࡫ࡩࡨࡱࠠࡧࡣ࡬ࡰࡪࡪࠢᙑ"))
      return False
  def bstack1ll1l1llll1_opy_(self, bstack1ll1l11l111_opy_, bstack1ll11llll1l_opy_):
    try:
      working_dir = os.path.dirname(bstack1ll1l11l111_opy_)
      shutil.unpack_archive(bstack1ll1l11l111_opy_, working_dir)
      bstack1ll1l111ll1_opy_ = os.path.join(working_dir, bstack1ll11llll1l_opy_)
      os.chmod(bstack1ll1l111ll1_opy_, 0o755)
      return bstack1ll1l111ll1_opy_
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡻ࡮ࡻ࡫ࡳࠤࡵ࡫ࡲࡤࡻࠣࡦ࡮ࡴࡡࡳࡻࠥᙒ"))
  def bstack1ll1l11l11l_opy_(self):
    try:
      bstack1ll1ll11l11_opy_ = self.config.get(bstack1l1111l_opy_ (u"ࠪࡴࡪࡸࡣࡺࠩᙓ"))
      bstack1ll1l11l11l_opy_ = bstack1ll1ll11l11_opy_ or (bstack1ll1ll11l11_opy_ is None and self.bstack1l11ll1ll_opy_)
      if not bstack1ll1l11l11l_opy_ or self.config.get(bstack1l1111l_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧᙔ"), None) not in bstack11111llll1_opy_:
        return False
      self.bstack1111lll11_opy_ = True
      return True
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡩࡴࠡࡲࡨࡶࡨࡿࠬࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࢀࢃࠢᙕ").format(e))
  def bstack1ll1l1ll1l1_opy_(self):
    try:
      bstack1ll1l1ll1l1_opy_ = self.bstack1ll1l111111_opy_
      return bstack1ll1l1ll1l1_opy_
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡧࡩࡹ࡫ࡣࡵࠢࡳࡩࡷࡩࡹࠡࡥࡤࡴࡹࡻࡲࡦࠢࡰࡳࡩ࡫ࠬࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࢀࢃࠢᙖ").format(e))
  def init(self, bstack1l11ll1ll_opy_, config, logger):
    self.bstack1l11ll1ll_opy_ = bstack1l11ll1ll_opy_
    self.config = config
    self.logger = logger
    if not self.bstack1ll1l11l11l_opy_():
      return
    self.bstack1ll1l1ll111_opy_ = config.get(bstack1l1111l_opy_ (u"ࠧࡱࡧࡵࡧࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᙗ"), {})
    self.bstack1ll1l111111_opy_ = config.get(bstack1l1111l_opy_ (u"ࠨࡲࡨࡶࡨࡿࡃࡢࡲࡷࡹࡷ࡫ࡍࡰࡦࡨࠫᙘ"))
    try:
      bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_ = self.bstack1ll1l1lll11_opy_()
      bstack1ll1l111ll1_opy_, bstack1ll1ll11111_opy_ = self.bstack1ll1l1l111l_opy_(bstack1ll11lll11l_opy_, bstack1ll11llll1l_opy_)
      if bstack1ll1ll11111_opy_:
        self.binary_path = bstack1ll1l111ll1_opy_
        thread = Thread(target=self.bstack1ll1ll111ll_opy_)
        thread.start()
      else:
        self.bstack1ll11ll11l1_opy_ = True
        self.logger.error(bstack1l1111l_opy_ (u"ࠤࡌࡲࡻࡧ࡬ࡪࡦࠣࡴࡪࡸࡣࡺࠢࡳࡥࡹ࡮ࠠࡧࡱࡸࡲࡩࠦ࠭ࠡࡽࢀ࠰࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡑࡧࡵࡧࡾࠨᙙ").format(bstack1ll1l111ll1_opy_))
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡽࢀࠦᙚ").format(e))
  def bstack1ll1l1lll1l_opy_(self):
    try:
      logfile = os.path.join(self.working_dir, bstack1l1111l_opy_ (u"ࠫࡱࡵࡧࠨᙛ"), bstack1l1111l_opy_ (u"ࠬࡶࡥࡳࡥࡼ࠲ࡱࡵࡧࠨᙜ"))
      os.makedirs(os.path.dirname(logfile)) if not os.path.exists(os.path.dirname(logfile)) else None
      self.logger.debug(bstack1l1111l_opy_ (u"ࠨࡐࡶࡵ࡫࡭ࡳ࡭ࠠࡱࡧࡵࡧࡾࠦ࡬ࡰࡩࡶࠤࡦࡺࠠࡼࡿࠥᙝ").format(logfile))
      self.bstack1ll11ll1l1l_opy_ = logfile
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡪࡺࠠࡱࡧࡵࡧࡾࠦ࡬ࡰࡩࠣࡴࡦࡺࡨ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࢁࡽࠣᙞ").format(e))
  @measure(event_name=EVENTS.bstack1111l11lll_opy_, stage=STAGE.SINGLE)
  def bstack1ll1ll111ll_opy_(self):
    bstack1ll11ll1l11_opy_ = self.bstack1ll1l1111ll_opy_()
    if bstack1ll11ll1l11_opy_ == None:
      self.bstack1ll11ll11l1_opy_ = True
      self.logger.error(bstack1l1111l_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡵࡱ࡮ࡩࡳࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥ࠮ࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼࠦᙟ"))
      return False
    command_args = [bstack1l1111l_opy_ (u"ࠤࡤࡴࡵࡀࡥࡹࡧࡦ࠾ࡸࡺࡡࡳࡶࠥᙠ") if self.bstack1l11ll1ll_opy_ else bstack1l1111l_opy_ (u"ࠪࡩࡽ࡫ࡣ࠻ࡵࡷࡥࡷࡺࠧᙡ")]
    bstack1ll11llllll_opy_ = self.bstack1ll11lll111_opy_()
    if bstack1ll11llllll_opy_ != None:
      command_args.append(bstack1l1111l_opy_ (u"ࠦ࠲ࡩࠠࡼࡿࠥᙢ").format(bstack1ll11llllll_opy_))
    env = os.environ.copy()
    env[bstack1l1111l_opy_ (u"ࠧࡖࡅࡓࡅ࡜ࡣ࡙ࡕࡋࡆࡐࠥᙣ")] = bstack1ll11ll1l11_opy_
    env[bstack1l1111l_opy_ (u"ࠨࡔࡉࡡࡅ࡙ࡎࡒࡄࡠࡗࡘࡍࡉࠨᙤ")] = os.environ.get(bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬᙥ"), bstack1l1111l_opy_ (u"ࠨࠩᙦ"))
    bstack1ll1l1lllll_opy_ = [self.binary_path]
    self.bstack1ll1l1lll1l_opy_()
    self.bstack1ll1l1l1111_opy_ = self.bstack1ll11ll11ll_opy_(bstack1ll1l1lllll_opy_ + command_args, env)
    self.logger.debug(bstack1l1111l_opy_ (u"ࠤࡖࡸࡦࡸࡴࡪࡰࡪࠤࡍ࡫ࡡ࡭ࡶ࡫ࠤࡈ࡮ࡥࡤ࡭ࠥᙧ"))
    bstack1ll1l1111l1_opy_ = 0
    while self.bstack1ll1l1l1111_opy_.poll() == None:
      bstack1ll1l1ll1ll_opy_ = self.bstack1ll1l11ll1l_opy_()
      if bstack1ll1l1ll1ll_opy_:
        self.logger.debug(bstack1l1111l_opy_ (u"ࠥࡌࡪࡧ࡬ࡵࡪࠣࡇ࡭࡫ࡣ࡬ࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࠨᙨ"))
        self.bstack1ll1l1ll11l_opy_ = True
        return True
      bstack1ll1l1111l1_opy_ += 1
      self.logger.debug(bstack1l1111l_opy_ (u"ࠦࡍ࡫ࡡ࡭ࡶ࡫ࠤࡈ࡮ࡥࡤ࡭ࠣࡖࡪࡺࡲࡺࠢ࠰ࠤࢀࢃࠢᙩ").format(bstack1ll1l1111l1_opy_))
      time.sleep(2)
    self.logger.error(bstack1l1111l_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡱࡧࡵࡧࡾ࠲ࠠࡉࡧࡤࡰࡹ࡮ࠠࡄࡪࡨࡧࡰࠦࡆࡢ࡫࡯ࡩࡩࠦࡡࡧࡶࡨࡶࠥࢁࡽࠡࡣࡷࡸࡪࡳࡰࡵࡵࠥᙪ").format(bstack1ll1l1111l1_opy_))
    self.bstack1ll11ll11l1_opy_ = True
    return False
  def bstack1ll1l11ll1l_opy_(self, bstack1ll1l1111l1_opy_ = 0):
    if bstack1ll1l1111l1_opy_ > 10:
      return False
    try:
      bstack1ll1l11lll1_opy_ = os.environ.get(bstack1l1111l_opy_ (u"࠭ࡐࡆࡔࡆ࡝ࡤ࡙ࡅࡓࡘࡈࡖࡤࡇࡄࡅࡔࡈࡗࡘ࠭ᙫ"), bstack1l1111l_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠸࠹࠸ࠨᙬ"))
      bstack1ll11lll1l1_opy_ = bstack1ll1l11lll1_opy_ + bstack1111ll1l11_opy_
      response = requests.get(bstack1ll11lll1l1_opy_)
      data = response.json()
      self.bstack1ll1l1ll1_opy_ = data.get(bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࠧ᙭"), {}).get(bstack1l1111l_opy_ (u"ࠩ࡬ࡨࠬ᙮"), None)
      return True
    except:
      self.logger.debug(bstack1l1111l_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡲࡧࡨࡻࡲࡳࡧࡧࠤࡼ࡮ࡩ࡭ࡧࠣࡴࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡩࡧࡤࡰࡹ࡮ࠠࡤࡪࡨࡧࡰࠦࡲࡦࡵࡳࡳࡳࡹࡥࠣᙯ"))
      return False
  def bstack1ll1l1111ll_opy_(self):
    bstack1ll1l11111l_opy_ = bstack1l1111l_opy_ (u"ࠫࡦࡶࡰࠨᙰ") if self.bstack1l11ll1ll_opy_ else bstack1l1111l_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡫ࠧᙱ")
    bstack1ll1l111lll_opy_ = bstack1l1111l_opy_ (u"ࠨࡵ࡯ࡦࡨࡪ࡮ࡴࡥࡥࠤᙲ") if self.config.get(bstack1l1111l_opy_ (u"ࠧࡱࡧࡵࡧࡾ࠭ᙳ")) is None else True
    bstack1lll111llll_opy_ = bstack1l1111l_opy_ (u"ࠣࡣࡳ࡭࠴ࡧࡰࡱࡡࡳࡩࡷࡩࡹ࠰ࡩࡨࡸࡤࡶࡲࡰ࡬ࡨࡧࡹࡥࡴࡰ࡭ࡨࡲࡄࡴࡡ࡮ࡧࡀࡿࢂࠬࡴࡺࡲࡨࡁࢀࢃࠦࡱࡧࡵࡧࡾࡃࡻࡾࠤᙴ").format(self.config[bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧᙵ")], bstack1ll1l11111l_opy_, bstack1ll1l111lll_opy_)
    if self.bstack1ll1l111111_opy_:
      bstack1lll111llll_opy_ += bstack1l1111l_opy_ (u"ࠥࠪࡵ࡫ࡲࡤࡻࡢࡧࡦࡶࡴࡶࡴࡨࡣࡲࡵࡤࡦ࠿ࡾࢁࠧᙶ").format(self.bstack1ll1l111111_opy_)
    uri = bstack111l1l1ll_opy_(bstack1lll111llll_opy_)
    try:
      response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠫࡌࡋࡔࠨᙷ"), uri, {}, {bstack1l1111l_opy_ (u"ࠬࡧࡵࡵࡪࠪᙸ"): (self.config[bstack1l1111l_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨᙹ")], self.config[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪᙺ")])})
      if response.status_code == 200:
        data = response.json()
        self.bstack1111lll11_opy_ = data.get(bstack1l1111l_opy_ (u"ࠨࡵࡸࡧࡨ࡫ࡳࡴࠩᙻ"))
        self.bstack1ll1l111111_opy_ = data.get(bstack1l1111l_opy_ (u"ࠩࡳࡩࡷࡩࡹࡠࡥࡤࡴࡹࡻࡲࡦࡡࡰࡳࡩ࡫ࠧᙼ"))
        os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡉࡗࡉ࡙ࠨᙽ")] = str(self.bstack1111lll11_opy_)
        os.environ[bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡊࡘࡃ࡚ࡡࡆࡅࡕ࡚ࡕࡓࡇࡢࡑࡔࡊࡅࠨᙾ")] = str(self.bstack1ll1l111111_opy_)
        if bstack1ll1l111lll_opy_ == bstack1l1111l_opy_ (u"ࠧࡻ࡮ࡥࡧࡩ࡭ࡳ࡫ࡤࠣᙿ") and str(self.bstack1111lll11_opy_).lower() == bstack1l1111l_opy_ (u"ࠨࡴࡳࡷࡨࠦ "):
          self.bstack1l11ll11l1_opy_ = True
        if bstack1l1111l_opy_ (u"ࠢࡵࡱ࡮ࡩࡳࠨᚁ") in data:
          return data[bstack1l1111l_opy_ (u"ࠣࡶࡲ࡯ࡪࡴࠢᚂ")]
        else:
          raise bstack1l1111l_opy_ (u"ࠩࡗࡳࡰ࡫࡮ࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠤ࠲ࠦࡻࡾࠩᚃ").format(data)
      else:
        raise bstack1l1111l_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡦࡦࡶࡦ࡬ࠥࡶࡥࡳࡥࡼࠤࡹࡵ࡫ࡦࡰ࠯ࠤࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡳࡵࡣࡷࡹࡸࠦ࠭ࠡࡽࢀ࠰ࠥࡘࡥࡴࡲࡲࡲࡸ࡫ࠠࡃࡱࡧࡽࠥ࠳ࠠࡼࡿࠥᚄ").format(response.status_code, response.json())
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡧࡷ࡫ࡡࡵ࡫ࡱ࡫ࠥࡶࡥࡳࡥࡼࠤࡵࡸ࡯࡫ࡧࡦࡸࠧᚅ").format(e))
  def bstack1ll11lll111_opy_(self):
    bstack1ll1l11l1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"ࠧࡶࡥࡳࡥࡼࡇࡴࡴࡦࡪࡩ࠱࡮ࡸࡵ࡮ࠣᚆ"))
    try:
      if bstack1l1111l_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧᚇ") not in self.bstack1ll1l1ll111_opy_:
        self.bstack1ll1l1ll111_opy_[bstack1l1111l_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨᚈ")] = 2
      with open(bstack1ll1l11l1l1_opy_, bstack1l1111l_opy_ (u"ࠨࡹࠪᚉ")) as fp:
        json.dump(self.bstack1ll1l1ll111_opy_, fp)
      return bstack1ll1l11l1l1_opy_
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡩࡲࡦࡣࡷࡩࠥࡶࡥࡳࡥࡼࠤࡨࡵ࡮ࡧ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤᚊ").format(e))
  def bstack1ll11ll11ll_opy_(self, cmd, env = os.environ.copy()):
    try:
      if self.bstack1ll11ll1ll1_opy_ == bstack1l1111l_opy_ (u"ࠪࡻ࡮ࡴࠧᚋ"):
        bstack1ll1l1l1ll1_opy_ = [bstack1l1111l_opy_ (u"ࠫࡨࡳࡤ࠯ࡧࡻࡩࠬᚌ"), bstack1l1111l_opy_ (u"ࠬ࠵ࡣࠨᚍ")]
        cmd = bstack1ll1l1l1ll1_opy_ + cmd
      cmd = bstack1l1111l_opy_ (u"࠭ࠠࠨᚎ").join(cmd)
      self.logger.debug(bstack1l1111l_opy_ (u"ࠢࡓࡷࡱࡲ࡮ࡴࡧࠡࡽࢀࠦᚏ").format(cmd))
      with open(self.bstack1ll11ll1l1l_opy_, bstack1l1111l_opy_ (u"ࠣࡣࠥᚐ")) as bstack1ll11lllll1_opy_:
        process = subprocess.Popen(cmd, shell=True, stdout=bstack1ll11lllll1_opy_, text=True, stderr=bstack1ll11lllll1_opy_, env=env, universal_newlines=True)
      return process
    except Exception as e:
      self.bstack1ll11ll11l1_opy_ = True
      self.logger.error(bstack1l1111l_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡵ࡫ࡲࡤࡻࠣࡻ࡮ࡺࡨࠡࡥࡰࡨࠥ࠳ࠠࡼࡿ࠯ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡽࢀࠦᚑ").format(cmd, e))
  def shutdown(self):
    try:
      if self.bstack1ll1l1ll11l_opy_:
        self.logger.info(bstack1l1111l_opy_ (u"ࠥࡗࡹࡵࡰࡱ࡫ࡱ࡫ࠥࡖࡥࡳࡥࡼࠦᚒ"))
        cmd = [self.binary_path, bstack1l1111l_opy_ (u"ࠦࡪࡾࡥࡤ࠼ࡶࡸࡴࡶࠢᚓ")]
        self.bstack1ll11ll11ll_opy_(cmd)
        self.bstack1ll1l1ll11l_opy_ = False
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡷࡳࡵࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡸ࡫ࡷ࡬ࠥࡩ࡯࡮࡯ࡤࡲࡩࠦ࠭ࠡࡽࢀ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡾࢁࠧᚔ").format(cmd, e))
  def bstack1l11llll1_opy_(self):
    if not self.bstack1111lll11_opy_:
      return
    try:
      bstack1ll1l11llll_opy_ = 0
      while not self.bstack1ll1l1ll11l_opy_ and bstack1ll1l11llll_opy_ < self.bstack1ll1l1l1l1l_opy_:
        if self.bstack1ll11ll11l1_opy_:
          self.logger.info(bstack1l1111l_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡹࡥࡵࡷࡳࠤ࡫ࡧࡩ࡭ࡧࡧࠦᚕ"))
          return
        time.sleep(1)
        bstack1ll1l11llll_opy_ += 1
      os.environ[bstack1l1111l_opy_ (u"ࠧࡑࡇࡕࡇ࡞ࡥࡂࡆࡕࡗࡣࡕࡒࡁࡕࡈࡒࡖࡒ࠭ᚖ")] = str(self.bstack1ll1l1l11l1_opy_())
      self.logger.info(bstack1l1111l_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡴࡧࡷࡹࡵࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠤᚗ"))
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡹࡥࡵࡷࡳࠤࡵ࡫ࡲࡤࡻ࠯ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡼࡿࠥᚘ").format(e))
  def bstack1ll1l1l11l1_opy_(self):
    if self.bstack1l11ll1ll_opy_:
      return
    try:
      bstack1ll11llll11_opy_ = [platform[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨᚙ")].lower() for platform in self.config.get(bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧᚚ"), [])]
      bstack1ll1ll11ll1_opy_ = sys.maxsize
      bstack1ll1l1l1lll_opy_ = bstack1l1111l_opy_ (u"ࠬ࠭᚛")
      for browser in bstack1ll11llll11_opy_:
        if browser in self.bstack1ll1l1l1l11_opy_:
          bstack1ll1ll11l1l_opy_ = self.bstack1ll1l1l1l11_opy_[browser]
        if bstack1ll1ll11l1l_opy_ < bstack1ll1ll11ll1_opy_:
          bstack1ll1ll11ll1_opy_ = bstack1ll1ll11l1l_opy_
          bstack1ll1l1l1lll_opy_ = browser
      return bstack1ll1l1l1lll_opy_
    except Exception as e:
      self.logger.error(bstack1l1111l_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡩ࡭ࡳࡪࠠࡣࡧࡶࡸࠥࡶ࡬ࡢࡶࡩࡳࡷࡳࠬࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࢀࢃࠢ᚜").format(e))
  @classmethod
  def bstack1l1ll1l11l_opy_(self):
    return os.getenv(bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡆࡔࡆ࡝ࠬ᚝"), bstack1l1111l_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ᚞")).lower()
  @classmethod
  def bstack111lll11ll_opy_(self):
    return os.getenv(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒࡈࡖࡈ࡟࡟ࡄࡃࡓࡘ࡚ࡘࡅࡠࡏࡒࡈࡊ࠭᚟"), bstack1l1111l_opy_ (u"ࠪࠫᚠ"))