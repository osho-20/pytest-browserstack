# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import re
from bstack_utils.bstack1llll11ll_opy_ import bstack111l1l1lll_opy_
def bstack1111111l1l_opy_(fixture_name):
    if fixture_name.startswith(bstack1l1111l_opy_ (u"ࠫࡤࡾࡵ࡯࡫ࡷࡣࡸ࡫ࡴࡶࡲࡢࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭፠")):
        return bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡷࡳ࠱࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭፡")
    elif fixture_name.startswith(bstack1l1111l_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡳࡦࡶࡸࡴࡤࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭።")):
        return bstack1l1111l_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠳࡭ࡰࡦࡸࡰࡪ࠭፣")
    elif fixture_name.startswith(bstack1l1111l_opy_ (u"ࠨࡡࡻࡹࡳ࡯ࡴࡠࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭፤")):
        return bstack1l1111l_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱ࠱࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭፥")
    elif fixture_name.startswith(bstack1l1111l_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨ፦")):
        return bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠳࡭ࡰࡦࡸࡰࡪ࠭፧")
def bstack111111l11l_opy_(fixture_name):
    return bool(re.match(bstack1l1111l_opy_ (u"ࠬࡤ࡟ࡹࡷࡱ࡭ࡹࡥࠨࡴࡧࡷࡹࡵࢂࡴࡦࡣࡵࡨࡴࡽ࡮ࠪࡡࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࢁࡳ࡯ࡥࡷ࡯ࡩ࠮ࡥࡦࡪࡺࡷࡹࡷ࡫࡟࠯ࠬࠪ፨"), fixture_name))
def bstack1111111lll_opy_(fixture_name):
    return bool(re.match(bstack1l1111l_opy_ (u"࠭࡞ࡠࡺࡸࡲ࡮ࡺ࡟ࠩࡵࡨࡸࡺࡶࡼࡵࡧࡤࡶࡩࡵࡷ࡯ࠫࡢࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࡣ࠳࠰ࠧ፩"), fixture_name))
def bstack1111111111_opy_(fixture_name):
    return bool(re.match(bstack1l1111l_opy_ (u"ࠧ࡟ࡡࡻࡹࡳ࡯ࡴࡠࠪࡶࡩࡹࡻࡰࡽࡶࡨࡥࡷࡪ࡯ࡸࡰࠬࡣࡨࡲࡡࡴࡵࡢࡪ࡮ࡾࡴࡶࡴࡨࡣ࠳࠰ࠧ፪"), fixture_name))
def bstack11111111ll_opy_(fixture_name):
    if fixture_name.startswith(bstack1l1111l_opy_ (u"ࠨࡡࡻࡹࡳ࡯ࡴࡠࡵࡨࡸࡺࡶ࡟ࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠪ፫")):
        return bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡻࡰ࠮ࡨࡸࡲࡨࡺࡩࡰࡰࠪ፬"), bstack1l1111l_opy_ (u"ࠪࡆࡊࡌࡏࡓࡇࡢࡉࡆࡉࡈࠨ፭")
    elif fixture_name.startswith(bstack1l1111l_opy_ (u"ࠫࡤࡾࡵ࡯࡫ࡷࡣࡸ࡫ࡴࡶࡲࡢࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࠫ፮")):
        return bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡷࡳ࠱ࡲࡵࡤࡶ࡮ࡨࠫ፯"), bstack1l1111l_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡁࡍࡎࠪ፰")
    elif fixture_name.startswith(bstack1l1111l_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬ፱")):
        return bstack1l1111l_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰ࠰ࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ፲"), bstack1l1111l_opy_ (u"ࠩࡄࡊ࡙ࡋࡒࡠࡇࡄࡇࡍ࠭፳")
    elif fixture_name.startswith(bstack1l1111l_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲࡤࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭፴")):
        return bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠳࡭ࡰࡦࡸࡰࡪ࠭፵"), bstack1l1111l_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡆࡒࡌࠨ፶")
    return None, None
def bstack1111111ll1_opy_(hook_name):
    if hook_name in [bstack1l1111l_opy_ (u"࠭ࡳࡦࡶࡸࡴࠬ፷"), bstack1l1111l_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࠩ፸")]:
        return hook_name.capitalize()
    return hook_name
def bstack111111ll11_opy_(hook_name):
    if hook_name in [bstack1l1111l_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ፹"), bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡻࡰࡠ࡯ࡨࡸ࡭ࡵࡤࠨ፺")]:
        return bstack1l1111l_opy_ (u"ࠪࡆࡊࡌࡏࡓࡇࡢࡉࡆࡉࡈࠨ፻")
    elif hook_name in [bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡱࡴࡪࡵ࡭ࡧࠪ፼"), bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡨࡲࡡࡴࡵࠪ፽")]:
        return bstack1l1111l_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡁࡍࡎࠪ፾")
    elif hook_name in [bstack1l1111l_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡩࡹࡳࡩࡴࡪࡱࡱࠫ፿"), bstack1l1111l_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡱࡪࡺࡨࡰࡦࠪᎀ")]:
        return bstack1l1111l_opy_ (u"ࠩࡄࡊ࡙ࡋࡒࡠࡇࡄࡇࡍ࠭ᎁ")
    elif hook_name in [bstack1l1111l_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡳ࡯ࡥࡷ࡯ࡩࠬᎂ"), bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥࡣ࡭ࡣࡶࡷࠬᎃ")]:
        return bstack1l1111l_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡆࡒࡌࠨᎄ")
    return hook_name
def bstack111111l111_opy_(node, scenario):
    if hasattr(node, bstack1l1111l_opy_ (u"࠭ࡣࡢ࡮࡯ࡷࡵ࡫ࡣࠨᎅ")):
        parts = node.nodeid.rsplit(bstack1l1111l_opy_ (u"ࠢ࡜ࠤᎆ"))
        params = parts[-1]
        return bstack1l1111l_opy_ (u"ࠣࡽࢀࠤࡠࢁࡽࠣᎇ").format(scenario.name, params)
    return scenario.name
def bstack11111111l1_opy_(node):
    try:
        examples = []
        if hasattr(node, bstack1l1111l_opy_ (u"ࠩࡦࡥࡱࡲࡳࡱࡧࡦࠫᎈ")):
            examples = list(node.callspec.params[bstack1l1111l_opy_ (u"ࠪࡣࡵࡿࡴࡦࡵࡷࡣࡧࡪࡤࡠࡧࡻࡥࡲࡶ࡬ࡦࠩᎉ")].values())
        return examples
    except:
        return []
def bstack111111l1l1_opy_(feature, scenario):
    return list(feature.tags) + list(scenario.tags)
def bstack1111111l11_opy_(report):
    try:
        status = bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᎊ")
        if report.passed or (report.failed and hasattr(report, bstack1l1111l_opy_ (u"ࠧࡽࡡࡴࡺࡩࡥ࡮ࡲࠢᎋ"))):
            status = bstack1l1111l_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ᎌ")
        elif report.skipped:
            status = bstack1l1111l_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨᎍ")
        bstack111l1l1lll_opy_(status)
    except:
        pass
def bstack1l111l11l_opy_(status):
    try:
        bstack111111111l_opy_ = bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᎎ")
        if status == bstack1l1111l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩᎏ"):
            bstack111111111l_opy_ = bstack1l1111l_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪ᎐")
        elif status == bstack1l1111l_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬ᎑"):
            bstack111111111l_opy_ = bstack1l1111l_opy_ (u"ࠬࡹ࡫ࡪࡲࡳࡩࡩ࠭᎒")
        bstack111l1l1lll_opy_(bstack111111111l_opy_)
    except:
        pass
def bstack111111l1ll_opy_(item=None, report=None, summary=None, extra=None):
    return