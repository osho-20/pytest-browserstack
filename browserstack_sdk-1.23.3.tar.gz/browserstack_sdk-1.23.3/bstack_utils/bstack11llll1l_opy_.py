# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
from uuid import uuid4
from bstack_utils.helper import bstack1llll111_opy_, bstack1llll11ll11_opy_
from bstack_utils.bstack11l11lll1l_opy_ import bstack11111111l1_opy_
class bstack11lll1ll_opy_:
    def __init__(self, name=None, code=None, uuid=None, file_path=None, bstack1l1l11ll_opy_=None, framework=None, tags=[], scope=[], bstack1ll1lll11ll_opy_=None, bstack1ll1lll11l1_opy_=True, bstack1ll1lll1l11_opy_=None, bstack11llllll11_opy_=None, result=None, duration=None, bstack1ll1ll11_opy_=None, meta={}):
        self.bstack1ll1ll11_opy_ = bstack1ll1ll11_opy_
        self.name = name
        self.code = code
        self.file_path = file_path
        self.uuid = uuid
        if not self.uuid and bstack1ll1lll11l1_opy_:
            self.uuid = uuid4().__str__()
        self.bstack1l1l11ll_opy_ = bstack1l1l11ll_opy_
        self.framework = framework
        self.tags = tags
        self.scope = scope
        self.bstack1ll1lll11ll_opy_ = bstack1ll1lll11ll_opy_
        self.bstack1ll1lll1l11_opy_ = bstack1ll1lll1l11_opy_
        self.bstack11llllll11_opy_ = bstack11llllll11_opy_
        self.result = result
        self.duration = duration
        self.meta = meta
        self.hooks = []
    def bstack1l1lll1l_opy_(self):
        if self.uuid:
            return self.uuid
        self.uuid = uuid4().__str__()
        return self.uuid
    def bstack11ll11l1_opy_(self, meta):
        self.meta = meta
    def bstack11ll11ll_opy_(self, hooks):
        self.hooks = hooks
    def bstack1ll1ll1l11l_opy_(self):
        bstack1ll1ll1l1l1_opy_ = os.path.relpath(self.file_path, start=os.getcwd())
        return {
            bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫᗯ"): bstack1ll1ll1l1l1_opy_,
            bstack1l1111l_opy_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫᗰ"): bstack1ll1ll1l1l1_opy_,
            bstack1l1111l_opy_ (u"ࠪࡺࡨࡥࡦࡪ࡮ࡨࡴࡦࡺࡨࠨᗱ"): bstack1ll1ll1l1l1_opy_
        }
    def set(self, **kwargs):
        for key, val in kwargs.items():
            if not hasattr(self, key):
                raise TypeError(bstack1l1111l_opy_ (u"࡚ࠦࡴࡥࡹࡲࡨࡧࡹ࡫ࡤࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶ࠽ࠤࠧᗲ") + key)
            setattr(self, key, val)
    def bstack1ll1ll1llll_opy_(self):
        return {
            bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᗳ"): self.name,
            bstack1l1111l_opy_ (u"࠭ࡢࡰࡦࡼࠫᗴ"): {
                bstack1l1111l_opy_ (u"ࠧ࡭ࡣࡱ࡫ࠬᗵ"): bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨᗶ"),
                bstack1l1111l_opy_ (u"ࠩࡦࡳࡩ࡫ࠧᗷ"): self.code
            },
            bstack1l1111l_opy_ (u"ࠪࡷࡨࡵࡰࡦࡵࠪᗸ"): self.scope,
            bstack1l1111l_opy_ (u"ࠫࡹࡧࡧࡴࠩᗹ"): self.tags,
            bstack1l1111l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨᗺ"): self.framework,
            bstack1l1111l_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᗻ"): self.bstack1l1l11ll_opy_
        }
    def bstack1ll1ll1ll1l_opy_(self):
        return {
         bstack1l1111l_opy_ (u"ࠧ࡮ࡧࡷࡥࠬᗼ"): self.meta
        }
    def bstack1ll1lll1lll_opy_(self):
        return {
            bstack1l1111l_opy_ (u"ࠨࡥࡸࡷࡹࡵ࡭ࡓࡧࡵࡹࡳࡖࡡࡳࡣࡰࠫᗽ"): {
                bstack1l1111l_opy_ (u"ࠩࡵࡩࡷࡻ࡮ࡠࡰࡤࡱࡪ࠭ᗾ"): self.bstack1ll1lll11ll_opy_
            }
        }
    def bstack1ll1lll1111_opy_(self, bstack1ll1llll111_opy_, details):
        step = next(filter(lambda st: st[bstack1l1111l_opy_ (u"ࠪ࡭ࡩ࠭ᗿ")] == bstack1ll1llll111_opy_, self.meta[bstack1l1111l_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪᘀ")]), None)
        step.update(details)
    def bstack11l1ll1l_opy_(self, bstack1ll1llll111_opy_):
        step = next(filter(lambda st: st[bstack1l1111l_opy_ (u"ࠬ࡯ࡤࠨᘁ")] == bstack1ll1llll111_opy_, self.meta[bstack1l1111l_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬᘂ")]), None)
        step.update({
            bstack1l1111l_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫᘃ"): bstack1llll111_opy_()
        })
    def bstack1lllll11_opy_(self, bstack1ll1llll111_opy_, result, duration=None):
        bstack1ll1lll1l11_opy_ = bstack1llll111_opy_()
        if bstack1ll1llll111_opy_ is not None and self.meta.get(bstack1l1111l_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧᘄ")):
            step = next(filter(lambda st: st[bstack1l1111l_opy_ (u"ࠩ࡬ࡨࠬᘅ")] == bstack1ll1llll111_opy_, self.meta[bstack1l1111l_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᘆ")]), None)
            step.update({
                bstack1l1111l_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᘇ"): bstack1ll1lll1l11_opy_,
                bstack1l1111l_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧᘈ"): duration if duration else bstack1llll11ll11_opy_(step[bstack1l1111l_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᘉ")], bstack1ll1lll1l11_opy_),
                bstack1l1111l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᘊ"): result.result,
                bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࠩᘋ"): str(result.exception) if result.exception else None
            })
    def add_step(self, bstack1ll1ll1ll11_opy_):
        if self.meta.get(bstack1l1111l_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨᘌ")):
            self.meta[bstack1l1111l_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᘍ")].append(bstack1ll1ll1ll11_opy_)
        else:
            self.meta[bstack1l1111l_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪᘎ")] = [ bstack1ll1ll1ll11_opy_ ]
    def bstack1ll1ll1l111_opy_(self):
        return {
            bstack1l1111l_opy_ (u"ࠬࡻࡵࡪࡦࠪᘏ"): self.bstack1l1lll1l_opy_(),
            **self.bstack1ll1ll1llll_opy_(),
            **self.bstack1ll1ll1l11l_opy_(),
            **self.bstack1ll1ll1ll1l_opy_()
        }
    def bstack1ll1llll11l_opy_(self):
        if not self.result:
            return {}
        data = {
            bstack1l1111l_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᘐ"): self.bstack1ll1lll1l11_opy_,
            bstack1l1111l_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᘑ"): self.duration,
            bstack1l1111l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᘒ"): self.result.result
        }
        if data[bstack1l1111l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᘓ")] == bstack1l1111l_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᘔ"):
            data[bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࡤࡺࡹࡱࡧࠪᘕ")] = self.result.bstack111ll1l11l_opy_()
            data[bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ᘖ")] = [{bstack1l1111l_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩᘗ"): self.result.bstack1llll1l1l11_opy_()}]
        return data
    def bstack1ll1lll1l1l_opy_(self):
        return {
            bstack1l1111l_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᘘ"): self.bstack1l1lll1l_opy_(),
            **self.bstack1ll1ll1llll_opy_(),
            **self.bstack1ll1ll1l11l_opy_(),
            **self.bstack1ll1llll11l_opy_(),
            **self.bstack1ll1ll1ll1l_opy_()
        }
    def bstack1ll111ll_opy_(self, event, result=None):
        if result:
            self.result = result
        if bstack1l1111l_opy_ (u"ࠨࡕࡷࡥࡷࡺࡥࡥࠩᘙ") in event:
            return self.bstack1ll1ll1l111_opy_()
        elif bstack1l1111l_opy_ (u"ࠩࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᘚ") in event:
            return self.bstack1ll1lll1l1l_opy_()
    def bstack1ll11ll1_opy_(self):
        pass
    def stop(self, time=None, duration=None, result=None):
        self.bstack1ll1lll1l11_opy_ = time if time else bstack1llll111_opy_()
        self.duration = duration if duration else bstack1llll11ll11_opy_(self.bstack1l1l11ll_opy_, self.bstack1ll1lll1l11_opy_)
        if result:
            self.result = result
class bstack1l1l1lll_opy_(bstack11lll1ll_opy_):
    def __init__(self, hooks=[], bstack1ll1l11l_opy_={}, *args, **kwargs):
        self.hooks = hooks
        self.bstack1ll1l11l_opy_ = bstack1ll1l11l_opy_
        super().__init__(*args, **kwargs, bstack11llllll11_opy_=bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࠨᘛ"))
    @classmethod
    def bstack1ll1lll1ll1_opy_(cls, scenario, feature, test, **kwargs):
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1l1111l_opy_ (u"ࠫ࡮ࡪࠧᘜ"): id(step),
                bstack1l1111l_opy_ (u"ࠬࡺࡥࡹࡶࠪᘝ"): step.name,
                bstack1l1111l_opy_ (u"࠭࡫ࡦࡻࡺࡳࡷࡪࠧᘞ"): step.keyword,
            })
        return bstack1l1l1lll_opy_(
            **kwargs,
            meta={
                bstack1l1111l_opy_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࠨᘟ"): {
                    bstack1l1111l_opy_ (u"ࠨࡰࡤࡱࡪ࠭ᘠ"): feature.name,
                    bstack1l1111l_opy_ (u"ࠩࡳࡥࡹ࡮ࠧᘡ"): feature.filename,
                    bstack1l1111l_opy_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨᘢ"): feature.description
                },
                bstack1l1111l_opy_ (u"ࠫࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭ᘣ"): {
                    bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᘤ"): scenario.name
                },
                bstack1l1111l_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬᘥ"): steps,
                bstack1l1111l_opy_ (u"ࠧࡦࡺࡤࡱࡵࡲࡥࡴࠩᘦ"): bstack11111111l1_opy_(test)
            }
        )
    def bstack1ll1ll1lll1_opy_(self):
        return {
            bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᘧ"): self.hooks
        }
    def bstack1ll1ll11lll_opy_(self):
        if self.bstack1ll1l11l_opy_:
            return {
                bstack1l1111l_opy_ (u"ࠩ࡬ࡲࡹ࡫ࡧࡳࡣࡷ࡭ࡴࡴࡳࠨᘨ"): self.bstack1ll1l11l_opy_
            }
        return {}
    def bstack1ll1lll1l1l_opy_(self):
        return {
            **super().bstack1ll1lll1l1l_opy_(),
            **self.bstack1ll1ll1lll1_opy_()
        }
    def bstack1ll1ll1l111_opy_(self):
        return {
            **super().bstack1ll1ll1l111_opy_(),
            **self.bstack1ll1ll11lll_opy_()
        }
    def bstack1ll11ll1_opy_(self):
        return bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬᘩ")
class bstack1ll11l1l_opy_(bstack11lll1ll_opy_):
    def __init__(self, hook_type, *args,bstack1ll1l11l_opy_={}, **kwargs):
        self.hook_type = hook_type
        self.bstack1ll1ll1l1ll_opy_ = None
        self.bstack1ll1l11l_opy_ = bstack1ll1l11l_opy_
        super().__init__(*args, **kwargs, bstack11llllll11_opy_=bstack1l1111l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᘪ"))
    def bstack1l111l1l_opy_(self):
        return self.hook_type
    def bstack1ll1lll111l_opy_(self):
        return {
            bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨᘫ"): self.hook_type
        }
    def bstack1ll1lll1l1l_opy_(self):
        return {
            **super().bstack1ll1lll1l1l_opy_(),
            **self.bstack1ll1lll111l_opy_()
        }
    def bstack1ll1ll1l111_opy_(self):
        return {
            **super().bstack1ll1ll1l111_opy_(),
            bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠ࡫ࡧࠫᘬ"): self.bstack1ll1ll1l1ll_opy_,
            **self.bstack1ll1lll111l_opy_()
        }
    def bstack1ll11ll1_opy_(self):
        return bstack1l1111l_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࠩᘭ")
    def bstack11ll1111_opy_(self, bstack1ll1ll1l1ll_opy_):
        self.bstack1ll1ll1l1ll_opy_ = bstack1ll1ll1l1ll_opy_