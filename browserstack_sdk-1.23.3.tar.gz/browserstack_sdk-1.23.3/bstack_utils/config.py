# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
conf = {
    bstack1l1111l_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨྭ"): False,
    bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡢࡷࡪࡹࡳࡪࡱࡱࠫྮ"): True,
    bstack1l1111l_opy_ (u"ࠫࡸࡱࡩࡱࡡࡶࡩࡸࡹࡩࡰࡰࡢࡷࡹࡧࡴࡶࡵࠪྯ"): False
}
class Config(object):
    instance = None
    def __init__(self):
        self._111l1ll11l_opy_ = conf
    @classmethod
    def bstack111l1111_opy_(cls):
        if cls.instance:
            return cls.instance
        return Config()
    def get_property(self, property_name):
        return self._111l1ll11l_opy_.get(property_name, None)
    def set_property(self, property_name, bstack111l1ll1l1_opy_):
        self._111l1ll11l_opy_[property_name] = bstack111l1ll1l1_opy_
    def bstack1l1l111l11_opy_(self, val):
        self._111l1ll11l_opy_[bstack1l1111l_opy_ (u"ࠬࡹ࡫ࡪࡲࡢࡷࡪࡹࡳࡪࡱࡱࡣࡸࡺࡡࡵࡷࡶࠫྰ")] = bool(val)
    def bstack111111l1_opy_(self):
        return self._111l1ll11l_opy_.get(bstack1l1111l_opy_ (u"࠭ࡳ࡬࡫ࡳࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡤࡹࡴࡢࡶࡸࡷࠬྱ"), False)