# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import json
import logging
import os
import datetime
import threading
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack1lll1l11l11_opy_, bstack1lll11l1l1l_opy_, bstack1ll1l11111_opy_, bstack11llllll_opy_, bstack1llll1lllll_opy_, bstack1llll1l1111_opy_, bstack1lll11l11l1_opy_, bstack1llll111_opy_
from bstack_utils.measure import measure
from bstack_utils.bstack11111l111l_opy_ import bstack1lllll1l111_opy_
import bstack_utils.bstack11111ll1l_opy_ as bstack1lllllll1l_opy_
from bstack_utils.bstack11ll1l1l_opy_ import bstack1l11l1ll_opy_
import bstack_utils.accessibility as bstack1111ll11_opy_
from bstack_utils.bstack1l1llll1l1_opy_ import bstack1l1llll1l1_opy_
from bstack_utils.bstack11llll1l_opy_ import bstack11lll1ll_opy_
bstack1ll11111l1l_opy_ = bstack1l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡯࡭࡮ࡨࡧࡹࡵࡲ࠮ࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠫᝬ")
logger = logging.getLogger(__name__)
class bstack1l11l1l1_opy_:
    bstack11111l111l_opy_ = None
    bs_config = None
    bstack1lll1lll11_opy_ = None
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    @measure(event_name=EVENTS.bstack1111l11ll1_opy_, stage=STAGE.SINGLE)
    def launch(cls, bs_config, bstack1lll1lll11_opy_):
        cls.bs_config = bs_config
        cls.bstack1lll1lll11_opy_ = bstack1lll1lll11_opy_
        try:
            cls.bstack1l1llll1lll_opy_()
            bstack1ll111l1l11_opy_ = bstack1lll1l11l11_opy_(bs_config)
            bstack1ll111lll1l_opy_ = bstack1lll11l1l1l_opy_(bs_config)
            data = bstack1lllllll1l_opy_.bstack1l1llllll11_opy_(bs_config, bstack1lll1lll11_opy_)
            config = {
                bstack1l1111l_opy_ (u"ࠬࡧࡵࡵࡪࠪ᝭"): (bstack1ll111l1l11_opy_, bstack1ll111lll1l_opy_),
                bstack1l1111l_opy_ (u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧᝮ"): cls.default_headers()
            }
            response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠧࡑࡑࡖࡘࠬᝯ"), cls.request_url(bstack1l1111l_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠲࠰ࡤࡸ࡭ࡱࡪࡳࠨᝰ")), data, config)
            if response.status_code != 200:
                bstack1ll1111111l_opy_ = response.json()
                if bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪ᝱")] == False:
                    cls.bstack1ll1111l1l1_opy_(bstack1ll1111111l_opy_)
                    return
                cls.bstack1ll11111l11_opy_(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪᝲ")])
                cls.bstack1l1lllll1ll_opy_(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᝳ")])
                return None
            bstack1l1lllll111_opy_ = cls.bstack1l1llll1ll1_opy_(response)
            return bstack1l1lllll111_opy_
        except Exception as error:
            logger.error(bstack1l1111l_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡹ࡫࡭ࡱ࡫ࠠࡤࡴࡨࡥࡹ࡯࡮ࡨࠢࡥࡹ࡮ࡲࡤࠡࡨࡲࡶ࡚ࠥࡥࡴࡶࡋࡹࡧࡀࠠࡼࡿࠥ᝴").format(str(error)))
            return None
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    def stop(cls, bstack1ll11111ll1_opy_=None):
        if not bstack1l11l1ll_opy_.on() and not bstack1111ll11_opy_.on():
            return
        if os.environ.get(bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ᝵")) == bstack1l1111l_opy_ (u"ࠢ࡯ࡷ࡯ࡰࠧ᝶") or os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉ࠭᝷")) == bstack1l1111l_opy_ (u"ࠤࡱࡹࡱࡲࠢ᝸"):
            logger.error(bstack1l1111l_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡶࡸࡴࡶࠠࡣࡷ࡬ࡰࡩࠦࡲࡦࡳࡸࡩࡸࡺࠠࡵࡱࠣࡘࡪࡹࡴࡉࡷࡥ࠾ࠥࡓࡩࡴࡵ࡬ࡲ࡬ࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡵࡱ࡮ࡩࡳ࠭᝹"))
            return {
                bstack1l1111l_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫ᝺"): bstack1l1111l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫ᝻"),
                bstack1l1111l_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧ᝼"): bstack1l1111l_opy_ (u"ࠧࡕࡱ࡮ࡩࡳ࠵ࡢࡶ࡫࡯ࡨࡎࡊࠠࡪࡵࠣࡹࡳࡪࡥࡧ࡫ࡱࡩࡩ࠲ࠠࡣࡷ࡬ࡰࡩࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠡ࡯࡬࡫࡭ࡺࠠࡩࡣࡹࡩࠥ࡬ࡡࡪ࡮ࡨࡨࠬ᝽")
            }
        try:
            cls.bstack11111l111l_opy_.shutdown()
            data = {
                bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭᝾"): bstack1llll111_opy_()
            }
            if not bstack1ll11111ll1_opy_ is None:
                data[bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡲ࡫ࡴࡢࡦࡤࡸࡦ࠭᝿")] = [{
                    bstack1l1111l_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪក"): bstack1l1111l_opy_ (u"ࠫࡺࡹࡥࡳࡡ࡮࡭ࡱࡲࡥࡥࠩខ"),
                    bstack1l1111l_opy_ (u"ࠬࡹࡩࡨࡰࡤࡰࠬគ"): bstack1ll11111ll1_opy_
                }]
            config = {
                bstack1l1111l_opy_ (u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧឃ"): cls.default_headers()
            }
            bstack1lll111llll_opy_ = bstack1l1111l_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡷ࡬ࡰࡩࡹ࠯ࡼࡿ࠲ࡷࡹࡵࡰࠨង").format(os.environ[bstack1l1111l_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉࠨច")])
            bstack1ll111l1111_opy_ = cls.request_url(bstack1lll111llll_opy_)
            response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠩࡓ࡙࡙࠭ឆ"), bstack1ll111l1111_opy_, data, config)
            if not response.ok:
                raise Exception(bstack1l1111l_opy_ (u"ࠥࡗࡹࡵࡰࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡱࡳࡹࠦ࡯࡬ࠤជ"))
        except Exception as error:
            logger.error(bstack1l1111l_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡷࡹࡵࡰࠡࡤࡸ࡭ࡱࡪࠠࡳࡧࡴࡹࡪࡹࡴࠡࡶࡲࠤ࡙࡫ࡳࡵࡊࡸࡦ࠿ࡀࠠࠣឈ") + str(error))
            return {
                bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬញ"): bstack1l1111l_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬដ"),
                bstack1l1111l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨឋ"): str(error)
            }
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    def bstack1l1llll1ll1_opy_(cls, response):
        bstack1ll1111111l_opy_ = response.json()
        bstack1l1lllll111_opy_ = {}
        if bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠨ࡬ࡺࡸࠬឌ")) is None:
            os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡊࡘࡖࠪឍ")] = bstack1l1111l_opy_ (u"ࠪࡲࡺࡲ࡬ࠨណ")
        else:
            os.environ[bstack1l1111l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬត")] = bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠬࡰࡷࡵࠩថ"), bstack1l1111l_opy_ (u"࠭࡮ࡶ࡮࡯ࠫទ"))
        os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬធ")] = bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠪន"), bstack1l1111l_opy_ (u"ࠩࡱࡹࡱࡲࠧប"))
        if bstack1l11l1ll_opy_.bstack11111l11ll_opy_(cls.bs_config, cls.bstack1lll1lll11_opy_.get(bstack1l1111l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡵࡴࡧࡧࠫផ"), bstack1l1111l_opy_ (u"ࠫࠬព"))) is True:
            bstack1l1llllllll_opy_, bstack1ll1l1l1l_opy_, bstack1ll1111l11l_opy_ = cls.bstack1ll111111l1_opy_(bstack1ll1111111l_opy_)
            if bstack1l1llllllll_opy_ != None and bstack1ll1l1l1l_opy_ != None:
                bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠬࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠬភ")] = {
                    bstack1l1111l_opy_ (u"࠭ࡪࡸࡶࡢࡸࡴࡱࡥ࡯ࠩម"): bstack1l1llllllll_opy_,
                    bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩយ"): bstack1ll1l1l1l_opy_,
                    bstack1l1111l_opy_ (u"ࠨࡣ࡯ࡰࡴࡽ࡟ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬរ"): bstack1ll1111l11l_opy_
                }
            else:
                bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠩࡲࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩល")] = {}
        else:
            bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪវ")] = {}
        if bstack1111ll11_opy_.bstack1ll11l11ll1_opy_(cls.bs_config) is True:
            bstack1ll1111llll_opy_, bstack1ll1l1l1l_opy_ = cls.bstack1l1llll1l1l_opy_(bstack1ll1111111l_opy_)
            if bstack1ll1111llll_opy_ != None and bstack1ll1l1l1l_opy_ != None:
                bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫឝ")] = {
                    bstack1l1111l_opy_ (u"ࠬࡧࡵࡵࡪࡢࡸࡴࡱࡥ࡯ࠩឞ"): bstack1ll1111llll_opy_,
                    bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨស"): bstack1ll1l1l1l_opy_,
                }
            else:
                bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧហ")] = {}
        else:
            bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨឡ")] = {}
        if bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠩࡲࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩអ")].get(bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬឣ")) != None or bstack1l1lllll111_opy_[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫឤ")].get(bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧឥ")) != None:
            cls.bstack1ll1111ll1l_opy_(bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"࠭ࡪࡸࡶࠪឦ")), bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩឧ")))
        return bstack1l1lllll111_opy_
    @classmethod
    def bstack1ll111111l1_opy_(cls, bstack1ll1111111l_opy_):
        if bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠨࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠨឨ")) == None:
            cls.bstack1ll11111l11_opy_()
            return [None, None, None]
        if bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠩࡲࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩឩ")][bstack1l1111l_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫឪ")] != True:
            cls.bstack1ll11111l11_opy_(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫឫ")])
            return [None, None, None]
        logger.debug(bstack1l1111l_opy_ (u"࡚ࠬࡥࡴࡶࠣࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠣࡆࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡘࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠢࠩឬ"))
        os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡆࡓࡒࡖࡌࡆࡖࡈࡈࠬឭ")] = bstack1l1111l_opy_ (u"ࠧࡵࡴࡸࡩࠬឮ")
        if bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠨ࡬ࡺࡸࠬឯ")):
            os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪឰ")] = bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠪ࡮ࡼࡺࠧឱ")]
            os.environ[bstack1l1111l_opy_ (u"ࠫࡈࡘࡅࡅࡇࡑࡘࡎࡇࡌࡔࡡࡉࡓࡗࡥࡃࡓࡃࡖࡌࡤࡘࡅࡑࡑࡕࡘࡎࡔࡇࠨឲ")] = json.dumps({
                bstack1l1111l_opy_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧឳ"): bstack1lll1l11l11_opy_(cls.bs_config),
                bstack1l1111l_opy_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ឴"): bstack1lll11l1l1l_opy_(cls.bs_config)
            })
        if bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩ឵")):
            os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡍࡇࡓࡉࡇࡇࡣࡎࡊࠧា")] = bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫិ")]
        if bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪី")].get(bstack1l1111l_opy_ (u"ࠫࡴࡶࡴࡪࡱࡱࡷࠬឹ"), {}).get(bstack1l1111l_opy_ (u"ࠬࡧ࡬࡭ࡱࡺࡣࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩឺ")):
            os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡅࡑࡒࡏࡘࡡࡖࡇࡗࡋࡅࡏࡕࡋࡓ࡙࡙ࠧុ")] = str(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠧࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿࠧូ")][bstack1l1111l_opy_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࡴࠩួ")][bstack1l1111l_opy_ (u"ࠩࡤࡰࡱࡵࡷࡠࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭ើ")])
        return [bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠪ࡮ࡼࡺࠧឿ")], bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ៀ")], os.environ[bstack1l1111l_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡄࡐࡑࡕࡗࡠࡕࡆࡖࡊࡋࡎࡔࡊࡒࡘࡘ࠭េ")]]
    @classmethod
    def bstack1l1llll1l1l_opy_(cls, bstack1ll1111111l_opy_):
        if bstack1ll1111111l_opy_.get(bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭ែ")) == None:
            cls.bstack1l1lllll1ll_opy_()
            return [None, None]
        if bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧៃ")][bstack1l1111l_opy_ (u"ࠨࡵࡸࡧࡨ࡫ࡳࡴࠩោ")] != True:
            cls.bstack1l1lllll1ll_opy_(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩៅ")])
            return [None, None]
        if bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪំ")].get(bstack1l1111l_opy_ (u"ࠫࡴࡶࡴࡪࡱࡱࡷࠬះ")):
            logger.debug(bstack1l1111l_opy_ (u"࡚ࠬࡥࡴࡶࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡆࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡘࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠢࠩៈ"))
            parsed = json.loads(os.getenv(bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡢࡅࡈࡉࡅࡔࡕࡌࡆࡎࡒࡉࡕ࡛ࡢࡇࡔࡔࡆࡊࡉࡘࡖࡆ࡚ࡉࡐࡐࡢ࡝ࡒࡒࠧ៉"), bstack1l1111l_opy_ (u"ࠧࡼࡿࠪ៊")))
            capabilities = bstack1lllllll1l_opy_.bstack1ll1111l111_opy_(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ់")][bstack1l1111l_opy_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡵࠪ៌")][bstack1l1111l_opy_ (u"ࠪࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠩ៍")], bstack1l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ៎"), bstack1l1111l_opy_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ៏"))
            bstack1ll1111llll_opy_ = capabilities[bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࡚࡯࡬ࡧࡱࠫ័")]
            os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬ៑")] = bstack1ll1111llll_opy_
            parsed[bstack1l1111l_opy_ (u"ࠨࡵࡦࡥࡳࡴࡥࡳࡘࡨࡶࡸ࡯࡯࡯្ࠩ")] = capabilities[bstack1l1111l_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪ៓")]
            os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫ។")] = json.dumps(parsed)
            scripts = bstack1lllllll1l_opy_.bstack1ll1111l111_opy_(bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ៕")][bstack1l1111l_opy_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡸ࠭៖")][bstack1l1111l_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹࡹࠧៗ")], bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ៘"), bstack1l1111l_opy_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩ៙"))
            bstack1l1llll1l1_opy_.bstack1ll11l1l1l1_opy_(scripts)
            commands = bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩ៚")][bstack1l1111l_opy_ (u"ࠪࡳࡵࡺࡩࡰࡰࡶࠫ៛")][bstack1l1111l_opy_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡸ࡚࡯ࡘࡴࡤࡴࠬៜ")].get(bstack1l1111l_opy_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡹࠧ៝"))
            bstack1l1llll1l1_opy_.bstack1ll11l1lll1_opy_(commands)
            bstack1l1llll1l1_opy_.store()
        return [bstack1ll1111llll_opy_, bstack1ll1111111l_opy_[bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨ៞")]]
    @classmethod
    def bstack1ll11111l11_opy_(cls, response=None):
        os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬ៟")] = bstack1l1111l_opy_ (u"ࠨࡰࡸࡰࡱ࠭០")
        os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡉࡏࡎࡒࡏࡉ࡙ࡋࡄࠨ១")] = bstack1l1111l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩ២")
        os.environ[bstack1l1111l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬ៣")] = bstack1l1111l_opy_ (u"ࠬࡴࡵ࡭࡮ࠪ៤")
        os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡎ࡜࡚ࠧ៥")] = bstack1l1111l_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬ៦")
        os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡍࡇࡓࡉࡇࡇࡣࡎࡊࠧ៧")] = bstack1l1111l_opy_ (u"ࠤࡱࡹࡱࡲࠢ៨")
        os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡂࡎࡏࡓ࡜ࡥࡓࡄࡔࡈࡉࡓ࡙ࡈࡐࡖࡖࠫ៩")] = bstack1l1111l_opy_ (u"ࠦࡳࡻ࡬࡭ࠤ៪")
        cls.bstack1ll1111l1l1_opy_(response, bstack1l1111l_opy_ (u"ࠧࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠧ៫"))
        return [None, None, None]
    @classmethod
    def bstack1l1lllll1ll_opy_(cls, response=None):
        os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡕࡖࡋࡇࠫ៬")] = bstack1l1111l_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬ៭")
        os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭៮")] = bstack1l1111l_opy_ (u"ࠩࡱࡹࡱࡲࠧ៯")
        os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫ៰")] = bstack1l1111l_opy_ (u"ࠫࡳࡻ࡬࡭ࠩ៱")
        cls.bstack1ll1111l1l1_opy_(response, bstack1l1111l_opy_ (u"ࠧࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠧ៲"))
        return [None, None, None]
    @classmethod
    def bstack1ll1111ll1l_opy_(cls, bstack1l1llll1l11_opy_, bstack1ll1l1l1l_opy_):
        os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ៳")] = bstack1l1llll1l11_opy_
        os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬ៴")] = bstack1ll1l1l1l_opy_
    @classmethod
    def bstack1ll1111l1l1_opy_(cls, response=None, product=bstack1l1111l_opy_ (u"ࠣࠤ៵")):
        if response == None:
            logger.error(product + bstack1l1111l_opy_ (u"ࠤࠣࡆࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠦ៶"))
        for error in response[bstack1l1111l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡵࠪ៷")]:
            bstack1lll1lll1ll_opy_ = error[bstack1l1111l_opy_ (u"ࠫࡰ࡫ࡹࠨ៸")]
            error_message = error[bstack1l1111l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭៹")]
            if error_message:
                if bstack1lll1lll1ll_opy_ == bstack1l1111l_opy_ (u"ࠨࡅࡓࡔࡒࡖࡤࡇࡃࡄࡇࡖࡗࡤࡊࡅࡏࡋࡈࡈࠧ៺"):
                    logger.info(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1l1111l_opy_ (u"ࠢࡅࡣࡷࡥࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠠࠣ៻") + product + bstack1l1111l_opy_ (u"ࠣࠢࡩࡥ࡮ࡲࡥࡥࠢࡧࡹࡪࠦࡴࡰࠢࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠨ៼"))
    @classmethod
    def bstack1l1llll1lll_opy_(cls):
        if cls.bstack11111l111l_opy_ is not None:
            return
        cls.bstack11111l111l_opy_ = bstack1lllll1l111_opy_(cls.post_data)
        cls.bstack11111l111l_opy_.start()
    @classmethod
    def bstack1l1111ll_opy_(cls):
        if cls.bstack11111l111l_opy_ is None:
            return
        cls.bstack11111l111l_opy_.shutdown()
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    def post_data(cls, bstack11ll1lll_opy_, bstack1ll1111ll11_opy_=bstack1l1111l_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡥࡹࡩࡨࠨ៽")):
        config = {
            bstack1l1111l_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫ៾"): cls.default_headers()
        }
        response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠫࡕࡕࡓࡕࠩ៿"), cls.request_url(bstack1ll1111ll11_opy_), bstack11ll1lll_opy_, config)
        bstack1ll11l11l11_opy_ = response.json()
    @classmethod
    def bstack1l1ll111_opy_(cls, bstack11ll1lll_opy_, bstack1ll1111ll11_opy_=bstack1l1111l_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡡࡵࡥ࡫ࠫ᠀")):
        if not bstack1lllllll1l_opy_.bstack1ll1111lll1_opy_(bstack11ll1lll_opy_[bstack1l1111l_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ᠁")]):
            return
        bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1lllllll1_opy_(bstack11ll1lll_opy_[bstack1l1111l_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ᠂")], bstack11ll1lll_opy_.get(bstack1l1111l_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࠪ᠃")))
        if bstack111lll1l11_opy_ != None:
            if bstack11ll1lll_opy_.get(bstack1l1111l_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࠫ᠄")) != None:
                bstack11ll1lll_opy_[bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬ᠅")][bstack1l1111l_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸࡤࡳࡡࡱࠩ᠆")] = bstack111lll1l11_opy_
            else:
                bstack11ll1lll_opy_[bstack1l1111l_opy_ (u"ࠬࡶࡲࡰࡦࡸࡧࡹࡥ࡭ࡢࡲࠪ᠇")] = bstack111lll1l11_opy_
        if bstack1ll1111ll11_opy_ == bstack1l1111l_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡢࡢࡶࡦ࡬ࠬ᠈"):
            cls.bstack1l1llll1lll_opy_()
            cls.bstack11111l111l_opy_.add(bstack11ll1lll_opy_)
        elif bstack1ll1111ll11_opy_ == bstack1l1111l_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬ᠉"):
            cls.post_data([bstack11ll1lll_opy_], bstack1ll1111ll11_opy_)
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    @measure(event_name=EVENTS.bstack1111l111l1_opy_, stage=STAGE.SINGLE)
    def bstack11lllll1_opy_(cls, bstack1llll1ll_opy_):
        bstack1l1lllll1l1_opy_ = []
        for log in bstack1llll1ll_opy_:
            bstack1ll111111ll_opy_ = {
                bstack1l1111l_opy_ (u"ࠨ࡭࡬ࡲࡩ࠭᠊"): bstack1l1111l_opy_ (u"ࠩࡗࡉࡘ࡚࡟ࡍࡑࡊࠫ᠋"),
                bstack1l1111l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩ᠌"): log[bstack1l1111l_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪ᠍")],
                bstack1l1111l_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ᠎"): log[bstack1l1111l_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ᠏")],
                bstack1l1111l_opy_ (u"ࠧࡩࡶࡷࡴࡤࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ᠐"): {},
                bstack1l1111l_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ᠑"): log[bstack1l1111l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ᠒")],
            }
            if bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪ᠓") in log:
                bstack1ll111111ll_opy_[bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ᠔")] = log[bstack1l1111l_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ᠕")]
            elif bstack1l1111l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭᠖") in log:
                bstack1ll111111ll_opy_[bstack1l1111l_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ᠗")] = log[bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ᠘")]
            bstack1l1lllll1l1_opy_.append(bstack1ll111111ll_opy_)
        cls.bstack1l1ll111_opy_({
            bstack1l1111l_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭᠙"): bstack1l1111l_opy_ (u"ࠪࡐࡴ࡭ࡃࡳࡧࡤࡸࡪࡪࠧ᠚"),
            bstack1l1111l_opy_ (u"ࠫࡱࡵࡧࡴࠩ᠛"): bstack1l1lllll1l1_opy_
        })
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    def bstack1ll1111l1ll_opy_(cls, steps):
        bstack1ll11111111_opy_ = []
        for step in steps:
            bstack1ll11111lll_opy_ = {
                bstack1l1111l_opy_ (u"ࠬࡱࡩ࡯ࡦࠪ᠜"): bstack1l1111l_opy_ (u"࠭ࡔࡆࡕࡗࡣࡘ࡚ࡅࡑࠩ᠝"),
                bstack1l1111l_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭᠞"): step[bstack1l1111l_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧ᠟")],
                bstack1l1111l_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬᠠ"): step[bstack1l1111l_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ᠡ")],
                bstack1l1111l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᠢ"): step[bstack1l1111l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᠣ")],
                bstack1l1111l_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨᠤ"): step[bstack1l1111l_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩᠥ")]
            }
            if bstack1l1111l_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᠦ") in step:
                bstack1ll11111lll_opy_[bstack1l1111l_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᠧ")] = step[bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᠨ")]
            elif bstack1l1111l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫᠩ") in step:
                bstack1ll11111lll_opy_[bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᠪ")] = step[bstack1l1111l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ᠫ")]
            bstack1ll11111111_opy_.append(bstack1ll11111lll_opy_)
        cls.bstack1l1ll111_opy_({
            bstack1l1111l_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫᠬ"): bstack1l1111l_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨࠬᠭ"),
            bstack1l1111l_opy_ (u"ࠩ࡯ࡳ࡬ࡹࠧᠮ"): bstack1ll11111111_opy_
        })
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    def bstack1l1l1l1l11_opy_(cls, screenshot):
        cls.bstack1l1ll111_opy_({
            bstack1l1111l_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧᠯ"): bstack1l1111l_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨᠰ"),
            bstack1l1111l_opy_ (u"ࠬࡲ࡯ࡨࡵࠪᠱ"): [{
                bstack1l1111l_opy_ (u"࠭࡫ࡪࡰࡧࠫᠲ"): bstack1l1111l_opy_ (u"ࠧࡕࡇࡖࡘࡤ࡙ࡃࡓࡇࡈࡒࡘࡎࡏࡕࠩᠳ"),
                bstack1l1111l_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫᠴ"): datetime.datetime.utcnow().isoformat() + bstack1l1111l_opy_ (u"ࠩ࡝ࠫᠵ"),
                bstack1l1111l_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᠶ"): screenshot[bstack1l1111l_opy_ (u"ࠫ࡮ࡳࡡࡨࡧࠪᠷ")],
                bstack1l1111l_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᠸ"): screenshot[bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ᠹ")]
            }]
        }, bstack1ll1111ll11_opy_=bstack1l1111l_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬᠺ"))
    @classmethod
    @bstack11llllll_opy_(class_method=True)
    def bstack1ll1lll111_opy_(cls, driver):
        current_test_uuid = cls.current_test_uuid()
        if not current_test_uuid:
            return
        cls.bstack1l1ll111_opy_({
            bstack1l1111l_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬᠻ"): bstack1l1111l_opy_ (u"ࠩࡆࡆ࡙࡙ࡥࡴࡵ࡬ࡳࡳࡉࡲࡦࡣࡷࡩࡩ࠭ᠼ"),
            bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬᠽ"): {
                bstack1l1111l_opy_ (u"ࠦࡺࡻࡩࡥࠤᠾ"): cls.current_test_uuid(),
                bstack1l1111l_opy_ (u"ࠧ࡯࡮ࡵࡧࡪࡶࡦࡺࡩࡰࡰࡶࠦᠿ"): cls.bstack1ll1ll1l_opy_(driver)
            }
        })
    @classmethod
    def bstack1l1l11l1_opy_(cls, event: str, bstack11ll1lll_opy_: bstack11lll1ll_opy_):
        bstack1ll1lll1_opy_ = {
            bstack1l1111l_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪᡀ"): event,
            bstack11ll1lll_opy_.bstack1ll11ll1_opy_(): bstack11ll1lll_opy_.bstack1ll111ll_opy_(event)
        }
        cls.bstack1l1ll111_opy_(bstack1ll1lll1_opy_)
        result = getattr(bstack11ll1lll_opy_, bstack1l1111l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᡁ"), None)
        if event == bstack1l1111l_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩᡂ"):
            threading.current_thread().bstackTestMeta = {bstack1l1111l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩᡃ"): bstack1l1111l_opy_ (u"ࠪࡴࡪࡴࡤࡪࡰࡪࠫᡄ")}
        elif event == bstack1l1111l_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ᡅ"):
            threading.current_thread().bstackTestMeta = {bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬᡆ"): getattr(result, bstack1l1111l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᡇ"), bstack1l1111l_opy_ (u"ࠧࠨᡈ"))}
    @classmethod
    def on(cls):
        if (os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡐࡗࡕࠩᡉ"), None) is None or os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪᡊ")] == bstack1l1111l_opy_ (u"ࠥࡲࡺࡲ࡬ࠣᡋ")) and (os.environ.get(bstack1l1111l_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᡌ"), None) is None or os.environ[bstack1l1111l_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪᡍ")] == bstack1l1111l_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦᡎ")):
            return False
        return True
    @staticmethod
    def bstack1l1lllll11l_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1l11l1l1_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def default_headers():
        headers = {
            bstack1l1111l_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᡏ"): bstack1l1111l_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᡐ"),
            bstack1l1111l_opy_ (u"࡛ࠩ࠱ࡇ࡙ࡔࡂࡅࡎ࠱࡙ࡋࡓࡕࡑࡓࡗࠬᡑ"): bstack1l1111l_opy_ (u"ࠪࡸࡷࡻࡥࠨᡒ")
        }
        if os.environ.get(bstack1l1111l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬᡓ"), None):
            headers[bstack1l1111l_opy_ (u"ࠬࡇࡵࡵࡪࡲࡶ࡮ࢀࡡࡵ࡫ࡲࡲࠬᡔ")] = bstack1l1111l_opy_ (u"࠭ࡂࡦࡣࡵࡩࡷࠦࡻࡾࠩᡕ").format(os.environ[bstack1l1111l_opy_ (u"ࠢࡃࡕࡢࡘࡊ࡙ࡔࡉࡗࡅࡣࡏ࡝ࡔࠣᡖ")])
        return headers
    @staticmethod
    def request_url(url):
        return bstack1l1111l_opy_ (u"ࠨࡽࢀ࠳ࢀࢃࠧᡗ").format(bstack1ll11111l1l_opy_, url)
    @staticmethod
    def current_test_uuid():
        return getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭ᡘ"), None)
    @staticmethod
    def bstack1ll1ll1l_opy_(driver):
        return {
            bstack1llll1lllll_opy_(): bstack1llll1l1111_opy_(driver)
        }
    @staticmethod
    def bstack1l1llllll1l_opy_(exception_info, report):
        return [{bstack1l1111l_opy_ (u"ࠪࡦࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ᡙ"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack111ll1l11l_opy_(typename):
        if bstack1l1111l_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࠢᡚ") in typename:
            return bstack1l1111l_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࡆࡴࡵࡳࡷࠨᡛ")
        return bstack1l1111l_opy_ (u"ࠨࡕ࡯ࡪࡤࡲࡩࡲࡥࡥࡇࡵࡶࡴࡸࠢᡜ")