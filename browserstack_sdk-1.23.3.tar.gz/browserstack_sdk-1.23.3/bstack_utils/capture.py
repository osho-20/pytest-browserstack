# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import builtins
import logging
class bstack1l11ll1l_opy_:
    def __init__(self, handler):
        self._1lllllll1l1_opy_ = builtins.print
        self.handler = handler
        self._started = False
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        self._1llllllllll_opy_ = {
            level: getattr(self.logger, level)
            for level in [bstack1l1111l_opy_ (u"ࠨ࡫ࡱࡪࡴ࠭᎜"), bstack1l1111l_opy_ (u"ࠩࡧࡩࡧࡻࡧࠨ᎝"), bstack1l1111l_opy_ (u"ࠪࡻࡦࡸ࡮ࡪࡰࡪࠫ᎞"), bstack1l1111l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪ᎟")]
        }
    def start(self):
        if self._started:
            return
        self._started = True
        builtins.print = self._1llllllll11_opy_
        self._1lllllll1ll_opy_()
    def _1llllllll11_opy_(self, *args, **kwargs):
        self._1lllllll1l1_opy_(*args, **kwargs)
        message = bstack1l1111l_opy_ (u"ࠬࠦࠧᎠ").join(map(str, args)) + bstack1l1111l_opy_ (u"࠭࡜࡯ࠩᎡ")
        self._log_message(bstack1l1111l_opy_ (u"ࠧࡊࡐࡉࡓࠬᎢ"), message)
    def _log_message(self, level, msg, *args, **kwargs):
        if self.handler:
            self.handler({bstack1l1111l_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧᎣ"): level, bstack1l1111l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᎤ"): msg})
    def _1lllllll1ll_opy_(self):
        for level, bstack1lllllllll1_opy_ in self._1llllllllll_opy_.items():
            setattr(logging, level, self._1llllllll1l_opy_(level, bstack1lllllllll1_opy_))
    def _1llllllll1l_opy_(self, level, bstack1lllllllll1_opy_):
        def wrapper(msg, *args, **kwargs):
            bstack1lllllllll1_opy_(msg, *args, **kwargs)
            self._log_message(level.upper(), msg)
        return wrapper
    def reset(self):
        if not self._started:
            return
        self._started = False
        builtins.print = self._1lllllll1l1_opy_
        for level, bstack1lllllllll1_opy_ in self._1llllllllll_opy_.items():
            setattr(logging, level, bstack1lllllllll1_opy_)