# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import datetime
import json
import os
import platform
import re
import subprocess
import traceback
import tempfile
import multiprocessing
import threading
import sys
import logging
from math import ceil
import urllib
from urllib.parse import urlparse
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import (bstack11111lllll_opy_, bstack11ll111ll_opy_, bstack1lll1111l1_opy_, bstack1ll111l1l_opy_,
                                    bstack1111l1l111_opy_, bstack1111ll1ll1_opy_, bstack1111l1l1ll_opy_, bstack1111ll1l1l_opy_)
from bstack_utils.messages import bstack1llll11lll_opy_, bstack11l1l11l11_opy_
from bstack_utils.proxy import bstack1lll11llll_opy_, bstack1ll1llll11_opy_
bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
logger = logging.getLogger(__name__)
def bstack1lll1l11l11_opy_(config):
    return config[bstack1l1111l_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭Ꭶ")]
def bstack1lll11l1l1l_opy_(config):
    return config[bstack1l1111l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨᎧ")]
def bstack111l1111l_opy_():
    try:
        import playwright
        return True
    except ImportError:
        return False
def bstack1lll11l1111_opy_(obj):
    values = []
    bstack1lll11l111l_opy_ = re.compile(bstack1l1111l_opy_ (u"ࡸࠢ࡟ࡅࡘࡗ࡙ࡕࡍࡠࡖࡄࡋࡤࡢࡤࠬࠦࠥᎨ"), re.I)
    for key in obj.keys():
        if bstack1lll11l111l_opy_.match(key):
            values.append(obj[key])
    return values
def bstack1llll111l11_opy_(config):
    tags = []
    tags.extend(bstack1lll11l1111_opy_(os.environ))
    tags.extend(bstack1lll11l1111_opy_(config))
    return tags
def bstack1llll11l11l_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack1lll11ll1ll_opy_(bstack1lll1ll11ll_opy_):
    if not bstack1lll1ll11ll_opy_:
        return bstack1l1111l_opy_ (u"ࠧࠨᎩ")
    return bstack1l1111l_opy_ (u"ࠣࡽࢀࠤ࠭ࢁࡽࠪࠤᎪ").format(bstack1lll1ll11ll_opy_.name, bstack1lll1ll11ll_opy_.email)
def bstack1lll11l11ll_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack1lll1ll1ll1_opy_ = repo.common_dir
        info = {
            bstack1l1111l_opy_ (u"ࠤࡶ࡬ࡦࠨᎫ"): repo.head.commit.hexsha,
            bstack1l1111l_opy_ (u"ࠥࡷ࡭ࡵࡲࡵࡡࡶ࡬ࡦࠨᎬ"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack1l1111l_opy_ (u"ࠦࡧࡸࡡ࡯ࡥ࡫ࠦᎭ"): repo.active_branch.name,
            bstack1l1111l_opy_ (u"ࠧࡺࡡࡨࠤᎮ"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack1l1111l_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡺࡥࡳࠤᎯ"): bstack1lll11ll1ll_opy_(repo.head.commit.committer),
            bstack1l1111l_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡴࡦࡴࡢࡨࡦࡺࡥࠣᎰ"): repo.head.commit.committed_datetime.isoformat(),
            bstack1l1111l_opy_ (u"ࠣࡣࡸࡸ࡭ࡵࡲࠣᎱ"): bstack1lll11ll1ll_opy_(repo.head.commit.author),
            bstack1l1111l_opy_ (u"ࠤࡤࡹࡹ࡮࡯ࡳࡡࡧࡥࡹ࡫ࠢᎲ"): repo.head.commit.authored_datetime.isoformat(),
            bstack1l1111l_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡢࡱࡪࡹࡳࡢࡩࡨࠦᎳ"): repo.head.commit.message,
            bstack1l1111l_opy_ (u"ࠦࡷࡵ࡯ࡵࠤᎴ"): repo.git.rev_parse(bstack1l1111l_opy_ (u"ࠧ࠳࠭ࡴࡪࡲࡻ࠲ࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠢᎵ")),
            bstack1l1111l_opy_ (u"ࠨࡣࡰ࡯ࡰࡳࡳࡥࡧࡪࡶࡢࡨ࡮ࡸࠢᎶ"): bstack1lll1ll1ll1_opy_,
            bstack1l1111l_opy_ (u"ࠢࡸࡱࡵ࡯ࡹࡸࡥࡦࡡࡪ࡭ࡹࡥࡤࡪࡴࠥᎷ"): subprocess.check_output([bstack1l1111l_opy_ (u"ࠣࡩ࡬ࡸࠧᎸ"), bstack1l1111l_opy_ (u"ࠤࡵࡩࡻ࠳ࡰࡢࡴࡶࡩࠧᎹ"), bstack1l1111l_opy_ (u"ࠥ࠱࠲࡭ࡩࡵ࠯ࡦࡳࡲࡳ࡯࡯࠯ࡧ࡭ࡷࠨᎺ")]).strip().decode(
                bstack1l1111l_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᎻ")),
            bstack1l1111l_opy_ (u"ࠧࡲࡡࡴࡶࡢࡸࡦ࡭ࠢᎼ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack1l1111l_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡹ࡟ࡴ࡫ࡱࡧࡪࡥ࡬ࡢࡵࡷࡣࡹࡧࡧࠣᎽ"): repo.git.rev_list(
                bstack1l1111l_opy_ (u"ࠢࡼࡿ࠱࠲ࢀࢃࠢᎾ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack1llll11l111_opy_ = []
        for remote in remotes:
            bstack1lll1l111ll_opy_ = {
                bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᎿ"): remote.name,
                bstack1l1111l_opy_ (u"ࠤࡸࡶࡱࠨᏀ"): remote.url,
            }
            bstack1llll11l111_opy_.append(bstack1lll1l111ll_opy_)
        bstack1lll111ll1l_opy_ = {
            bstack1l1111l_opy_ (u"ࠥࡲࡦࡳࡥࠣᏁ"): bstack1l1111l_opy_ (u"ࠦ࡬࡯ࡴࠣᏂ"),
            **info,
            bstack1l1111l_opy_ (u"ࠧࡸࡥ࡮ࡱࡷࡩࡸࠨᏃ"): bstack1llll11l111_opy_
        }
        bstack1lll111ll1l_opy_ = bstack1lll1l11ll1_opy_(bstack1lll111ll1l_opy_)
        return bstack1lll111ll1l_opy_
    except git.InvalidGitRepositoryError:
        return {}
    except Exception as err:
        print(bstack1l1111l_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡯ࡱࡷ࡯ࡥࡹ࡯࡮ࡨࠢࡊ࡭ࡹࠦ࡭ࡦࡶࡤࡨࡦࡺࡡࠡࡹ࡬ࡸ࡭ࠦࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠤᏄ").format(err))
        return {}
def bstack1lll1l11ll1_opy_(bstack1lll111ll1l_opy_):
    bstack1llll1l11l1_opy_ = bstack1lll1lll11l_opy_(bstack1lll111ll1l_opy_)
    if bstack1llll1l11l1_opy_ and bstack1llll1l11l1_opy_ > bstack1111l1l111_opy_:
        bstack1llll1l11ll_opy_ = bstack1llll1l11l1_opy_ - bstack1111l1l111_opy_
        bstack1lll1ll1lll_opy_ = bstack1llll11l1l1_opy_(bstack1lll111ll1l_opy_[bstack1l1111l_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺ࡟࡮ࡧࡶࡷࡦ࡭ࡥࠣᏅ")], bstack1llll1l11ll_opy_)
        bstack1lll111ll1l_opy_[bstack1l1111l_opy_ (u"ࠣࡥࡲࡱࡲ࡯ࡴࡠ࡯ࡨࡷࡸࡧࡧࡦࠤᏆ")] = bstack1lll1ll1lll_opy_
        logger.info(bstack1l1111l_opy_ (u"ࠤࡗ࡬ࡪࠦࡣࡰ࡯ࡰ࡭ࡹࠦࡨࡢࡵࠣࡦࡪ࡫࡮ࠡࡶࡵࡹࡳࡩࡡࡵࡧࡧ࠲࡙ࠥࡩࡻࡧࠣࡳ࡫ࠦࡣࡰ࡯ࡰ࡭ࡹࠦࡡࡧࡶࡨࡶࠥࡺࡲࡶࡰࡦࡥࡹ࡯࡯࡯ࠢ࡬ࡷࠥࢁࡽࠡࡍࡅࠦᏇ")
                    .format(bstack1lll1lll11l_opy_(bstack1lll111ll1l_opy_) / 1024))
    return bstack1lll111ll1l_opy_
def bstack1lll1lll11l_opy_(json_data):
    try:
        if json_data:
            bstack1lllll11111_opy_ = json.dumps(json_data)
            bstack1lll1ll1111_opy_ = sys.getsizeof(bstack1lllll11111_opy_)
            return bstack1lll1ll1111_opy_
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠥࡗࡴࡳࡥࡵࡪ࡬ࡲ࡬ࠦࡷࡦࡰࡷࠤࡼࡸ࡯࡯ࡩࠣࡻ࡭࡯࡬ࡦࠢࡦࡥࡱࡩࡵ࡭ࡣࡷ࡭ࡳ࡭ࠠࡴ࡫ࡽࡩࠥࡵࡦࠡࡌࡖࡓࡓࠦ࡯ࡣ࡬ࡨࡧࡹࡀࠠࡼࡿࠥᏈ").format(e))
    return -1
def bstack1llll11l1l1_opy_(field, bstack1lll1l1ll1l_opy_):
    try:
        bstack1lll1l11lll_opy_ = len(bytes(bstack1111ll1ll1_opy_, bstack1l1111l_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᏉ")))
        bstack1lll1l1l111_opy_ = bytes(field, bstack1l1111l_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫᏊ"))
        bstack1llll1lll1l_opy_ = len(bstack1lll1l1l111_opy_)
        bstack1llll1l1l1l_opy_ = ceil(bstack1llll1lll1l_opy_ - bstack1lll1l1ll1l_opy_ - bstack1lll1l11lll_opy_)
        if bstack1llll1l1l1l_opy_ > 0:
            bstack1lll1llllll_opy_ = bstack1lll1l1l111_opy_[:bstack1llll1l1l1l_opy_].decode(bstack1l1111l_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬᏋ"), errors=bstack1l1111l_opy_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᏌ")) + bstack1111ll1ll1_opy_
            return bstack1lll1llllll_opy_
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡸࡪ࡬ࡰࡪࠦࡴࡳࡷࡱࡧࡦࡺࡩ࡯ࡩࠣࡪ࡮࡫࡬ࡥ࠮ࠣࡲࡴࡺࡨࡪࡰࡪࠤࡼࡧࡳࠡࡶࡵࡹࡳࡩࡡࡵࡧࡧࠤ࡭࡫ࡲࡦ࠼ࠣࡿࢂࠨᏍ").format(e))
    return field
def bstack11l11llll1_opy_():
    env = os.environ
    if (bstack1l1111l_opy_ (u"ࠤࡍࡉࡓࡑࡉࡏࡕࡢ࡙ࡗࡒࠢᏎ") in env and len(env[bstack1l1111l_opy_ (u"ࠥࡎࡊࡔࡋࡊࡐࡖࡣ࡚ࡘࡌࠣᏏ")]) > 0) or (
            bstack1l1111l_opy_ (u"ࠦࡏࡋࡎࡌࡋࡑࡗࡤࡎࡏࡎࡇࠥᏐ") in env and len(env[bstack1l1111l_opy_ (u"ࠧࡐࡅࡏࡍࡌࡒࡘࡥࡈࡐࡏࡈࠦᏑ")]) > 0):
        return {
            bstack1l1111l_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᏒ"): bstack1l1111l_opy_ (u"ࠢࡋࡧࡱ࡯࡮ࡴࡳࠣᏓ"),
            bstack1l1111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᏔ"): env.get(bstack1l1111l_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧᏕ")),
            bstack1l1111l_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᏖ"): env.get(bstack1l1111l_opy_ (u"ࠦࡏࡕࡂࡠࡐࡄࡑࡊࠨᏗ")),
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᏘ"): env.get(bstack1l1111l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧᏙ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠢࡄࡋࠥᏚ")) == bstack1l1111l_opy_ (u"ࠣࡶࡵࡹࡪࠨᏛ") and bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠤࡆࡍࡗࡉࡌࡆࡅࡌࠦᏜ"))):
        return {
            bstack1l1111l_opy_ (u"ࠥࡲࡦࡳࡥࠣᏝ"): bstack1l1111l_opy_ (u"ࠦࡈ࡯ࡲࡤ࡮ࡨࡇࡎࠨᏞ"),
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᏟ"): env.get(bstack1l1111l_opy_ (u"ࠨࡃࡊࡔࡆࡐࡊࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤᏠ")),
            bstack1l1111l_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᏡ"): env.get(bstack1l1111l_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡠࡌࡒࡆࠧᏢ")),
            bstack1l1111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᏣ"): env.get(bstack1l1111l_opy_ (u"ࠥࡇࡎࡘࡃࡍࡇࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࠨᏤ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠦࡈࡏࠢᏥ")) == bstack1l1111l_opy_ (u"ࠧࡺࡲࡶࡧࠥᏦ") and bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠨࡔࡓࡃ࡙ࡍࡘࠨᏧ"))):
        return {
            bstack1l1111l_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᏨ"): bstack1l1111l_opy_ (u"ࠣࡖࡵࡥࡻ࡯ࡳࠡࡅࡌࠦᏩ"),
            bstack1l1111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᏪ"): env.get(bstack1l1111l_opy_ (u"ࠥࡘࡗࡇࡖࡊࡕࡢࡆ࡚ࡏࡌࡅࡡ࡚ࡉࡇࡥࡕࡓࡎࠥᏫ")),
            bstack1l1111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᏬ"): env.get(bstack1l1111l_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢᏭ")),
            bstack1l1111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᏮ"): env.get(bstack1l1111l_opy_ (u"ࠢࡕࡔࡄ࡚ࡎ࡙࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨᏯ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠣࡅࡌࠦᏰ")) == bstack1l1111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᏱ") and env.get(bstack1l1111l_opy_ (u"ࠥࡇࡎࡥࡎࡂࡏࡈࠦᏲ")) == bstack1l1111l_opy_ (u"ࠦࡨࡵࡤࡦࡵ࡫࡭ࡵࠨᏳ"):
        return {
            bstack1l1111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᏴ"): bstack1l1111l_opy_ (u"ࠨࡃࡰࡦࡨࡷ࡭࡯ࡰࠣᏵ"),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ᏶"): None,
            bstack1l1111l_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥ᏷"): None,
            bstack1l1111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᏸ"): None
        }
    if env.get(bstack1l1111l_opy_ (u"ࠥࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡂࡓࡃࡑࡇࡍࠨᏹ")) and env.get(bstack1l1111l_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡄࡑࡐࡑࡎ࡚ࠢᏺ")):
        return {
            bstack1l1111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᏻ"): bstack1l1111l_opy_ (u"ࠨࡂࡪࡶࡥࡹࡨࡱࡥࡵࠤᏼ"),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᏽ"): env.get(bstack1l1111l_opy_ (u"ࠣࡄࡌࡘࡇ࡛ࡃࡌࡇࡗࡣࡌࡏࡔࡠࡊࡗࡘࡕࡥࡏࡓࡋࡊࡍࡓࠨ᏾")),
            bstack1l1111l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦ᏿"): None,
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤ᐀"): env.get(bstack1l1111l_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨᐁ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠧࡉࡉࠣᐂ")) == bstack1l1111l_opy_ (u"ࠨࡴࡳࡷࡨࠦᐃ") and bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠢࡅࡔࡒࡒࡊࠨᐄ"))):
        return {
            bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᐅ"): bstack1l1111l_opy_ (u"ࠤࡇࡶࡴࡴࡥࠣᐆ"),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᐇ"): env.get(bstack1l1111l_opy_ (u"ࠦࡉࡘࡏࡏࡇࡢࡆ࡚ࡏࡌࡅࡡࡏࡍࡓࡑࠢᐈ")),
            bstack1l1111l_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᐉ"): None,
            bstack1l1111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᐊ"): env.get(bstack1l1111l_opy_ (u"ࠢࡅࡔࡒࡒࡊࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧᐋ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠣࡅࡌࠦᐌ")) == bstack1l1111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᐍ") and bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠥࡗࡊࡓࡁࡑࡊࡒࡖࡊࠨᐎ"))):
        return {
            bstack1l1111l_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᐏ"): bstack1l1111l_opy_ (u"࡙ࠧࡥ࡮ࡣࡳ࡬ࡴࡸࡥࠣᐐ"),
            bstack1l1111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᐑ"): env.get(bstack1l1111l_opy_ (u"ࠢࡔࡇࡐࡅࡕࡎࡏࡓࡇࡢࡓࡗࡍࡁࡏࡋ࡝ࡅ࡙ࡏࡏࡏࡡࡘࡖࡑࠨᐒ")),
            bstack1l1111l_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᐓ"): env.get(bstack1l1111l_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢᐔ")),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᐕ"): env.get(bstack1l1111l_opy_ (u"ࠦࡘࡋࡍࡂࡒࡋࡓࡗࡋ࡟ࡋࡑࡅࡣࡎࡊࠢᐖ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠧࡉࡉࠣᐗ")) == bstack1l1111l_opy_ (u"ࠨࡴࡳࡷࡨࠦᐘ") and bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠢࡈࡋࡗࡐࡆࡈ࡟ࡄࡋࠥᐙ"))):
        return {
            bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᐚ"): bstack1l1111l_opy_ (u"ࠤࡊ࡭ࡹࡒࡡࡣࠤᐛ"),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᐜ"): env.get(bstack1l1111l_opy_ (u"ࠦࡈࡏ࡟ࡋࡑࡅࡣ࡚ࡘࡌࠣᐝ")),
            bstack1l1111l_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᐞ"): env.get(bstack1l1111l_opy_ (u"ࠨࡃࡊࡡࡍࡓࡇࡥࡎࡂࡏࡈࠦᐟ")),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᐠ"): env.get(bstack1l1111l_opy_ (u"ࠣࡅࡌࡣࡏࡕࡂࡠࡋࡇࠦᐡ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠤࡆࡍࠧᐢ")) == bstack1l1111l_opy_ (u"ࠥࡸࡷࡻࡥࠣᐣ") and bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡎࡍ࡙ࡋࠢᐤ"))):
        return {
            bstack1l1111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᐥ"): bstack1l1111l_opy_ (u"ࠨࡂࡶ࡫࡯ࡨࡰ࡯ࡴࡦࠤᐦ"),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᐧ"): env.get(bstack1l1111l_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢᐨ")),
            bstack1l1111l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᐩ"): env.get(bstack1l1111l_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࡥࡌࡂࡄࡈࡐࠧᐪ")) or env.get(bstack1l1111l_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡎࡍ࡙ࡋ࡟ࡑࡋࡓࡉࡑࡏࡎࡆࡡࡑࡅࡒࡋࠢᐫ")),
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᐬ"): env.get(bstack1l1111l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣᐭ"))
        }
    if bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠢࡕࡈࡢࡆ࡚ࡏࡌࡅࠤᐮ"))):
        return {
            bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᐯ"): bstack1l1111l_opy_ (u"ࠤ࡙࡭ࡸࡻࡡ࡭ࠢࡖࡸࡺࡪࡩࡰࠢࡗࡩࡦࡳࠠࡔࡧࡵࡺ࡮ࡩࡥࡴࠤᐰ"),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᐱ"): bstack1l1111l_opy_ (u"ࠦࢀࢃࡻࡾࠤᐲ").format(env.get(bstack1l1111l_opy_ (u"࡙࡙ࠬࡔࡖࡈࡑࡤ࡚ࡅࡂࡏࡉࡓ࡚ࡔࡄࡂࡖࡌࡓࡓ࡙ࡅࡓࡘࡈࡖ࡚ࡘࡉࠨᐳ")), env.get(bstack1l1111l_opy_ (u"࠭ࡓ࡚ࡕࡗࡉࡒࡥࡔࡆࡃࡐࡔࡗࡕࡊࡆࡅࡗࡍࡉ࠭ᐴ"))),
            bstack1l1111l_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᐵ"): env.get(bstack1l1111l_opy_ (u"ࠣࡕ࡜ࡗ࡙ࡋࡍࡠࡆࡈࡊࡎࡔࡉࡕࡋࡒࡒࡎࡊࠢᐶ")),
            bstack1l1111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᐷ"): env.get(bstack1l1111l_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡡࡅ࡙ࡎࡒࡄࡊࡆࠥᐸ"))
        }
    if bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠦࡆࡖࡐࡗࡇ࡜ࡓࡗࠨᐹ"))):
        return {
            bstack1l1111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᐺ"): bstack1l1111l_opy_ (u"ࠨࡁࡱࡲࡹࡩࡾࡵࡲࠣᐻ"),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᐼ"): bstack1l1111l_opy_ (u"ࠣࡽࢀ࠳ࡵࡸ࡯࡫ࡧࡦࡸ࠴ࢁࡽ࠰ࡽࢀ࠳ࡧࡻࡩ࡭ࡦࡶ࠳ࢀࢃࠢᐽ").format(env.get(bstack1l1111l_opy_ (u"ࠩࡄࡔࡕ࡜ࡅ࡚ࡑࡕࡣ࡚ࡘࡌࠨᐾ")), env.get(bstack1l1111l_opy_ (u"ࠪࡅࡕࡖࡖࡆ࡛ࡒࡖࡤࡇࡃࡄࡑࡘࡒ࡙ࡥࡎࡂࡏࡈࠫᐿ")), env.get(bstack1l1111l_opy_ (u"ࠫࡆࡖࡐࡗࡇ࡜ࡓࡗࡥࡐࡓࡑࡍࡉࡈ࡚࡟ࡔࡎࡘࡋࠬᑀ")), env.get(bstack1l1111l_opy_ (u"ࠬࡇࡐࡑࡘࡈ࡝ࡔࡘ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩᑁ"))),
            bstack1l1111l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᑂ"): env.get(bstack1l1111l_opy_ (u"ࠢࡂࡒࡓ࡚ࡊ࡟ࡏࡓࡡࡍࡓࡇࡥࡎࡂࡏࡈࠦᑃ")),
            bstack1l1111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᑄ"): env.get(bstack1l1111l_opy_ (u"ࠤࡄࡔࡕ࡜ࡅ࡚ࡑࡕࡣࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥᑅ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠥࡅ࡟࡛ࡒࡆࡡࡋࡘ࡙ࡖ࡟ࡖࡕࡈࡖࡤࡇࡇࡆࡐࡗࠦᑆ")) and env.get(bstack1l1111l_opy_ (u"࡙ࠦࡌ࡟ࡃࡗࡌࡐࡉࠨᑇ")):
        return {
            bstack1l1111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᑈ"): bstack1l1111l_opy_ (u"ࠨࡁࡻࡷࡵࡩࠥࡉࡉࠣᑉ"),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᑊ"): bstack1l1111l_opy_ (u"ࠣࡽࢀࡿࢂ࠵࡟ࡣࡷ࡬ࡰࡩ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡣࡷ࡬ࡰࡩࡏࡤ࠾ࡽࢀࠦᑋ").format(env.get(bstack1l1111l_opy_ (u"ࠩࡖ࡝ࡘ࡚ࡅࡎࡡࡗࡉࡆࡓࡆࡐࡗࡑࡈࡆ࡚ࡉࡐࡐࡖࡉࡗ࡜ࡅࡓࡗࡕࡍࠬᑌ")), env.get(bstack1l1111l_opy_ (u"ࠪࡗ࡞࡙ࡔࡆࡏࡢࡘࡊࡇࡍࡑࡔࡒࡎࡊࡉࡔࠨᑍ")), env.get(bstack1l1111l_opy_ (u"ࠫࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡋࡇࠫᑎ"))),
            bstack1l1111l_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᑏ"): env.get(bstack1l1111l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡍࡉࠨᑐ")),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᑑ"): env.get(bstack1l1111l_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡏࡄࠣᑒ"))
        }
    if any([env.get(bstack1l1111l_opy_ (u"ࠤࡆࡓࡉࡋࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠢᑓ")), env.get(bstack1l1111l_opy_ (u"ࠥࡇࡔࡊࡅࡃࡗࡌࡐࡉࡥࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡒ࡙ࡗࡉࡅࡠࡘࡈࡖࡘࡏࡏࡏࠤᑔ")), env.get(bstack1l1111l_opy_ (u"ࠦࡈࡕࡄࡆࡄࡘࡍࡑࡊ࡟ࡔࡑࡘࡖࡈࡋ࡟ࡗࡇࡕࡗࡎࡕࡎࠣᑕ"))]):
        return {
            bstack1l1111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᑖ"): bstack1l1111l_opy_ (u"ࠨࡁࡘࡕࠣࡇࡴࡪࡥࡃࡷ࡬ࡰࡩࠨᑗ"),
            bstack1l1111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᑘ"): env.get(bstack1l1111l_opy_ (u"ࠣࡅࡒࡈࡊࡈࡕࡊࡎࡇࡣࡕ࡛ࡂࡍࡋࡆࡣࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢᑙ")),
            bstack1l1111l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᑚ"): env.get(bstack1l1111l_opy_ (u"ࠥࡇࡔࡊࡅࡃࡗࡌࡐࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠣᑛ")),
            bstack1l1111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᑜ"): env.get(bstack1l1111l_opy_ (u"ࠧࡉࡏࡅࡇࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠥᑝ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠨࡢࡢ࡯ࡥࡳࡴࡥࡢࡶ࡫࡯ࡨࡓࡻ࡭ࡣࡧࡵࠦᑞ")):
        return {
            bstack1l1111l_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᑟ"): bstack1l1111l_opy_ (u"ࠣࡄࡤࡱࡧࡵ࡯ࠣᑠ"),
            bstack1l1111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᑡ"): env.get(bstack1l1111l_opy_ (u"ࠥࡦࡦࡳࡢࡰࡱࡢࡦࡺ࡯࡬ࡥࡔࡨࡷࡺࡲࡴࡴࡗࡵࡰࠧᑢ")),
            bstack1l1111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᑣ"): env.get(bstack1l1111l_opy_ (u"ࠧࡨࡡ࡮ࡤࡲࡳࡤࡹࡨࡰࡴࡷࡎࡴࡨࡎࡢ࡯ࡨࠦᑤ")),
            bstack1l1111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᑥ"): env.get(bstack1l1111l_opy_ (u"ࠢࡣࡣࡰࡦࡴࡵ࡟ࡣࡷ࡬ࡰࡩࡔࡵ࡮ࡤࡨࡶࠧᑦ"))
        }
    if env.get(bstack1l1111l_opy_ (u"࡙ࠣࡈࡖࡈࡑࡅࡓࠤᑧ")) or env.get(bstack1l1111l_opy_ (u"ࠤ࡚ࡉࡗࡉࡋࡆࡔࡢࡑࡆࡏࡎࡠࡒࡌࡔࡊࡒࡉࡏࡇࡢࡗ࡙ࡇࡒࡕࡇࡇࠦᑨ")):
        return {
            bstack1l1111l_opy_ (u"ࠥࡲࡦࡳࡥࠣᑩ"): bstack1l1111l_opy_ (u"ࠦ࡜࡫ࡲࡤ࡭ࡨࡶࠧᑪ"),
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᑫ"): env.get(bstack1l1111l_opy_ (u"ࠨࡗࡆࡔࡆࡏࡊࡘ࡟ࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥᑬ")),
            bstack1l1111l_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᑭ"): bstack1l1111l_opy_ (u"ࠣࡏࡤ࡭ࡳࠦࡐࡪࡲࡨࡰ࡮ࡴࡥࠣᑮ") if env.get(bstack1l1111l_opy_ (u"ࠤ࡚ࡉࡗࡉࡋࡆࡔࡢࡑࡆࡏࡎࡠࡒࡌࡔࡊࡒࡉࡏࡇࡢࡗ࡙ࡇࡒࡕࡇࡇࠦᑯ")) else None,
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᑰ"): env.get(bstack1l1111l_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࡤࡍࡉࡕࡡࡆࡓࡒࡓࡉࡕࠤᑱ"))
        }
    if any([env.get(bstack1l1111l_opy_ (u"ࠧࡍࡃࡑࡡࡓࡖࡔࡐࡅࡄࡖࠥᑲ")), env.get(bstack1l1111l_opy_ (u"ࠨࡇࡄࡎࡒ࡙ࡉࡥࡐࡓࡑࡍࡉࡈ࡚ࠢᑳ")), env.get(bstack1l1111l_opy_ (u"ࠢࡈࡑࡒࡋࡑࡋ࡟ࡄࡎࡒ࡙ࡉࡥࡐࡓࡑࡍࡉࡈ࡚ࠢᑴ"))]):
        return {
            bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᑵ"): bstack1l1111l_opy_ (u"ࠤࡊࡳࡴ࡭࡬ࡦࠢࡆࡰࡴࡻࡤࠣᑶ"),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᑷ"): None,
            bstack1l1111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᑸ"): env.get(bstack1l1111l_opy_ (u"ࠧࡖࡒࡐࡌࡈࡇ࡙ࡥࡉࡅࠤᑹ")),
            bstack1l1111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᑺ"): env.get(bstack1l1111l_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡉࡅࠤᑻ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠣࡕࡋࡍࡕࡖࡁࡃࡎࡈࠦᑼ")):
        return {
            bstack1l1111l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᑽ"): bstack1l1111l_opy_ (u"ࠥࡗ࡭࡯ࡰࡱࡣࡥࡰࡪࠨᑾ"),
            bstack1l1111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᑿ"): env.get(bstack1l1111l_opy_ (u"࡙ࠧࡈࡊࡒࡓࡅࡇࡒࡅࡠࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦᒀ")),
            bstack1l1111l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᒁ"): bstack1l1111l_opy_ (u"ࠢࡋࡱࡥࠤࠨࢁࡽࠣᒂ").format(env.get(bstack1l1111l_opy_ (u"ࠨࡕࡋࡍࡕࡖࡁࡃࡎࡈࡣࡏࡕࡂࡠࡋࡇࠫᒃ"))) if env.get(bstack1l1111l_opy_ (u"ࠤࡖࡌࡎࡖࡐࡂࡄࡏࡉࡤࡐࡏࡃࡡࡌࡈࠧᒄ")) else None,
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᒅ"): env.get(bstack1l1111l_opy_ (u"ࠦࡘࡎࡉࡑࡒࡄࡆࡑࡋ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨᒆ"))
        }
    if bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠧࡔࡅࡕࡎࡌࡊ࡞ࠨᒇ"))):
        return {
            bstack1l1111l_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᒈ"): bstack1l1111l_opy_ (u"ࠢࡏࡧࡷࡰ࡮࡬ࡹࠣᒉ"),
            bstack1l1111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᒊ"): env.get(bstack1l1111l_opy_ (u"ࠤࡇࡉࡕࡒࡏ࡚ࡡࡘࡖࡑࠨᒋ")),
            bstack1l1111l_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᒌ"): env.get(bstack1l1111l_opy_ (u"ࠦࡘࡏࡔࡆࡡࡑࡅࡒࡋࠢᒍ")),
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᒎ"): env.get(bstack1l1111l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡏࡄࠣᒏ"))
        }
    if bstack11ll111lll_opy_(env.get(bstack1l1111l_opy_ (u"ࠢࡈࡋࡗࡌ࡚ࡈ࡟ࡂࡅࡗࡍࡔࡔࡓࠣᒐ"))):
        return {
            bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᒑ"): bstack1l1111l_opy_ (u"ࠤࡊ࡭ࡹࡎࡵࡣࠢࡄࡧࡹ࡯࡯࡯ࡵࠥᒒ"),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᒓ"): bstack1l1111l_opy_ (u"ࠦࢀࢃ࠯ࡼࡿ࠲ࡥࡨࡺࡩࡰࡰࡶ࠳ࡷࡻ࡮ࡴ࠱ࡾࢁࠧᒔ").format(env.get(bstack1l1111l_opy_ (u"ࠬࡍࡉࡕࡊࡘࡆࡤ࡙ࡅࡓࡘࡈࡖࡤ࡛ࡒࡍࠩᒕ")), env.get(bstack1l1111l_opy_ (u"࠭ࡇࡊࡖࡋ࡙ࡇࡥࡒࡆࡒࡒࡗࡎ࡚ࡏࡓ࡛ࠪᒖ")), env.get(bstack1l1111l_opy_ (u"ࠧࡈࡋࡗࡌ࡚ࡈ࡟ࡓࡗࡑࡣࡎࡊࠧᒗ"))),
            bstack1l1111l_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᒘ"): env.get(bstack1l1111l_opy_ (u"ࠤࡊࡍ࡙ࡎࡕࡃࡡ࡚ࡓࡗࡑࡆࡍࡑ࡚ࠦᒙ")),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᒚ"): env.get(bstack1l1111l_opy_ (u"ࠦࡌࡏࡔࡉࡗࡅࡣࡗ࡛ࡎࡠࡋࡇࠦᒛ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠧࡉࡉࠣᒜ")) == bstack1l1111l_opy_ (u"ࠨࡴࡳࡷࡨࠦᒝ") and env.get(bstack1l1111l_opy_ (u"ࠢࡗࡇࡕࡇࡊࡒࠢᒞ")) == bstack1l1111l_opy_ (u"ࠣ࠳ࠥᒟ"):
        return {
            bstack1l1111l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᒠ"): bstack1l1111l_opy_ (u"࡚ࠥࡪࡸࡣࡦ࡮ࠥᒡ"),
            bstack1l1111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᒢ"): bstack1l1111l_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࢁࡽࠣᒣ").format(env.get(bstack1l1111l_opy_ (u"࠭ࡖࡆࡔࡆࡉࡑࡥࡕࡓࡎࠪᒤ"))),
            bstack1l1111l_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᒥ"): None,
            bstack1l1111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᒦ"): None,
        }
    if env.get(bstack1l1111l_opy_ (u"ࠤࡗࡉࡆࡓࡃࡊࡖ࡜ࡣ࡛ࡋࡒࡔࡋࡒࡒࠧᒧ")):
        return {
            bstack1l1111l_opy_ (u"ࠥࡲࡦࡳࡥࠣᒨ"): bstack1l1111l_opy_ (u"࡙ࠦ࡫ࡡ࡮ࡥ࡬ࡸࡾࠨᒩ"),
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᒪ"): None,
            bstack1l1111l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᒫ"): env.get(bstack1l1111l_opy_ (u"ࠢࡕࡇࡄࡑࡈࡏࡔ࡚ࡡࡓࡖࡔࡐࡅࡄࡖࡢࡒࡆࡓࡅࠣᒬ")),
            bstack1l1111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᒭ"): env.get(bstack1l1111l_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣᒮ"))
        }
    if any([env.get(bstack1l1111l_opy_ (u"ࠥࡇࡔࡔࡃࡐࡗࡕࡗࡊࠨᒯ")), env.get(bstack1l1111l_opy_ (u"ࠦࡈࡕࡎࡄࡑࡘࡖࡘࡋ࡟ࡖࡔࡏࠦᒰ")), env.get(bstack1l1111l_opy_ (u"ࠧࡉࡏࡏࡅࡒ࡙ࡗ࡙ࡅࡠࡗࡖࡉࡗࡔࡁࡎࡇࠥᒱ")), env.get(bstack1l1111l_opy_ (u"ࠨࡃࡐࡐࡆࡓ࡚ࡘࡓࡆࡡࡗࡉࡆࡓࠢᒲ"))]):
        return {
            bstack1l1111l_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᒳ"): bstack1l1111l_opy_ (u"ࠣࡅࡲࡲࡨࡵࡵࡳࡵࡨࠦᒴ"),
            bstack1l1111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᒵ"): None,
            bstack1l1111l_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᒶ"): env.get(bstack1l1111l_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧᒷ")) or None,
            bstack1l1111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᒸ"): env.get(bstack1l1111l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡏࡄࠣᒹ"), 0)
        }
    if env.get(bstack1l1111l_opy_ (u"ࠢࡈࡑࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧᒺ")):
        return {
            bstack1l1111l_opy_ (u"ࠣࡰࡤࡱࡪࠨᒻ"): bstack1l1111l_opy_ (u"ࠤࡊࡳࡈࡊࠢᒼ"),
            bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᒽ"): None,
            bstack1l1111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᒾ"): env.get(bstack1l1111l_opy_ (u"ࠧࡍࡏࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥᒿ")),
            bstack1l1111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᓀ"): env.get(bstack1l1111l_opy_ (u"ࠢࡈࡑࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤࡉࡏࡖࡐࡗࡉࡗࠨᓁ"))
        }
    if env.get(bstack1l1111l_opy_ (u"ࠣࡅࡉࡣࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᓂ")):
        return {
            bstack1l1111l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᓃ"): bstack1l1111l_opy_ (u"ࠥࡇࡴࡪࡥࡇࡴࡨࡷ࡭ࠨᓄ"),
            bstack1l1111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᓅ"): env.get(bstack1l1111l_opy_ (u"ࠧࡉࡆࡠࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦᓆ")),
            bstack1l1111l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᓇ"): env.get(bstack1l1111l_opy_ (u"ࠢࡄࡈࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤࡔࡁࡎࡇࠥᓈ")),
            bstack1l1111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᓉ"): env.get(bstack1l1111l_opy_ (u"ࠤࡆࡊࡤࡈࡕࡊࡎࡇࡣࡎࡊࠢᓊ"))
        }
    return {bstack1l1111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᓋ"): None}
def get_host_info():
    return {
        bstack1l1111l_opy_ (u"ࠦ࡭ࡵࡳࡵࡰࡤࡱࡪࠨᓌ"): platform.node(),
        bstack1l1111l_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢᓍ"): platform.system(),
        bstack1l1111l_opy_ (u"ࠨࡴࡺࡲࡨࠦᓎ"): platform.machine(),
        bstack1l1111l_opy_ (u"ࠢࡷࡧࡵࡷ࡮ࡵ࡮ࠣᓏ"): platform.version(),
        bstack1l1111l_opy_ (u"ࠣࡣࡵࡧ࡭ࠨᓐ"): platform.architecture()[0]
    }
def bstack11ll1llll_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack1llll1lllll_opy_():
    if bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࠪᓑ")):
        return bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩᓒ")
    return bstack1l1111l_opy_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࡤ࡭ࡲࡪࡦࠪᓓ")
def bstack1llll1l1111_opy_(driver):
    info = {
        bstack1l1111l_opy_ (u"ࠬࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫᓔ"): driver.capabilities,
        bstack1l1111l_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࠪᓕ"): driver.session_id,
        bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨᓖ"): driver.capabilities.get(bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭ᓗ"), None),
        bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡺࡪࡸࡳࡪࡱࡱࠫᓘ"): driver.capabilities.get(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᓙ"), None),
        bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࠭ᓚ"): driver.capabilities.get(bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠫᓛ"), None),
    }
    if bstack1llll1lllll_opy_() == bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬᓜ"):
        if bstack1l11ll1ll_opy_():
            info[bstack1l1111l_opy_ (u"ࠧࡱࡴࡲࡨࡺࡩࡴࠨᓝ")] = bstack1l1111l_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧᓞ")
        elif driver.capabilities.get(bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᓟ"), {}).get(bstack1l1111l_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫ࠧᓠ"), False):
            info[bstack1l1111l_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸࠬᓡ")] = bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡷࡨࡧ࡬ࡦࠩᓢ")
        else:
            info[bstack1l1111l_opy_ (u"࠭ࡰࡳࡱࡧࡹࡨࡺࠧᓣ")] = bstack1l1111l_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡦࠩᓤ")
    return info
def bstack1l11ll1ll_opy_():
    if bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠨࡣࡳࡴࡤࡧࡵࡵࡱࡰࡥࡹ࡫ࠧᓥ")):
        return True
    if bstack11ll111lll_opy_(os.environ.get(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪᓦ"), None)):
        return True
    return False
def bstack1ll1l11111_opy_(bstack1lll11ll11l_opy_, url, data, config):
    headers = config.get(bstack1l1111l_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫᓧ"), None)
    proxies = bstack1lll11llll_opy_(config, url)
    auth = config.get(bstack1l1111l_opy_ (u"ࠫࡦࡻࡴࡩࠩᓨ"), None)
    response = requests.request(
            bstack1lll11ll11l_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack11l11ll11l_opy_(bstack1111l11ll_opy_, size):
    bstack1l11ll1l1_opy_ = []
    while len(bstack1111l11ll_opy_) > size:
        bstack11l11l11l_opy_ = bstack1111l11ll_opy_[:size]
        bstack1l11ll1l1_opy_.append(bstack11l11l11l_opy_)
        bstack1111l11ll_opy_ = bstack1111l11ll_opy_[size:]
    bstack1l11ll1l1_opy_.append(bstack1111l11ll_opy_)
    return bstack1l11ll1l1_opy_
def bstack1lll11l11l1_opy_(message, bstack1llll111l1l_opy_=False):
    os.write(1, bytes(message, bstack1l1111l_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫᓩ")))
    os.write(1, bytes(bstack1l1111l_opy_ (u"࠭࡜࡯ࠩᓪ"), bstack1l1111l_opy_ (u"ࠧࡶࡶࡩ࠱࠽࠭ᓫ")))
    if bstack1llll111l1l_opy_:
        with open(bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠮ࡱ࠴࠵ࡾ࠳ࠧᓬ") + os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡎࡁࡔࡊࡈࡈࡤࡏࡄࠨᓭ")] + bstack1l1111l_opy_ (u"ࠪ࠲ࡱࡵࡧࠨᓮ"), bstack1l1111l_opy_ (u"ࠫࡦ࠭ᓯ")) as f:
            f.write(message + bstack1l1111l_opy_ (u"ࠬࡢ࡮ࠨᓰ"))
def bstack1lll11lll11_opy_():
    return os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩᓱ")].lower() == bstack1l1111l_opy_ (u"ࠧࡵࡴࡸࡩࠬᓲ")
def bstack111l1l1ll_opy_(bstack1lll111llll_opy_):
    return bstack1l1111l_opy_ (u"ࠨࡽࢀ࠳ࢀࢃࠧᓳ").format(bstack11111lllll_opy_, bstack1lll111llll_opy_)
def bstack1llll111_opy_():
    return bstack1l1l1ll1_opy_().replace(tzinfo=None).isoformat() + bstack1l1111l_opy_ (u"ࠩ࡝ࠫᓴ")
def bstack1llll11ll11_opy_(start, finish):
    return (datetime.datetime.fromisoformat(finish.rstrip(bstack1l1111l_opy_ (u"ࠪ࡞ࠬᓵ"))) - datetime.datetime.fromisoformat(start.rstrip(bstack1l1111l_opy_ (u"ࠫ࡟࠭ᓶ")))).total_seconds() * 1000
def bstack1lll1l1111l_opy_(timestamp):
    return bstack1llll11ll1l_opy_(timestamp).isoformat() + bstack1l1111l_opy_ (u"ࠬࡠࠧᓷ")
def bstack1lll11l1l11_opy_(bstack1llll1llll1_opy_):
    date_format = bstack1l1111l_opy_ (u"࡚࠭ࠥࠧࡰࠩࡩࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓ࠯ࠧࡩࠫᓸ")
    bstack1lll1ll111l_opy_ = datetime.datetime.strptime(bstack1llll1llll1_opy_, date_format)
    return bstack1lll1ll111l_opy_.isoformat() + bstack1l1111l_opy_ (u"࡛ࠧࠩᓹ")
def bstack1lll1lll111_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᓺ")
    else:
        return bstack1l1111l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩᓻ")
def bstack11ll111lll_opy_(val):
    if val is None:
        return False
    return val.__str__().lower() == bstack1l1111l_opy_ (u"ࠪࡸࡷࡻࡥࠨᓼ")
def bstack1lll11lll1l_opy_(val):
    return val.__str__().lower() == bstack1l1111l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪᓽ")
def bstack11llllll_opy_(bstack1lll1lll1ll_opy_=Exception, class_method=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack1lll1lll1ll_opy_ as e:
                print(bstack1l1111l_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡻࡾࠢ࠰ࡂࠥࢁࡽ࠻ࠢࡾࢁࠧᓾ").format(func.__name__, bstack1lll1lll1ll_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack1llll1111ll_opy_(bstack1lll1l11111_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack1lll1l11111_opy_(cls, *args, **kwargs)
            except bstack1lll1lll1ll_opy_ as e:
                print(bstack1l1111l_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡼࡿࠣ࠱ࡃࠦࡻࡾ࠼ࠣࡿࢂࠨᓿ").format(bstack1lll1l11111_opy_.__name__, bstack1lll1lll1ll_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if class_method:
        return bstack1llll1111ll_opy_
    else:
        return decorator
def bstack1l11lll11_opy_(bstack111ll1l1_opy_):
    if bstack1l1111l_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᔀ") in bstack111ll1l1_opy_ and bstack1lll11lll1l_opy_(bstack111ll1l1_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᔁ")]):
        return False
    if bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᔂ") in bstack111ll1l1_opy_ and bstack1lll11lll1l_opy_(bstack111ll1l1_opy_[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᔃ")]):
        return False
    return True
def bstack1llll1ll1_opy_():
    try:
        from pytest_bdd import reporting
        bstack1lll1l1l11l_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢ࡙ࡘࡋࡒࡠࡈࡕࡅࡒࡋࡗࡐࡔࡎࠦᔄ"), None)
        return bstack1lll1l1l11l_opy_ is None or bstack1lll1l1l11l_opy_ == bstack1l1111l_opy_ (u"ࠧࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠤᔅ")
    except Exception as e:
        return False
def bstack1ll111111l_opy_(hub_url, CONFIG):
    if bstack1ll11llll1_opy_() <= version.parse(bstack1l1111l_opy_ (u"࠭࠳࠯࠳࠶࠲࠵࠭ᔆ")):
        if hub_url != bstack1l1111l_opy_ (u"ࠧࠨᔇ"):
            return bstack1l1111l_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤᔈ") + hub_url + bstack1l1111l_opy_ (u"ࠤ࠽࠼࠵࠵ࡷࡥ࠱࡫ࡹࡧࠨᔉ")
        return bstack1lll1111l1_opy_
    if hub_url != bstack1l1111l_opy_ (u"ࠪࠫᔊ"):
        return bstack1l1111l_opy_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࠨᔋ") + hub_url + bstack1l1111l_opy_ (u"ࠧ࠵ࡷࡥ࠱࡫ࡹࡧࠨᔌ")
    return bstack1ll111l1l_opy_
def bstack1llll1ll1ll_opy_():
    return isinstance(os.getenv(bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖ࡙ࡕࡇࡖࡘࡤࡖࡌࡖࡉࡌࡒࠬᔍ")), str)
def bstack1ll111llll_opy_(url):
    return urlparse(url).hostname
def bstack1lllll11l1_opy_(hostname):
    for bstack1l1l111lll_opy_ in bstack11ll111ll_opy_:
        regex = re.compile(bstack1l1l111lll_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack111l1l1l1l_opy_(bstack1llll1l1lll_opy_, file_name, logger):
    bstack1l111ll1l1_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠧࡿࠩᔎ")), bstack1llll1l1lll_opy_)
    try:
        if not os.path.exists(bstack1l111ll1l1_opy_):
            os.makedirs(bstack1l111ll1l1_opy_)
        file_path = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠨࢀࠪᔏ")), bstack1llll1l1lll_opy_, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack1l1111l_opy_ (u"ࠩࡺࠫᔐ")):
                pass
            with open(file_path, bstack1l1111l_opy_ (u"ࠥࡻ࠰ࠨᔑ")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack1llll11lll_opy_.format(str(e)))
def bstack111l1l1l11_opy_(file_name, key, value, logger):
    file_path = bstack111l1l1l1l_opy_(bstack1l1111l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫᔒ"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack1l1l1l111_opy_ = json.load(open(file_path, bstack1l1111l_opy_ (u"ࠬࡸࡢࠨᔓ")))
        else:
            bstack1l1l1l111_opy_ = {}
        bstack1l1l1l111_opy_[key] = value
        with open(file_path, bstack1l1111l_opy_ (u"ࠨࡷࠬࠤᔔ")) as outfile:
            json.dump(bstack1l1l1l111_opy_, outfile)
def bstack1ll11l1ll_opy_(file_name, logger):
    file_path = bstack111l1l1l1l_opy_(bstack1l1111l_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧᔕ"), file_name, logger)
    bstack1l1l1l111_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack1l1111l_opy_ (u"ࠨࡴࠪᔖ")) as bstack11l11l1ll_opy_:
            bstack1l1l1l111_opy_ = json.load(bstack11l11l1ll_opy_)
    return bstack1l1l1l111_opy_
def bstack11l1lll11_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡩ࡫࡬ࡦࡶ࡬ࡲ࡬ࠦࡦࡪ࡮ࡨ࠾ࠥ࠭ᔗ") + file_path + bstack1l1111l_opy_ (u"ࠪࠤࠬᔘ") + str(e))
def bstack1ll11llll1_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack1l1111l_opy_ (u"ࠦࡁࡔࡏࡕࡕࡈࡘࡃࠨᔙ")
def bstack1llll1111_opy_(config):
    if bstack1l1111l_opy_ (u"ࠬ࡯ࡳࡑ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠫᔚ") in config:
        del (config[bstack1l1111l_opy_ (u"࠭ࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠬᔛ")])
        return False
    if bstack1ll11llll1_opy_() < version.parse(bstack1l1111l_opy_ (u"ࠧ࠴࠰࠷࠲࠵࠭ᔜ")):
        return False
    if bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠨ࠶࠱࠵࠳࠻ࠧᔝ")):
        return True
    if bstack1l1111l_opy_ (u"ࠩࡸࡷࡪ࡝࠳ࡄࠩᔞ") in config and config[bstack1l1111l_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅࠪᔟ")] is False:
        return False
    else:
        return True
def bstack1lll111l11_opy_(args_list, bstack1llll11l1ll_opy_):
    index = -1
    for value in bstack1llll11l1ll_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index
class Result:
    def __init__(self, result=None, duration=None, exception=None, bstack1ll11lll_opy_=None):
        self.result = result
        self.duration = duration
        self.exception = exception
        self.exception_type = type(self.exception).__name__ if exception else None
        self.bstack1ll11lll_opy_ = bstack1ll11lll_opy_
    @classmethod
    def passed(cls):
        return Result(result=bstack1l1111l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫᔠ"))
    @classmethod
    def failed(cls, exception=None):
        return Result(result=bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᔡ"), exception=exception)
    def bstack111ll1l11l_opy_(self):
        if self.result != bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᔢ"):
            return None
        if isinstance(self.exception_type, str) and bstack1l1111l_opy_ (u"ࠢࡂࡵࡶࡩࡷࡺࡩࡰࡰࠥᔣ") in self.exception_type:
            return bstack1l1111l_opy_ (u"ࠣࡃࡶࡷࡪࡸࡴࡪࡱࡱࡉࡷࡸ࡯ࡳࠤᔤ")
        return bstack1l1111l_opy_ (u"ࠤࡘࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࡊࡸࡲࡰࡴࠥᔥ")
    def bstack1llll1l1l11_opy_(self):
        if self.result != bstack1l1111l_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᔦ"):
            return None
        if self.bstack1ll11lll_opy_:
            return self.bstack1ll11lll_opy_
        return bstack1lll1l1llll_opy_(self.exception)
def bstack1lll1l1llll_opy_(exc):
    return [traceback.format_exception(exc)]
def bstack1llll11111l_opy_(message):
    if isinstance(message, str):
        return not bool(message and message.strip())
    return True
def bstack1l111ll1_opy_(object, key, default_value):
    if not object or not object.__dict__:
        return default_value
    if key in object.__dict__.keys():
        return object.__dict__.get(key)
    return default_value
def bstack1ll11l1l1l_opy_(config, logger):
    try:
        import playwright
        bstack1lll1ll1l1l_opy_ = playwright.__file__
        bstack1lll11l1lll_opy_ = os.path.split(bstack1lll1ll1l1l_opy_)
        bstack1lll1lllll1_opy_ = bstack1lll11l1lll_opy_[0] + bstack1l1111l_opy_ (u"ࠫ࠴ࡪࡲࡪࡸࡨࡶ࠴ࡶࡡࡤ࡭ࡤ࡫ࡪ࠵࡬ࡪࡤ࠲ࡧࡱ࡯࠯ࡤ࡮࡬࠲࡯ࡹࠧᔧ")
        os.environ[bstack1l1111l_opy_ (u"ࠬࡍࡌࡐࡄࡄࡐࡤࡇࡇࡆࡐࡗࡣࡍ࡚ࡔࡑࡡࡓࡖࡔ࡞࡙ࠨᔨ")] = bstack1ll1llll11_opy_(config)
        with open(bstack1lll1lllll1_opy_, bstack1l1111l_opy_ (u"࠭ࡲࠨᔩ")) as f:
            file_content = f.read()
            bstack1llll1ll1l1_opy_ = bstack1l1111l_opy_ (u"ࠧࡨ࡮ࡲࡦࡦࡲ࠭ࡢࡩࡨࡲࡹ࠭ᔪ")
            bstack1llll111lll_opy_ = file_content.find(bstack1llll1ll1l1_opy_)
            if bstack1llll111lll_opy_ == -1:
              process = subprocess.Popen(bstack1l1111l_opy_ (u"ࠣࡰࡳࡱࠥ࡯࡮ࡴࡶࡤࡰࡱࠦࡧ࡭ࡱࡥࡥࡱ࠳ࡡࡨࡧࡱࡸࠧᔫ"), shell=True, cwd=bstack1lll11l1lll_opy_[0])
              process.wait()
              bstack1llll1l111l_opy_ = bstack1l1111l_opy_ (u"ࠩࠥࡹࡸ࡫ࠠࡴࡶࡵ࡭ࡨࡺࠢ࠼ࠩᔬ")
              bstack1lll1llll1l_opy_ = bstack1l1111l_opy_ (u"ࠥࠦࠧࠦ࡜ࠣࡷࡶࡩࠥࡹࡴࡳ࡫ࡦࡸࡡࠨ࠻ࠡࡥࡲࡲࡸࡺࠠࡼࠢࡥࡳࡴࡺࡳࡵࡴࡤࡴࠥࢃࠠ࠾ࠢࡵࡩࡶࡻࡩࡳࡧࠫࠫ࡬ࡲ࡯ࡣࡣ࡯࠱ࡦ࡭ࡥ࡯ࡶࠪ࠭ࡀࠦࡩࡧࠢࠫࡴࡷࡵࡣࡦࡵࡶ࠲ࡪࡴࡶ࠯ࡉࡏࡓࡇࡇࡌࡠࡃࡊࡉࡓ࡚࡟ࡉࡖࡗࡔࡤࡖࡒࡐ࡚࡜࠭ࠥࡨ࡯ࡰࡶࡶࡸࡷࡧࡰࠩࠫ࠾ࠤࠧࠨࠢᔭ")
              bstack1lll1l11l1l_opy_ = file_content.replace(bstack1llll1l111l_opy_, bstack1lll1llll1l_opy_)
              with open(bstack1lll1lllll1_opy_, bstack1l1111l_opy_ (u"ࠫࡼ࠭ᔮ")) as f:
                f.write(bstack1lll1l11l1l_opy_)
    except Exception as e:
        logger.error(bstack11l1l11l11_opy_.format(str(e)))
def bstack1ll11l1l11_opy_():
  try:
    bstack1llll1ll11l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"ࠬࡵࡰࡵ࡫ࡰࡥࡱࡥࡨࡶࡤࡢࡹࡷࡲ࠮࡫ࡵࡲࡲࠬᔯ"))
    bstack1llll1lll11_opy_ = []
    if os.path.exists(bstack1llll1ll11l_opy_):
      with open(bstack1llll1ll11l_opy_) as f:
        bstack1llll1lll11_opy_ = json.load(f)
      os.remove(bstack1llll1ll11l_opy_)
    return bstack1llll1lll11_opy_
  except:
    pass
  return []
def bstack11l1ll1ll_opy_(bstack111lllll1l_opy_):
  try:
    bstack1llll1lll11_opy_ = []
    bstack1llll1ll11l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"࠭࡯ࡱࡶ࡬ࡱࡦࡲ࡟ࡩࡷࡥࡣࡺࡸ࡬࠯࡬ࡶࡳࡳ࠭ᔰ"))
    if os.path.exists(bstack1llll1ll11l_opy_):
      with open(bstack1llll1ll11l_opy_) as f:
        bstack1llll1lll11_opy_ = json.load(f)
    bstack1llll1lll11_opy_.append(bstack111lllll1l_opy_)
    with open(bstack1llll1ll11l_opy_, bstack1l1111l_opy_ (u"ࠧࡸࠩᔱ")) as f:
        json.dump(bstack1llll1lll11_opy_, f)
  except:
    pass
def bstack1ll1lll11l_opy_(logger, bstack1llll11llll_opy_ = False):
  try:
    test_name = os.environ.get(bstack1l1111l_opy_ (u"ࠨࡒ࡜ࡘࡊ࡙ࡔࡠࡖࡈࡗ࡙ࡥࡎࡂࡏࡈࠫᔲ"), bstack1l1111l_opy_ (u"ࠩࠪᔳ"))
    if test_name == bstack1l1111l_opy_ (u"ࠪࠫᔴ"):
        test_name = threading.current_thread().__dict__.get(bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࡆࡩࡪ࡟ࡵࡧࡶࡸࡤࡴࡡ࡮ࡧࠪᔵ"), bstack1l1111l_opy_ (u"ࠬ࠭ᔶ"))
    bstack1lll1llll11_opy_ = bstack1l1111l_opy_ (u"࠭ࠬࠡࠩᔷ").join(threading.current_thread().bstackTestErrorMessages)
    if bstack1llll11llll_opy_:
        bstack1l1l1l111l_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧᔸ"), bstack1l1111l_opy_ (u"ࠨ࠲ࠪᔹ"))
        bstack11ll1l1l1l_opy_ = {bstack1l1111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᔺ"): test_name, bstack1l1111l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩᔻ"): bstack1lll1llll11_opy_, bstack1l1111l_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪᔼ"): bstack1l1l1l111l_opy_}
        bstack1lll1l1l1ll_opy_ = []
        bstack1lll11lllll_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࡤࡶࡰࡱࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫᔽ"))
        if os.path.exists(bstack1lll11lllll_opy_):
            with open(bstack1lll11lllll_opy_) as f:
                bstack1lll1l1l1ll_opy_ = json.load(f)
        bstack1lll1l1l1ll_opy_.append(bstack11ll1l1l1l_opy_)
        with open(bstack1lll11lllll_opy_, bstack1l1111l_opy_ (u"࠭ࡷࠨᔾ")) as f:
            json.dump(bstack1lll1l1l1ll_opy_, f)
    else:
        bstack11ll1l1l1l_opy_ = {bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᔿ"): test_name, bstack1l1111l_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧᕀ"): bstack1lll1llll11_opy_, bstack1l1111l_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨᕁ"): str(multiprocessing.current_process().name)}
        if bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡢࡩࡷࡸ࡯ࡳࡡ࡯࡭ࡸࡺࠧᕂ") not in multiprocessing.current_process().__dict__.keys():
            multiprocessing.current_process().bstack_error_list = []
        multiprocessing.current_process().bstack_error_list.append(bstack11ll1l1l1l_opy_)
  except Exception as e:
      logger.warn(bstack1l1111l_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡴࡶࡲࡶࡪࠦࡰࡺࡶࡨࡷࡹࠦࡦࡶࡰࡱࡩࡱࠦࡤࡢࡶࡤ࠾ࠥࢁࡽࠣᕃ").format(e))
def bstack11l1l11ll_opy_(error_message, test_name, index, logger):
  try:
    bstack1lll111ll11_opy_ = []
    bstack11ll1l1l1l_opy_ = {bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᕄ"): test_name, bstack1l1111l_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬᕅ"): error_message, bstack1l1111l_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭ᕆ"): index}
    bstack1llll111111_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"ࠨࡴࡲࡦࡴࡺ࡟ࡦࡴࡵࡳࡷࡥ࡬ࡪࡵࡷ࠲࡯ࡹ࡯࡯ࠩᕇ"))
    if os.path.exists(bstack1llll111111_opy_):
        with open(bstack1llll111111_opy_) as f:
            bstack1lll111ll11_opy_ = json.load(f)
    bstack1lll111ll11_opy_.append(bstack11ll1l1l1l_opy_)
    with open(bstack1llll111111_opy_, bstack1l1111l_opy_ (u"ࠩࡺࠫᕈ")) as f:
        json.dump(bstack1lll111ll11_opy_, f)
  except Exception as e:
    logger.warn(bstack1l1111l_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡱࡵࡩࠥࡸ࡯ࡣࡱࡷࠤ࡫ࡻ࡮࡯ࡧ࡯ࠤࡩࡧࡴࡢ࠼ࠣࡿࢂࠨᕉ").format(e))
def bstack1l11l1l1ll_opy_(bstack1l11ll1l1l_opy_, name, logger):
  try:
    bstack11ll1l1l1l_opy_ = {bstack1l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩᕊ"): name, bstack1l1111l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫᕋ"): bstack1l11ll1l1l_opy_, bstack1l1111l_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬᕌ"): str(threading.current_thread()._name)}
    return bstack11ll1l1l1l_opy_
  except Exception as e:
    logger.warn(bstack1l1111l_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡹࡵࡲࡦࠢࡥࡩ࡭ࡧࡶࡦࠢࡩࡹࡳࡴࡥ࡭ࠢࡧࡥࡹࡧ࠺ࠡࡽࢀࠦᕍ").format(e))
  return
def bstack1lll11ll111_opy_():
    return platform.system() == bstack1l1111l_opy_ (u"ࠨ࡙࡬ࡲࡩࡵࡷࡴࠩᕎ")
def bstack11ll11ll11_opy_(bstack1lll1ll11l1_opy_, config, logger):
    bstack1lll11ll1l1_opy_ = {}
    try:
        return {key: config[key] for key in config if bstack1lll1ll11l1_opy_.match(key)}
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥ࡬ࡩ࡭ࡶࡨࡶࠥࡩ࡯࡯ࡨ࡬࡫ࠥࡱࡥࡺࡵࠣࡦࡾࠦࡲࡦࡩࡨࡼࠥࡳࡡࡵࡥ࡫࠾ࠥࢁࡽࠣᕏ").format(e))
    return bstack1lll11ll1l1_opy_
def bstack1111lll111_opy_(bstack1llll1ll111_opy_, bstack1lll1lll1l1_opy_):
    bstack1lll111lll1_opy_ = version.parse(bstack1llll1ll111_opy_)
    bstack1lll11l1ll1_opy_ = version.parse(bstack1lll1lll1l1_opy_)
    if bstack1lll111lll1_opy_ > bstack1lll11l1ll1_opy_:
        return 1
    elif bstack1lll111lll1_opy_ < bstack1lll11l1ll1_opy_:
        return -1
    else:
        return 0
def bstack1l1l1ll1_opy_():
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
def bstack1llll11ll1l_opy_(timestamp):
    return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc).replace(tzinfo=None)
def bstack1llll1l1ll1_opy_(framework):
    from browserstack_sdk._version import __version__
    return str(framework) + str(__version__)
def bstack111l1l11l_opy_(options, framework, bstack111lll1l11_opy_={}):
    if options is None:
        return
    if getattr(options, bstack1l1111l_opy_ (u"ࠪ࡫ࡪࡺࠧᕐ"), None):
        caps = options
    else:
        caps = options.to_capabilities()
    bstack11l11l1l11_opy_ = caps.get(bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬᕑ"))
    bstack1lll11llll1_opy_ = True
    bstack11l1lll111_opy_ = os.environ[bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪᕒ")]
    if bstack1lll11lll1l_opy_(caps.get(bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡻࡳࡦ࡙࠶ࡇࠬᕓ"))) or bstack1lll11lll1l_opy_(caps.get(bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡵࡴࡧࡢࡻ࠸ࡩࠧᕔ"))):
        bstack1lll11llll1_opy_ = False
    if bstack1llll1111_opy_({bstack1l1111l_opy_ (u"ࠣࡷࡶࡩ࡜࠹ࡃࠣᕕ"): bstack1lll11llll1_opy_}):
        bstack11l11l1l11_opy_ = bstack11l11l1l11_opy_ or {}
        bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫᕖ")] = bstack1llll1l1ll1_opy_(framework)
        bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᕗ")] = bstack1lll11lll11_opy_()
        bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡪࡸࡦࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧᕘ")] = bstack11l1lll111_opy_
        bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡔࡷࡵࡤࡶࡥࡷࡑࡦࡶࠧᕙ")] = bstack111lll1l11_opy_
        if getattr(options, bstack1l1111l_opy_ (u"࠭ࡳࡦࡶࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹࡿࠧᕚ"), None):
            options.set_capability(bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᕛ"), bstack11l11l1l11_opy_)
        else:
            options[bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩᕜ")] = bstack11l11l1l11_opy_
    else:
        if getattr(options, bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵࡻࠪᕝ"), None):
            options.set_capability(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫᕞ"), bstack1llll1l1ll1_opy_(framework))
            options.set_capability(bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᕟ"), bstack1lll11lll11_opy_())
            options.set_capability(bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡹ࡫ࡳࡵࡪࡸࡦࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧᕠ"), bstack11l1lll111_opy_)
            options.set_capability(bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡨࡵࡪ࡮ࡧࡔࡷࡵࡤࡶࡥࡷࡑࡦࡶࠧᕡ"), bstack111lll1l11_opy_)
        else:
            options[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡘࡊࡋࠨᕢ")] = bstack1llll1l1ll1_opy_(framework)
            options[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠩᕣ")] = bstack1lll11lll11_opy_()
            options[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡶࡨࡷࡹ࡮ࡵࡣࡄࡸ࡭ࡱࡪࡕࡶ࡫ࡧࠫᕤ")] = bstack11l1lll111_opy_
            options[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡥࡹ࡮ࡲࡤࡑࡴࡲࡨࡺࡩࡴࡎࡣࡳࠫᕥ")] = bstack111lll1l11_opy_
    return options
def bstack1lll1l1l1l1_opy_(ws_endpoint, framework):
    bstack111lll1l11_opy_ = bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠦࡕࡒࡁ࡚࡙ࡕࡍࡌࡎࡔࡠࡒࡕࡓࡉ࡛ࡃࡕࡡࡐࡅࡕࠨᕦ"))
    if ws_endpoint and len(ws_endpoint.split(bstack1l1111l_opy_ (u"ࠬࡩࡡࡱࡵࡀࠫᕧ"))) > 1:
        ws_url = ws_endpoint.split(bstack1l1111l_opy_ (u"࠭ࡣࡢࡲࡶࡁࠬᕨ"))[0]
        if bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯ࠪᕩ") in ws_url:
            from browserstack_sdk._version import __version__
            bstack1llll111ll1_opy_ = json.loads(urllib.parse.unquote(ws_endpoint.split(bstack1l1111l_opy_ (u"ࠨࡥࡤࡴࡸࡃࠧᕪ"))[1]))
            bstack1llll111ll1_opy_ = bstack1llll111ll1_opy_ or {}
            bstack11l1lll111_opy_ = os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧᕫ")]
            bstack1llll111ll1_opy_[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫᕬ")] = str(framework) + str(__version__)
            bstack1llll111ll1_opy_[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᕭ")] = bstack1lll11lll11_opy_()
            bstack1llll111ll1_opy_[bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡹ࡫ࡳࡵࡪࡸࡦࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧᕮ")] = bstack11l1lll111_opy_
            bstack1llll111ll1_opy_[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡨࡵࡪ࡮ࡧࡔࡷࡵࡤࡶࡥࡷࡑࡦࡶࠧᕯ")] = bstack111lll1l11_opy_
            ws_endpoint = ws_endpoint.split(bstack1l1111l_opy_ (u"ࠧࡤࡣࡳࡷࡂ࠭ᕰ"))[0] + bstack1l1111l_opy_ (u"ࠨࡥࡤࡴࡸࡃࠧᕱ") + urllib.parse.quote(json.dumps(bstack1llll111ll1_opy_))
    return ws_endpoint
def bstack111lll11l_opy_():
    global bstack11l1l11l1_opy_
    from playwright._impl._browser_type import BrowserType
    bstack11l1l11l1_opy_ = BrowserType.connect
    return bstack11l1l11l1_opy_
def bstack1l1l1l11l1_opy_(framework_name):
    global bstack11ll111ll1_opy_
    bstack11ll111ll1_opy_ = framework_name
    return framework_name
def bstack1l11111ll_opy_(self, *args, **kwargs):
    global bstack11l1l11l1_opy_
    try:
        global bstack11ll111ll1_opy_
        if bstack1l1111l_opy_ (u"ࠩࡺࡷࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭ᕲ") in kwargs:
            kwargs[bstack1l1111l_opy_ (u"ࠪࡻࡸࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧᕳ")] = bstack1lll1l1l1l1_opy_(
                kwargs.get(bstack1l1111l_opy_ (u"ࠫࡼࡹࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨᕴ"), None),
                bstack11ll111ll1_opy_
            )
    except Exception as e:
        logger.error(bstack1l1111l_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡥ࡯ࠢࡳࡶࡴࡩࡥࡴࡵ࡬ࡲ࡬ࠦࡓࡅࡍࠣࡧࡦࡶࡳ࠻ࠢࡾࢁࠧᕵ").format(str(e)))
    return bstack11l1l11l1_opy_(self, *args, **kwargs)
def bstack1lll1l111l1_opy_(bstack1lll1l1lll1_opy_, proxies):
    proxy_settings = {}
    try:
        if not proxies:
            proxies = bstack1lll11llll_opy_(bstack1lll1l1lll1_opy_, bstack1l1111l_opy_ (u"ࠨࠢᕶ"))
        if proxies and proxies.get(bstack1l1111l_opy_ (u"ࠢࡩࡶࡷࡴࡸࠨᕷ")):
            parsed_url = urlparse(proxies.get(bstack1l1111l_opy_ (u"ࠣࡪࡷࡸࡵࡹࠢᕸ")))
            if parsed_url and parsed_url.hostname: proxy_settings[bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡾࡹࡉࡱࡶࡸࠬᕹ")] = str(parsed_url.hostname)
            if parsed_url and parsed_url.port: proxy_settings[bstack1l1111l_opy_ (u"ࠪࡴࡷࡵࡸࡺࡒࡲࡶࡹ࠭ᕺ")] = str(parsed_url.port)
            if parsed_url and parsed_url.username: proxy_settings[bstack1l1111l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡘࡷࡪࡸࠧᕻ")] = str(parsed_url.username)
            if parsed_url and parsed_url.password: proxy_settings[bstack1l1111l_opy_ (u"ࠬࡶࡲࡰࡺࡼࡔࡦࡹࡳࠨᕼ")] = str(parsed_url.password)
        return proxy_settings
    except:
        return proxy_settings
def bstack1l1l1ll1l_opy_(bstack1lll1l1lll1_opy_):
    bstack1llll1111l1_opy_ = {
        bstack1111ll1l1l_opy_[bstack1llll11lll1_opy_]: bstack1lll1l1lll1_opy_[bstack1llll11lll1_opy_]
        for bstack1llll11lll1_opy_ in bstack1lll1l1lll1_opy_
        if bstack1llll11lll1_opy_ in bstack1111ll1l1l_opy_
    }
    bstack1llll1111l1_opy_[bstack1l1111l_opy_ (u"ࠨࡰࡳࡱࡻࡽࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨᕽ")] = bstack1lll1l111l1_opy_(bstack1lll1l1lll1_opy_, bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠢࡱࡴࡲࡼࡾ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠢᕾ")))
    bstack1lll1l1ll11_opy_ = [element.lower() for element in bstack1111l1l1ll_opy_]
    bstack1lll1ll1l11_opy_(bstack1llll1111l1_opy_, bstack1lll1l1ll11_opy_)
    return bstack1llll1111l1_opy_
def bstack1lll1ll1l11_opy_(d, keys):
    for key in list(d.keys()):
        if key.lower() in keys:
            d[key] = bstack1l1111l_opy_ (u"ࠣࠬ࠭࠮࠯ࠨᕿ")
    for value in d.values():
        if isinstance(value, dict):
            bstack1lll1ll1l11_opy_(value, keys)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    bstack1lll1ll1l11_opy_(item, keys)