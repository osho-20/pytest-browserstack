# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
from filelock import FileLock
import json
import os
import time
import uuid
from typing import Dict, List, Optional
from bstack_utils.constants import bstack111l1llll1_opy_, EVENTS
from bstack_utils.helper import bstack1ll1l11111_opy_, get_host_info, bstack11l11l11_opy_
from datetime import datetime
from bstack_utils.bstack11lll111ll_opy_ import get_logger
logger = get_logger(__name__)
bstack111ll111l1_opy_: Dict[str, float] = {}
bstack111ll1111l_opy_: List = []
bstack111l1lll11_opy_ = os.path.join(os.getcwd(), bstack1l1111l_opy_ (u"ࠫࡱࡵࡧࠨ྅"), bstack1l1111l_opy_ (u"ࠬࡱࡥࡺ࠯ࡰࡩࡹࡸࡩࡤࡵ࠱࡮ࡸࡵ࡮ࠨ྆"))
lock = FileLock(bstack111l1lll11_opy_+bstack1l1111l_opy_ (u"ࠨ࠮࡭ࡱࡦ࡯ࠧ྇"))
class bstack111l1lll1l_opy_:
    duration: float
    name: str
    startTime: float
    worker: int
    status: bool
    failure: str
    details: Optional[str]
    entryType: str
    platform: Optional[int]
    command: Optional[str]
    hookType: Optional[str]
    def __init__(self, duration: float, name: str, start_time: float, bstack111ll11l11_opy_: int, status: bool, failure: str, details: Optional[str] = None, platform: Optional[int] = None, command: Optional[str] = None, test_name: Optional[str] = None, hook_type: Optional[str] = None) -> None:
        self.duration = duration
        self.name = name
        self.startTime = start_time
        self.worker = bstack111ll11l11_opy_
        self.status = status
        self.failure = failure
        self.details = details
        self.entryType = bstack1l1111l_opy_ (u"ࠢ࡮ࡧࡤࡷࡺࡸࡥࠣྈ")
        self.platform = platform
        self.command = command
        self.testName = test_name
        self.hookType = hook_type
class bstack111ll11ll1_opy_:
    global bstack111ll111l1_opy_
    @staticmethod
    def mark(key: str) -> None:
        try:
            bstack111ll111l1_opy_[key] = time.time_ns() / 1000000
        except Exception as e:
            logger.debug(bstack111l1lllll_opy_ (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽࡨࢁࠧྉ"))
    @staticmethod
    def end(label: str, start: str, end: str, status: bool, failure: Optional[str], hook_type: Optional[str] = None, details: Optional[str] = None, command: Optional[str] = None, test_name: Optional[str] = None) -> None:
        try:
            bstack111ll11ll1_opy_.mark(end)
            bstack111ll11ll1_opy_.measure(label, start, end, status, failure, hook_type, details, command, test_name)
        except Exception as e:
            logger.debug(bstack111l1lllll_opy_ (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾࡩࢂࠨྊ"))
    @staticmethod
    def measure(label: str, start: str, end: str, status: bool, failure: Optional[str], hook_type: Optional[str] = None, details: Optional[str] = None, command: Optional[str] = None, test_name: Optional[str] = None) -> None:
        try:
            if start not in bstack111ll111l1_opy_ or end not in bstack111ll111l1_opy_:
                logger.debug(bstack1l1111l_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡴࡢࡴࡷࠤࡰ࡫ࡹࠡࡹ࡬ࡸ࡭ࠦࡶࡢ࡮ࡸࡩࠥࢁࡽࠡࡱࡵࠤࡪࡴࡤࠡ࡭ࡨࡽࠥࡽࡩࡵࡪࠣࡺࡦࡲࡵࡦࠢࡾࢁࠧྋ").format(start,end))
                return
            duration: float = bstack111ll111l1_opy_[end] - bstack111ll111l1_opy_[start]
            bstack111ll11111_opy_: bstack111l1lll1l_opy_ = bstack111l1lll1l_opy_(duration, label, bstack111ll111l1_opy_[start], os.getpid(), status, failure, details, os.environ.get(bstack1l1111l_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠦྌ"), 0), command, test_name, hook_type)
            del bstack111ll111l1_opy_[start]
            del bstack111ll111l1_opy_[end]
            bstack111ll11ll1_opy_.bstack111ll111ll_opy_(bstack111ll11111_opy_)
            if label == EVENTS.bstack111lllllll_opy_.value:
                bstack111ll11ll1_opy_.bstack1l1ll111_opy_()
        except Exception as e:
            logger.debug(bstack111l1lllll_opy_ (u"ࠧࡋࡲࡳࡱࡵ࠾ࠥࢁࡥࡾࠤྍ"))
    @staticmethod
    def bstack111ll111ll_opy_(bstack111ll11111_opy_):
        os.makedirs(os.path.dirname(bstack111l1lll11_opy_)) if not os.path.exists(os.path.dirname(bstack111l1lll11_opy_)) else None
        try:
            with lock:
                with open(bstack111l1lll11_opy_, bstack1l1111l_opy_ (u"ࠨࡲࠬࠤྎ"), encoding=bstack1l1111l_opy_ (u"ࠢࡶࡶࡩ࠱࠽ࠨྏ")) as file:
                    try:
                        data = json.load(file)
                    except json.JSONDecodeError:
                        data = []
                    data.append(bstack111ll11111_opy_.__dict__)
                    file.seek(0)
                    file.truncate()
                    json.dump(data, file, indent=4)
        except FileNotFoundError:
            with lock:
                with open(bstack111l1lll11_opy_, bstack1l1111l_opy_ (u"ࠣࡹࠥྐ"), encoding=bstack1l1111l_opy_ (u"ࠤࡸࡸ࡫࠳࠸ࠣྑ")) as file:
                    data = [bstack111ll11111_opy_.__dict__]
                    json.dump(data, file, indent=4)
    @staticmethod
    def bstack1l1ll111_opy_():
        try:
            with lock:
                with open(bstack111l1lll11_opy_, bstack1l1111l_opy_ (u"ࠥࡶࠧྒ"), encoding=bstack1l1111l_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥྒྷ")) as file:
                    data = json.load(file)
                    config = {
                        bstack1l1111l_opy_ (u"ࠧ࡮ࡥࡢࡦࡨࡶࡸࠨྔ"): {
                            bstack1l1111l_opy_ (u"ࠨࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠧྕ"): bstack1l1111l_opy_ (u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠥྖ"),
                        }
                    }
                    bstack111l1ll1ll_opy_ = datetime.utcnow()
                    bstack1llll111_opy_ = bstack111l1ll1ll_opy_.strftime(bstack1l1111l_opy_ (u"ࠣࠧ࡜࠱ࠪࡳ࠭ࠦࡦࡗࠩࡍࡀࠥࡎ࠼ࠨࡗ࠳ࠫࡦࠡࡗࡗࡇࠧྗ"))
                    test_id = os.environ.get(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧ྘")) if os.environ.get(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨྙ")) else bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠦࡸࡪ࡫ࡓࡷࡱࡍࡩࠨྚ"))
                    payload = {
                        bstack1l1111l_opy_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤྛ"): bstack1l1111l_opy_ (u"ࠨࡳࡥ࡭ࡢࡩࡻ࡫࡮ࡵࡵࠥྜ"),
                        bstack1l1111l_opy_ (u"ࠢࡥࡣࡷࡥࠧྜྷ"): {
                            bstack1l1111l_opy_ (u"ࠣࡶࡨࡷࡹ࡮ࡵࡣࡡࡸࡹ࡮ࡪࠢྞ"): test_id,
                            bstack1l1111l_opy_ (u"ࠤࡦࡶࡪࡧࡴࡦࡦࡢࡨࡦࡿࠢྟ"): bstack1llll111_opy_,
                            bstack1l1111l_opy_ (u"ࠥࡩࡻ࡫࡮ࡵࡡࡱࡥࡲ࡫ࠢྠ"): bstack1l1111l_opy_ (u"ࠦࡘࡊࡋࡇࡧࡤࡸࡺࡸࡥࡑࡧࡵࡪࡴࡸ࡭ࡢࡰࡦࡩࠧྡ"),
                            bstack1l1111l_opy_ (u"ࠧ࡫ࡶࡦࡰࡷࡣ࡯ࡹ࡯࡯ࠤྡྷ"): {
                                bstack1l1111l_opy_ (u"ࠨ࡭ࡦࡣࡶࡹࡷ࡫ࡳࠣྣ"): data
                            },
                            bstack1l1111l_opy_ (u"ࠢࡶࡵࡨࡶࡤࡪࡡࡵࡣࠥྤ"): bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠣࡷࡶࡩࡷࡔࡡ࡮ࡧࠥྥ")),
                            bstack1l1111l_opy_ (u"ࠤ࡫ࡳࡸࡺ࡟ࡪࡰࡩࡳࠧྦ"): get_host_info()
                        }
                    }
                    response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"ࠥࡔࡔ࡙ࡔࠣྦྷ"), bstack111l1llll1_opy_, payload, config)
                    if(response.status_code >= 200 and response.status_code < 300):
                        logger.info(bstack1l1111l_opy_ (u"ࠦࡉࡧࡴࡢࠢࡶࡩࡳࡺࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࡴࡰࠢࡾࢁࠥࡽࡩࡵࡪࠣࡨࡦࡺࡡࠡࡽࢀࠦྨ").format(bstack111l1llll1_opy_, payload))
                    else:
                        logger.info(bstack1l1111l_opy_ (u"ࠧࡘࡥࡲࡷࡨࡷࡹࠦࡦࡢ࡫࡯ࡩࡩࠦࡦࡰࡴࠣࡿࢂࠦࡷࡪࡶ࡫ࠤࡩࡧࡴࡢࠢࡾࢁࠧྩ").format(bstack111l1llll1_opy_, payload))
        except Exception as e:
            logger.info(bstack1l1111l_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡩࡳࡪࠠ࡬ࡧࡼࠤࡲ࡫ࡴࡳ࡫ࡦࡷࠥࡪࡡࡵࡣࠣࡻ࡮ࡺࡨࠡࡧࡵࡶࡴࡸࠠࡼࡿࠥྪ").format(e))
        os.remove(bstack111l1lll11_opy_)
    @staticmethod
    def bstack111ll11l1l_opy_(label: str) -> str:
        try:
            return bstack1l1111l_opy_ (u"ࠢࡼࡿ࠽ࡿࢂࠨྫ").format(label,str(uuid.uuid4().hex)[:6])
        except Exception as e:
            logger.debug(bstack111l1lllll_opy_ (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽࡨࢁࠧྫྷ"))