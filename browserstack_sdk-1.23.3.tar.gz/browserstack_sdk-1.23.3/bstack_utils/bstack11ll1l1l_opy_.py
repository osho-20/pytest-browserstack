# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
import threading
from bstack_utils.helper import bstack11ll111lll_opy_
from bstack_utils.constants import bstack1111l1lll1_opy_, EVENTS, STAGE
from bstack_utils.bstack11lll111ll_opy_ import get_logger
logger = get_logger(__name__)
class bstack1l11l1ll_opy_:
    bstack11111l111l_opy_ = None
    @classmethod
    def bstack1l1l1l11l_opy_(cls):
        if cls.on():
            logger.info(
                bstack1l1111l_opy_ (u"ࠧࡗ࡫ࡶ࡭ࡹࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡦࡺ࡯࡬ࡥࡵ࠲ࡿࢂࠦࡴࡰࠢࡹ࡭ࡪࡽࠠࡣࡷ࡬ࡰࡩࠦࡲࡦࡲࡲࡶࡹ࠲ࠠࡪࡰࡶ࡭࡬࡮ࡴࡴ࠮ࠣࡥࡳࡪࠠ࡮ࡣࡱࡽࠥࡳ࡯ࡳࡧࠣࡨࡪࡨࡵࡨࡩ࡬ࡲ࡬ࠦࡩ࡯ࡨࡲࡶࡲࡧࡴࡪࡱࡱࠤࡦࡲ࡬ࠡࡣࡷࠤࡴࡴࡥࠡࡲ࡯ࡥࡨ࡫ࠡ࡝ࡰࠪፀ").format(os.environ[bstack1l1111l_opy_ (u"ࠣࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡍࡇࡓࡉࡇࡇࡣࡎࡊࠢፁ")]))
    @classmethod
    def on(cls):
        if os.environ.get(bstack1l1111l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪፂ"), None) is None or os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡋ࡙ࡗࠫፃ")] == bstack1l1111l_opy_ (u"ࠦࡳࡻ࡬࡭ࠤፄ"):
            return False
        return True
    @classmethod
    def bstack11111l1l11_opy_(cls, bs_config, framework=bstack1l1111l_opy_ (u"ࠧࠨፅ")):
        bstack11111l1111_opy_ = False
        for fw in bstack1111l1lll1_opy_:
            if fw in framework:
                bstack11111l1111_opy_ = True
        return bstack11ll111lll_opy_(bs_config.get(bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪፆ"), bstack11111l1111_opy_))
    @classmethod
    def bstack11111l1l1l_opy_(cls, framework):
        return framework in bstack1111l1lll1_opy_
    @classmethod
    def bstack11111l11ll_opy_(cls, bs_config, framework):
        return cls.bstack11111l1l11_opy_(bs_config, framework) is True and cls.bstack11111l1l1l_opy_(framework)
    @staticmethod
    def current_hook_uuid():
        return getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡪࡲࡳࡰࡥࡵࡶ࡫ࡧࠫፇ"), None)
    @staticmethod
    def bstack1l1ll11l_opy_():
        if getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡶࡷ࡬ࡨࠬፈ"), None):
            return {
                bstack1l1111l_opy_ (u"ࠩࡷࡽࡵ࡫ࠧፉ"): bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࠨፊ"),
                bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫፋ"): getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩፌ"), None)
            }
        if getattr(threading.current_thread(), bstack1l1111l_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡩࡱࡲ࡯ࡤࡻࡵࡪࡦࠪፍ"), None):
            return {
                bstack1l1111l_opy_ (u"ࠧࡵࡻࡳࡩࠬፎ"): bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰ࠭ፏ"),
                bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩፐ"): getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧፑ"), None)
            }
        return None
    @staticmethod
    def bstack111111llll_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1l11l1ll_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def bstack1ll11l11_opy_(test, hook_name=None):
        bstack111111ll1l_opy_ = test.parent
        if hook_name in [bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡧࡱࡧࡳࡴࠩፒ"), bstack1l1111l_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࡟ࡤ࡮ࡤࡷࡸ࠭ፓ"), bstack1l1111l_opy_ (u"࠭ࡳࡦࡶࡸࡴࡤࡳ࡯ࡥࡷ࡯ࡩࠬፔ"), bstack1l1111l_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡰࡳࡩࡻ࡬ࡦࠩፕ")]:
            bstack111111ll1l_opy_ = test
        scope = []
        while bstack111111ll1l_opy_ is not None:
            scope.append(bstack111111ll1l_opy_.name)
            bstack111111ll1l_opy_ = bstack111111ll1l_opy_.parent
        scope.reverse()
        return scope[2:]
    @staticmethod
    def bstack111111lll1_opy_(hook_type):
        if hook_type == bstack1l1111l_opy_ (u"ࠣࡄࡈࡊࡔࡘࡅࡠࡇࡄࡇࡍࠨፖ"):
            return bstack1l1111l_opy_ (u"ࠤࡖࡩࡹࡻࡰࠡࡪࡲࡳࡰࠨፗ")
        elif hook_type == bstack1l1111l_opy_ (u"ࠥࡅࡋ࡚ࡅࡓࡡࡈࡅࡈࡎࠢፘ"):
            return bstack1l1111l_opy_ (u"࡙ࠦ࡫ࡡࡳࡦࡲࡻࡳࠦࡨࡰࡱ࡮ࠦፙ")
    @staticmethod
    def bstack11111l11l1_opy_(bstack111ll1ll_opy_):
        try:
            if not bstack1l11l1ll_opy_.on():
                return bstack111ll1ll_opy_
            if os.environ.get(bstack1l1111l_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡗࡋࡒࡖࡐࠥፚ"), None) == bstack1l1111l_opy_ (u"ࠨࡴࡳࡷࡨࠦ፛"):
                tests = os.environ.get(bstack1l1111l_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡒࡆࡔࡘࡒࡤ࡚ࡅࡔࡖࡖࠦ፜"), None)
                if tests is None or tests == bstack1l1111l_opy_ (u"ࠣࡰࡸࡰࡱࠨ፝"):
                    return bstack111ll1ll_opy_
                bstack111ll1ll_opy_ = tests.split(bstack1l1111l_opy_ (u"ࠩ࠯ࠫ፞"))
                return bstack111ll1ll_opy_
        except Exception as exc:
            logger.debug(bstack111l1lllll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡵࡩࡷࡻ࡮ࠡࡪࡤࡲࡩࡲࡥࡳ࠼ࠣࡿࡸࡺࡲࠩࡧࡻࡧ࠮ࢃࠢ፟"))
        return bstack111ll1ll_opy_