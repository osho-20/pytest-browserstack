# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
class bstack1ll1l1l11l_opy_:
    def __init__(self, handler):
        self._11111ll111_opy_ = None
        self.handler = handler
        self._11111ll11l_opy_ = self.bstack11111l1ll1_opy_()
        self.patch()
    def patch(self):
        self._11111ll111_opy_ = self._11111ll11l_opy_.execute
        self._11111ll11l_opy_.execute = self.bstack11111l1lll_opy_()
    def bstack11111l1lll_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            self.handler(bstack1l1111l_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࠧጾ"), driver_command, None, this, args)
            response = self._11111ll111_opy_(this, driver_command, *args, **kwargs)
            self.handler(bstack1l1111l_opy_ (u"ࠨࡡࡧࡶࡨࡶࠧጿ"), driver_command, response)
            return response
        return execute
    def reset(self):
        self._11111ll11l_opy_.execute = self._11111ll111_opy_
    @staticmethod
    def bstack11111l1ll1_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver