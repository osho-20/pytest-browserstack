# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.config import Config
from bstack_utils.messages import bstack111l11l1l1_opy_
bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
def bstack111l1l1111_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack111l11ll1l_opy_(bstack111l11llll_opy_, bstack111l11lll1_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack111l11llll_opy_):
        with open(bstack111l11llll_opy_) as f:
            pac = PACFile(f.read())
    elif bstack111l1l1111_opy_(bstack111l11llll_opy_):
        pac = get_pac(url=bstack111l11llll_opy_)
    else:
        raise Exception(bstack1l1111l_opy_ (u"ࠪࡔࡦࡩࠠࡧ࡫࡯ࡩࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡦࡺ࡬ࡷࡹࡀࠠࡼࡿࠪ࿦").format(bstack111l11llll_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack1l1111l_opy_ (u"ࠦ࠽࠴࠸࠯࠺࠱࠼ࠧ࿧"), 80))
        bstack111l11ll11_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack111l11ll11_opy_ = bstack1l1111l_opy_ (u"ࠬ࠶࠮࠱࠰࠳࠲࠵࠭࿨")
    proxy_url = session.get_pac().find_proxy_for_url(bstack111l11lll1_opy_, bstack111l11ll11_opy_)
    return proxy_url
def bstack1l1llll111_opy_(config):
    return bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩ࿩") in config or bstack1l1111l_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫ࿪") in config
def bstack1ll1llll11_opy_(config):
    if not bstack1l1llll111_opy_(config):
        return
    if config.get(bstack1l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡖࡲࡰࡺࡼࠫ࿫")):
        return config.get(bstack1l1111l_opy_ (u"ࠩ࡫ࡸࡹࡶࡐࡳࡱࡻࡽࠬ࿬"))
    if config.get(bstack1l1111l_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧ࿭")):
        return config.get(bstack1l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨ࿮"))
def bstack1lll11llll_opy_(config, bstack111l11lll1_opy_):
    proxy = bstack1ll1llll11_opy_(config)
    proxies = {}
    if config.get(bstack1l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨ࿯")) or config.get(bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ࿰")):
        if proxy.endswith(bstack1l1111l_opy_ (u"ࠧ࠯ࡲࡤࡧࠬ࿱")):
            proxies = bstack111lll11l1_opy_(proxy, bstack111l11lll1_opy_)
        else:
            proxies = {
                bstack1l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ࿲"): proxy
            }
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡾࡹࡔࡧࡷࡸ࡮ࡴࡧࡴࠩ࿳"), proxies)
    return proxies
def bstack111lll11l1_opy_(bstack111l11llll_opy_, bstack111l11lll1_opy_):
    proxies = {}
    global bstack111l11l1ll_opy_
    if bstack1l1111l_opy_ (u"ࠪࡔࡆࡉ࡟ࡑࡔࡒ࡜࡞࠭࿴") in globals():
        return bstack111l11l1ll_opy_
    try:
        proxy = bstack111l11ll1l_opy_(bstack111l11llll_opy_, bstack111l11lll1_opy_)
        if bstack1l1111l_opy_ (u"ࠦࡉࡏࡒࡆࡅࡗࠦ࿵") in proxy:
            proxies = {}
        elif bstack1l1111l_opy_ (u"ࠧࡎࡔࡕࡒࠥ࿶") in proxy or bstack1l1111l_opy_ (u"ࠨࡈࡕࡖࡓࡗࠧ࿷") in proxy or bstack1l1111l_opy_ (u"ࠢࡔࡑࡆࡏࡘࠨ࿸") in proxy:
            bstack111l1l111l_opy_ = proxy.split(bstack1l1111l_opy_ (u"ࠣࠢࠥ࿹"))
            if bstack1l1111l_opy_ (u"ࠤ࠽࠳࠴ࠨ࿺") in bstack1l1111l_opy_ (u"ࠥࠦ࿻").join(bstack111l1l111l_opy_[1:]):
                proxies = {
                    bstack1l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ࿼"): bstack1l1111l_opy_ (u"ࠧࠨ࿽").join(bstack111l1l111l_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷࠬ࿾"): str(bstack111l1l111l_opy_[0]).lower() + bstack1l1111l_opy_ (u"ࠢ࠻࠱࠲ࠦ࿿") + bstack1l1111l_opy_ (u"ࠣࠤက").join(bstack111l1l111l_opy_[1:])
                }
        elif bstack1l1111l_opy_ (u"ࠤࡓࡖࡔ࡞࡙ࠣခ") in proxy:
            bstack111l1l111l_opy_ = proxy.split(bstack1l1111l_opy_ (u"ࠥࠤࠧဂ"))
            if bstack1l1111l_opy_ (u"ࠦ࠿࠵࠯ࠣဃ") in bstack1l1111l_opy_ (u"ࠧࠨင").join(bstack111l1l111l_opy_[1:]):
                proxies = {
                    bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷࠬစ"): bstack1l1111l_opy_ (u"ࠢࠣဆ").join(bstack111l1l111l_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧဇ"): bstack1l1111l_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥဈ") + bstack1l1111l_opy_ (u"ࠥࠦဉ").join(bstack111l1l111l_opy_[1:])
                }
        else:
            proxies = {
                bstack1l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࠪည"): proxy
            }
    except Exception as e:
        print(bstack1l1111l_opy_ (u"ࠧࡹ࡯࡮ࡧࠣࡩࡷࡸ࡯ࡳࠤဋ"), bstack111l11l1l1_opy_.format(bstack111l11llll_opy_, str(e)))
    bstack111l11l1ll_opy_ = proxies
    return proxies