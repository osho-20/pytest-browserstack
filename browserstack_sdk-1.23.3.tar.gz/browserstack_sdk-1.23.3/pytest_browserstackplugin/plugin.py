# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import atexit
import datetime
import inspect
import logging
import signal
import threading
from uuid import uuid4
from bstack_utils.measure import bstack1ll1111ll1_opy_
from bstack_utils.percy_sdk import PercySDK
import pytest
from packaging import version
from browserstack_sdk.__init__ import (bstack1l111ll111_opy_, bstack1l111lll1_opy_, update, bstack11lllll11_opy_,
                                       bstack1ll1l11ll_opy_, bstack1l11ll11ll_opy_, bstack111ll1l11_opy_, bstack1l1l11ll11_opy_,
                                       bstack1llll111l1_opy_, bstack111lll1ll_opy_, bstack11ll1ll1l1_opy_, bstack111111l11_opy_,
                                       bstack1lll1l111l_opy_, getAccessibilityResults, getAccessibilityResultsSummary, perform_scan, bstack1111l1l1l_opy_)
from browserstack_sdk.bstack1111l11l_opy_ import bstack11l11111_opy_
from browserstack_sdk._version import __version__
from bstack_utils import bstack11lll111ll_opy_
from bstack_utils.capture import bstack1l11ll1l_opy_
from bstack_utils.config import Config
from bstack_utils.percy import *
from bstack_utils.constants import bstack11ll11l1ll_opy_, bstack1lll111ll_opy_, bstack11111lll1_opy_, \
    bstack1lll11ll11_opy_
from bstack_utils.helper import bstack1l111ll1_opy_, bstack1llll11ll1l_opy_, bstack1l1l1ll1_opy_, bstack11ll1llll_opy_, bstack1lll11lll11_opy_, bstack1llll111_opy_, \
    bstack1lll1lll111_opy_, \
    bstack1llll11l11l_opy_, bstack1ll11llll1_opy_, bstack1ll111111l_opy_, bstack1llll1ll1ll_opy_, bstack1llll1ll1_opy_, Notset, \
    bstack1llll1111_opy_, bstack1llll11ll11_opy_, bstack1lll1l1llll_opy_, Result, bstack1lll1l1111l_opy_, bstack1llll11111l_opy_, bstack11llllll_opy_, \
    bstack11l1ll1ll_opy_, bstack1ll1lll11l_opy_, bstack11ll111lll_opy_, bstack1lll11ll111_opy_
from bstack_utils.bstack1111llll1l_opy_ import bstack111l11l11l_opy_
from bstack_utils.messages import bstack11lll11lll_opy_, bstack1l1111l1l1_opy_, bstack1ll111l11l_opy_, bstack1l1l1l11ll_opy_, bstack111lllll_opy_, \
    bstack11l1l11l11_opy_, bstack1ll11111ll_opy_, bstack11l1l1ll11_opy_, bstack1l11l1lll1_opy_, bstack11llll1l11_opy_, \
    bstack1l1llll1l_opy_, bstack1lll11111l_opy_
from bstack_utils.proxy import bstack1ll1llll11_opy_, bstack111lll11l1_opy_
from bstack_utils.bstack11l11lll1l_opy_ import bstack111111l1ll_opy_, bstack1111111ll1_opy_, bstack111111ll11_opy_, bstack1111111lll_opy_, \
    bstack1111111111_opy_, bstack111111l111_opy_, bstack111111l1l1_opy_, bstack1l111l11l_opy_, bstack1111111l11_opy_
from bstack_utils.bstack1l1ll111l_opy_ import bstack1ll1l1l11l_opy_
from bstack_utils.bstack1llll11ll_opy_ import bstack1l11l1lll_opy_, bstack111l1lll1_opy_, bstack11ll1l11l1_opy_, \
    bstack11ll1111ll_opy_, bstack11l1l1l1ll_opy_
from bstack_utils.bstack11llll1l_opy_ import bstack1l1l1lll_opy_
from bstack_utils.bstack11ll1l1l_opy_ import bstack1l11l1ll_opy_
import bstack_utils.accessibility as bstack1111ll11_opy_
from bstack_utils.bstack1ll1l1l1_opy_ import bstack1l11l1l1_opy_
from bstack_utils.bstack1l1llll1l1_opy_ import bstack1l1llll1l1_opy_
from browserstack_sdk.__init__ import bstack11111l111_opy_
bstack1ll1ll111_opy_ = None
bstack1l111l1lll_opy_ = None
bstack11l1l1l11l_opy_ = None
bstack1lll1ll1l_opy_ = None
bstack1111l1lll_opy_ = None
bstack1lll11l11l_opy_ = None
bstack111ll11l1_opy_ = None
bstack1ll1111111_opy_ = None
bstack1ll11ll1ll_opy_ = None
bstack11lllllll_opy_ = None
bstack11lll11l1l_opy_ = None
bstack11lll1llll_opy_ = None
bstack11llll1ll1_opy_ = None
bstack11ll111ll1_opy_ = bstack1l1111l_opy_ (u"ࠪࠫᢟ")
CONFIG = {}
bstack11l1lll1l_opy_ = False
bstack11l11l111l_opy_ = bstack1l1111l_opy_ (u"ࠫࠬᢠ")
bstack111111ll1_opy_ = bstack1l1111l_opy_ (u"ࠬ࠭ᢡ")
bstack1l1ll1ll1l_opy_ = False
bstack11llll1ll_opy_ = []
bstack1l1l1lllll_opy_ = bstack11ll11l1ll_opy_
bstack1l1ll11ll1l_opy_ = bstack1l1111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᢢ")
bstack1l1l11l11_opy_ = {}
bstack1l1l11l1l_opy_ = None
bstack11111ll11_opy_ = False
logger = bstack11lll111ll_opy_.get_logger(__name__, bstack1l1l1lllll_opy_)
store = {
    bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡪࡲࡳࡰࡥࡵࡶ࡫ࡧࠫᢣ"): []
}
bstack1l1ll11llll_opy_ = False
try:
    from playwright.sync_api import (
        BrowserContext,
        Page
    )
except:
    pass
import json
_1lll11l1_opy_ = {}
current_test_uuid = None
def bstack1l11l1l1l1_opy_(page, bstack11lll1l11l_opy_):
    try:
        page.evaluate(bstack1l1111l_opy_ (u"ࠣࡡࠣࡁࡃࠦࡻࡾࠤᢤ"),
                      bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨ࡮ࡢ࡯ࡨࠦ࠿࠭ᢥ") + json.dumps(
                          bstack11lll1l11l_opy_) + bstack1l1111l_opy_ (u"ࠥࢁࢂࠨᢦ"))
    except Exception as e:
        print(bstack1l1111l_opy_ (u"ࠦࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡰࡤࡱࡪࠦࡻࡾࠤᢧ"), e)
def bstack11ll1lll1_opy_(page, message, level):
    try:
        page.evaluate(bstack1l1111l_opy_ (u"ࠧࡥࠠ࠾ࡀࠣࡿࢂࠨᢨ"), bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡩࡧࡴࡢࠤ࠽ᢩࠫ") + json.dumps(
            message) + bstack1l1111l_opy_ (u"ࠧ࠭ࠤ࡯ࡩࡻ࡫࡬ࠣ࠼ࠪᢪ") + json.dumps(level) + bstack1l1111l_opy_ (u"ࠨࡿࢀࠫ᢫"))
    except Exception as e:
        print(bstack1l1111l_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡧ࡮࡯ࡱࡷࡥࡹ࡯࡯࡯ࠢࡾࢁࠧ᢬"), e)
def pytest_configure(config):
    bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
    config.args = bstack1l11l1ll_opy_.bstack11111l11l1_opy_(config.args)
    bstack11l11l11_opy_.bstack1l1l111l11_opy_(bstack11ll111lll_opy_(config.getoption(bstack1l1111l_opy_ (u"ࠪࡷࡰ࡯ࡰࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧ᢭"))))
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    bstack1l1ll1l11ll_opy_ = item.config.getoption(bstack1l1111l_opy_ (u"ࠫࡸࡱࡩࡱࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭᢮"))
    plugins = item.config.getoption(bstack1l1111l_opy_ (u"ࠧࡶ࡬ࡶࡩ࡬ࡲࡸࠨ᢯"))
    report = outcome.get_result()
    bstack1l1ll1lll1l_opy_(item, call, report)
    if bstack1l1111l_opy_ (u"ࠨࡰࡺࡶࡨࡷࡹࡥࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡵࡲࡵࡨ࡫ࡱࠦᢰ") not in plugins or bstack1llll1ll1_opy_():
        return
    summary = []
    driver = getattr(item, bstack1l1111l_opy_ (u"ࠢࡠࡦࡵ࡭ࡻ࡫ࡲࠣᢱ"), None)
    page = getattr(item, bstack1l1111l_opy_ (u"ࠣࡡࡳࡥ࡬࡫ࠢᢲ"), None)
    try:
        if (driver == None or driver.session_id == None):
            driver = threading.current_thread().bstackSessionDriver
    except:
        pass
    item._driver = driver
    if (driver is not None):
        bstack1l1ll1ll11l_opy_(item, report, summary, bstack1l1ll1l11ll_opy_)
    if (page is not None):
        bstack1l1ll11lll1_opy_(item, report, summary, bstack1l1ll1l11ll_opy_)
def bstack1l1ll1ll11l_opy_(item, report, summary, bstack1l1ll1l11ll_opy_):
    if report.when == bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨᢳ") and report.skipped:
        bstack1111111l11_opy_(report)
    if report.when in [bstack1l1111l_opy_ (u"ࠥࡷࡪࡺࡵࡱࠤᢴ"), bstack1l1111l_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࠨᢵ")]:
        return
    if not bstack1lll11lll11_opy_():
        return
    try:
        if (str(bstack1l1ll1l11ll_opy_).lower() != bstack1l1111l_opy_ (u"ࠬࡺࡲࡶࡧࠪᢶ")):
            item._driver.execute_script(
                bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠣࠫᢷ") + json.dumps(
                    report.nodeid) + bstack1l1111l_opy_ (u"ࠧࡾࡿࠪᢸ"))
        os.environ[bstack1l1111l_opy_ (u"ࠨࡒ࡜ࡘࡊ࡙ࡔࡠࡖࡈࡗ࡙ࡥࡎࡂࡏࡈࠫᢹ")] = report.nodeid
    except Exception as e:
        summary.append(
            bstack1l1111l_opy_ (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉ࠽ࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡮ࡣࡵ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨ࠾ࠥࢁ࠰ࡾࠤᢺ").format(e)
        )
    passed = report.passed or report.skipped or (report.failed and hasattr(report, bstack1l1111l_opy_ (u"ࠥࡻࡦࡹࡸࡧࡣ࡬ࡰࠧᢻ")))
    bstack1lllll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠦࠧᢼ")
    bstack1111111l11_opy_(report)
    if not passed:
        try:
            bstack1lllll1l1l_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack1l1111l_opy_ (u"ࠧ࡝ࡁࡓࡐࡌࡒࡌࡀࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡦࡢ࡫࡯ࡹࡷ࡫ࠠࡳࡧࡤࡷࡴࡴ࠺ࠡࡽ࠳ࢁࠧᢽ").format(e)
            )
        try:
            if (threading.current_thread().bstackTestErrorMessages == None):
                threading.current_thread().bstackTestErrorMessages = []
        except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
        threading.current_thread().bstackTestErrorMessages.append(str(bstack1lllll1l1l_opy_))
    if not report.skipped:
        passed = report.passed or (report.failed and hasattr(report, bstack1l1111l_opy_ (u"ࠨࡷࡢࡵࡻࡪࡦ࡯࡬ࠣᢾ")))
        bstack1lllll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠢࠣᢿ")
        if not passed:
            try:
                bstack1lllll1l1l_opy_ = report.longrepr.reprcrash
            except Exception as e:
                summary.append(
                    bstack1l1111l_opy_ (u"࡙ࠣࡄࡖࡓࡏࡎࡈ࠼ࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡩࡥ࡮ࡲࡵࡳࡧࠣࡶࡪࡧࡳࡰࡰ࠽ࠤࢀ࠶ࡽࠣᣀ").format(e)
                )
            try:
                if (threading.current_thread().bstackTestErrorMessages == None):
                    threading.current_thread().bstackTestErrorMessages = []
            except Exception as e:
                threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(str(bstack1lllll1l1l_opy_))
        try:
            if passed:
                item._driver.execute_script(
                    bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡰࡪࡼࡥ࡭ࠤ࠽ࠤࠧ࡯࡮ࡧࡱࠥ࠰ࠥࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࡪࡡࡵࡣࠥ࠾ࠥ࠭ᣁ")
                    + json.dumps(bstack1l1111l_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠤࠦᣂ"))
                    + bstack1l1111l_opy_ (u"ࠦࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡽ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃࠢᣃ")
                )
            else:
                item._driver.execute_script(
                    bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡢࡰࡱࡳࡹࡧࡴࡦࠤ࠯ࠤࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨ࡬ࡦࡸࡨࡰࠧࡀࠠࠣࡧࡵࡶࡴࡸࠢ࠭ࠢ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡧࡥࡹࡧࠢ࠻ࠢࠪᣄ")
                    + json.dumps(str(bstack1lllll1l1l_opy_))
                    + bstack1l1111l_opy_ (u"ࠨ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡿ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾࠤᣅ")
                )
        except Exception as e:
            summary.append(bstack1l1111l_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡧ࡮࡯ࡱࡷࡥࡹ࡫࠺ࠡࡽ࠳ࢁࠧᣆ").format(e))
def bstack1l1ll1ll111_opy_(test_name, error_message):
    try:
        bstack1l1ll1l1l1l_opy_ = []
        bstack1l1l1l111l_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨᣇ"), bstack1l1111l_opy_ (u"ࠩ࠳ࠫᣈ"))
        bstack11ll1l1l1l_opy_ = {bstack1l1111l_opy_ (u"ࠪࡲࡦࡳࡥࠨᣉ"): test_name, bstack1l1111l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪᣊ"): error_message, bstack1l1111l_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫᣋ"): bstack1l1l1l111l_opy_}
        bstack1l1lll11ll1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1111l_opy_ (u"࠭ࡰࡸࡡࡳࡽࡹ࡫ࡳࡵࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫᣌ"))
        if os.path.exists(bstack1l1lll11ll1_opy_):
            with open(bstack1l1lll11ll1_opy_) as f:
                bstack1l1ll1l1l1l_opy_ = json.load(f)
        bstack1l1ll1l1l1l_opy_.append(bstack11ll1l1l1l_opy_)
        with open(bstack1l1lll11ll1_opy_, bstack1l1111l_opy_ (u"ࠧࡸࠩᣍ")) as f:
            json.dump(bstack1l1ll1l1l1l_opy_, f)
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡴࡪࡸࡳࡪࡵࡷ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡵࡿࡴࡦࡵࡷࠤࡪࡸࡲࡰࡴࡶ࠾ࠥ࠭ᣎ") + str(e))
def bstack1l1ll11lll1_opy_(item, report, summary, bstack1l1ll1l11ll_opy_):
    if report.when in [bstack1l1111l_opy_ (u"ࠤࡶࡩࡹࡻࡰࠣᣏ"), bstack1l1111l_opy_ (u"ࠥࡸࡪࡧࡲࡥࡱࡺࡲࠧᣐ")]:
        return
    if (str(bstack1l1ll1l11ll_opy_).lower() != bstack1l1111l_opy_ (u"ࠫࡹࡸࡵࡦࠩᣑ")):
        bstack1l11l1l1l1_opy_(item._page, report.nodeid)
    passed = report.passed or report.skipped or (report.failed and hasattr(report, bstack1l1111l_opy_ (u"ࠧࡽࡡࡴࡺࡩࡥ࡮ࡲࠢᣒ")))
    bstack1lllll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠨࠢᣓ")
    bstack1111111l11_opy_(report)
    if not report.skipped:
        if not passed:
            try:
                bstack1lllll1l1l_opy_ = report.longrepr.reprcrash
            except Exception as e:
                summary.append(
                    bstack1l1111l_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡨࡤ࡭ࡱࡻࡲࡦࠢࡵࡩࡦࡹ࡯࡯࠼ࠣࡿ࠵ࢃࠢᣔ").format(e)
                )
        try:
            if passed:
                bstack11l1l1l1ll_opy_(getattr(item, bstack1l1111l_opy_ (u"ࠨࡡࡳࡥ࡬࡫ࠧᣕ"), None), bstack1l1111l_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤᣖ"))
            else:
                error_message = bstack1l1111l_opy_ (u"ࠪࠫᣗ")
                if bstack1lllll1l1l_opy_:
                    bstack11ll1lll1_opy_(item._page, str(bstack1lllll1l1l_opy_), bstack1l1111l_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥᣘ"))
                    bstack11l1l1l1ll_opy_(getattr(item, bstack1l1111l_opy_ (u"ࠬࡥࡰࡢࡩࡨࠫᣙ"), None), bstack1l1111l_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨᣚ"), str(bstack1lllll1l1l_opy_))
                    error_message = str(bstack1lllll1l1l_opy_)
                else:
                    bstack11l1l1l1ll_opy_(getattr(item, bstack1l1111l_opy_ (u"ࠧࡠࡲࡤ࡫ࡪ࠭ᣛ"), None), bstack1l1111l_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣᣜ"))
                bstack1l1ll1ll111_opy_(report.nodeid, error_message)
        except Exception as e:
            summary.append(bstack1l1111l_opy_ (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉ࠽ࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡶࡲࡧࡥࡹ࡫ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳ࠻ࠢࡾ࠴ࢂࠨᣝ").format(e))
try:
    from typing import Generator
    import pytest_playwright.pytest_playwright as p
    @pytest.fixture
    def page(context: BrowserContext, request: pytest.FixtureRequest) -> Generator[Page, None, None]:
        page = context.new_page()
        request.node._page = page
        yield page
except:
    pass
def pytest_addoption(parser):
    parser.addoption(bstack1l1111l_opy_ (u"ࠥ࠱࠲ࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢᣞ"), default=bstack1l1111l_opy_ (u"ࠦࡋࡧ࡬ࡴࡧࠥᣟ"), help=bstack1l1111l_opy_ (u"ࠧࡇࡵࡵࡱࡰࡥࡹ࡯ࡣࠡࡵࡨࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠦᣠ"))
    parser.addoption(bstack1l1111l_opy_ (u"ࠨ࠭࠮ࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧᣡ"), default=bstack1l1111l_opy_ (u"ࠢࡇࡣ࡯ࡷࡪࠨᣢ"), help=bstack1l1111l_opy_ (u"ࠣࡃࡸࡸࡴࡳࡡࡵ࡫ࡦࠤࡸ࡫ࡴࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡱࡥࡲ࡫ࠢᣣ"))
    try:
        import pytest_selenium.pytest_selenium
    except:
        parser.addoption(bstack1l1111l_opy_ (u"ࠤ࠰࠱ࡩࡸࡩࡷࡧࡵࠦᣤ"), action=bstack1l1111l_opy_ (u"ࠥࡷࡹࡵࡲࡦࠤᣥ"), default=bstack1l1111l_opy_ (u"ࠦࡨ࡮ࡲࡰ࡯ࡨࠦᣦ"),
                         help=bstack1l1111l_opy_ (u"ࠧࡊࡲࡪࡸࡨࡶࠥࡺ࡯ࠡࡴࡸࡲࠥࡺࡥࡴࡶࡶࠦᣧ"))
def bstack1lll1lll_opy_(log):
    if not (log[bstack1l1111l_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᣨ")] and log[bstack1l1111l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᣩ")].strip()):
        return
    active = bstack1l1ll11l_opy_()
    log = {
        bstack1l1111l_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧᣪ"): log[bstack1l1111l_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨᣫ")],
        bstack1l1111l_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ᣬ"): bstack1l1l1ll1_opy_().isoformat() + bstack1l1111l_opy_ (u"ࠫ࡟࠭ᣭ"),
        bstack1l1111l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᣮ"): log[bstack1l1111l_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᣯ")],
    }
    if active:
        if active[bstack1l1111l_opy_ (u"ࠧࡵࡻࡳࡩࠬᣰ")] == bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰ࠭ᣱ"):
            log[bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᣲ")] = active[bstack1l1111l_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᣳ")]
        elif active[bstack1l1111l_opy_ (u"ࠫࡹࡿࡰࡦࠩᣴ")] == bstack1l1111l_opy_ (u"ࠬࡺࡥࡴࡶࠪᣵ"):
            log[bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭᣶")] = active[bstack1l1111l_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ᣷")]
    bstack1l11l1l1_opy_.bstack11lllll1_opy_([log])
def bstack1l1ll11l_opy_():
    if len(store[bstack1l1111l_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡ࡫ࡳࡴࡱ࡟ࡶࡷ࡬ࡨࠬ᣸")]) > 0 and store[bstack1l1111l_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢ࡬ࡴࡵ࡫ࡠࡷࡸ࡭ࡩ࠭᣹")][-1]:
        return {
            bstack1l1111l_opy_ (u"ࠪࡸࡾࡶࡥࠨ᣺"): bstack1l1111l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩ᣻"),
            bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ᣼"): store[bstack1l1111l_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡩࡱࡲ࡯ࡤࡻࡵࡪࡦࠪ᣽")][-1]
        }
    if store.get(bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡶࡨࡷࡹࡥࡵࡶ࡫ࡧࠫ᣾"), None):
        return {
            bstack1l1111l_opy_ (u"ࠨࡶࡼࡴࡪ࠭᣿"): bstack1l1111l_opy_ (u"ࠩࡷࡩࡸࡺࠧᤀ"),
            bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᤁ"): store[bstack1l1111l_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢࡹࡺ࡯ࡤࠨᤂ")]
        }
    return None
bstack1ll1llll_opy_ = bstack1l11ll1l_opy_(bstack1lll1lll_opy_)
def pytest_runtest_call(item):
    try:
        global CONFIG
        item._1l1ll1l1111_opy_ = True
        bstack1lll111lll_opy_ = bstack1111ll11_opy_.bstack1llll1l1l1_opy_(bstack1llll11l11l_opy_(item.own_markers))
        item._a11y_test_case = bstack1lll111lll_opy_
        if bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫᤃ"), None):
            driver = getattr(item, bstack1l1111l_opy_ (u"࠭࡟ࡥࡴ࡬ࡺࡪࡸࠧᤄ"), None)
            item._a11y_started = bstack1111ll11_opy_.bstack111lllll1_opy_(driver, bstack1lll111lll_opy_)
        if not bstack1l11l1l1_opy_.on() or bstack1l1ll11ll1l_opy_ != bstack1l1111l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧᤅ"):
            return
        global current_test_uuid, bstack1ll1llll_opy_
        bstack1ll1llll_opy_.start()
        bstack1l11lll1_opy_ = {
            bstack1l1111l_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᤆ"): uuid4().__str__(),
            bstack1l1111l_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᤇ"): bstack1l1l1ll1_opy_().isoformat() + bstack1l1111l_opy_ (u"ࠪ࡞ࠬᤈ")
        }
        current_test_uuid = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩᤉ")]
        store[bstack1l1111l_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩᤊ")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᤋ")]
        threading.current_thread().current_test_uuid = current_test_uuid
        _1lll11l1_opy_[item.nodeid] = {**_1lll11l1_opy_[item.nodeid], **bstack1l11lll1_opy_}
        bstack1l1ll11ll11_opy_(item, _1lll11l1_opy_[item.nodeid], bstack1l1111l_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᤌ"))
    except Exception as err:
        print(bstack1l1111l_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡳࡷࡱࡸࡪࡹࡴࡠࡥࡤࡰࡱࡀࠠࡼࡿࠪᤍ"), str(err))
def pytest_runtest_setup(item):
    global bstack1l1ll11llll_opy_
    threading.current_thread().percySessionName = item.nodeid
    if bstack1llll1ll1ll_opy_():
        atexit.register(bstack11lll1lll_opy_)
        if not bstack1l1ll11llll_opy_:
            try:
                bstack1l1lll111l1_opy_ = [signal.SIGINT, signal.SIGTERM]
                if not bstack1lll11ll111_opy_():
                    bstack1l1lll111l1_opy_.extend([signal.SIGHUP, signal.SIGQUIT])
                for s in bstack1l1lll111l1_opy_:
                    signal.signal(s, bstack1l1ll1l111l_opy_)
                bstack1l1ll11llll_opy_ = True
            except Exception as e:
                logger.debug(
                    bstack1l1111l_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡷ࡫ࡧࡪࡵࡷࡩࡷࠦࡳࡪࡩࡱࡥࡱࠦࡨࡢࡰࡧࡰࡪࡸࡳ࠻ࠢࠥᤎ") + str(e))
        try:
            item.config.hook.pytest_selenium_runtest_makereport = bstack111111l1ll_opy_
        except Exception as err:
            threading.current_thread().testStatus = bstack1l1111l_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪᤏ")
    try:
        if not bstack1l11l1l1_opy_.on():
            return
        bstack1ll1llll_opy_.start()
        uuid = uuid4().__str__()
        bstack1l11lll1_opy_ = {
            bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩᤐ"): uuid,
            bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᤑ"): bstack1l1l1ll1_opy_().isoformat() + bstack1l1111l_opy_ (u"࡚࠭ࠨᤒ"),
            bstack1l1111l_opy_ (u"ࠧࡵࡻࡳࡩࠬᤓ"): bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰ࠭ᤔ"),
            bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᤕ"): bstack1l1111l_opy_ (u"ࠪࡆࡊࡌࡏࡓࡇࡢࡉࡆࡉࡈࠨᤖ"),
            bstack1l1111l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡱࡥࡲ࡫ࠧᤗ"): bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫᤘ")
        }
        threading.current_thread().current_hook_uuid = uuid
        threading.current_thread().current_test_item = item
        store[bstack1l1111l_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡵࡧࡶࡸࡤ࡯ࡴࡦ࡯ࠪᤙ")] = item
        store[bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡪࡲࡳࡰࡥࡵࡶ࡫ࡧࠫᤚ")] = [uuid]
        if not _1lll11l1_opy_.get(item.nodeid, None):
            _1lll11l1_opy_[item.nodeid] = {bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᤛ"): [], bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡽࡺࡵࡳࡧࡶࠫᤜ"): []}
        _1lll11l1_opy_[item.nodeid][bstack1l1111l_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᤝ")].append(bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩᤞ")])
        _1lll11l1_opy_[item.nodeid + bstack1l1111l_opy_ (u"ࠬ࠳ࡳࡦࡶࡸࡴࠬ᤟")] = bstack1l11lll1_opy_
        bstack1l1ll1ll1ll_opy_(item, bstack1l11lll1_opy_, bstack1l1111l_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᤠ"))
    except Exception as err:
        print(bstack1l1111l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡺࡶࡨࡷࡹࡥࡲࡶࡰࡷࡩࡸࡺ࡟ࡴࡧࡷࡹࡵࡀࠠࡼࡿࠪᤡ"), str(err))
def pytest_runtest_teardown(item):
    try:
        global bstack1l1l11l11_opy_
        bstack1l1l1l111l_opy_ = 0
        if bstack1l1ll1ll1l_opy_ is True:
            bstack1l1l1l111l_opy_ = int(os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨᤢ")))
        if bstack1111l1ll1_opy_.bstack1l1ll1l11l_opy_() == bstack1l1111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᤣ"):
            if bstack1111l1ll1_opy_.bstack111lll11ll_opy_() == bstack1l1111l_opy_ (u"ࠥࡸࡪࡹࡴࡤࡣࡶࡩࠧᤤ"):
                bstack1l1ll11l1ll_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠫࡵ࡫ࡲࡤࡻࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧᤥ"), None)
                bstack111l1ll1l_opy_ = bstack1l1ll11l1ll_opy_ + bstack1l1111l_opy_ (u"ࠧ࠳ࡴࡦࡵࡷࡧࡦࡹࡥࠣᤦ")
                driver = getattr(item, bstack1l1111l_opy_ (u"࠭࡟ࡥࡴ࡬ࡺࡪࡸࠧᤧ"), None)
                bstack1l1l11ll1l_opy_ = getattr(item, bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᤨ"), None)
                bstack1l1lllllll_opy_ = getattr(item, bstack1l1111l_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᤩ"), None)
                PercySDK.screenshot(driver, bstack111l1ll1l_opy_, bstack1l1l11ll1l_opy_=bstack1l1l11ll1l_opy_, bstack1l1lllllll_opy_=bstack1l1lllllll_opy_, bstack1l1111l11_opy_=bstack1l1l1l111l_opy_)
        if getattr(item, bstack1l1111l_opy_ (u"ࠩࡢࡥ࠶࠷ࡹࡠࡵࡷࡥࡷࡺࡥࡥࠩᤪ"), False):
            bstack11l11111_opy_.bstack1111l1ll_opy_(getattr(item, bstack1l1111l_opy_ (u"ࠪࡣࡩࡸࡩࡷࡧࡵࠫᤫ"), None), bstack1l1l11l11_opy_, logger, item)
        if not bstack1l11l1l1_opy_.on():
            return
        bstack1l11lll1_opy_ = {
            bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩ᤬"): uuid4().__str__(),
            bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩ᤭"): bstack1l1l1ll1_opy_().isoformat() + bstack1l1111l_opy_ (u"࡚࠭ࠨ᤮"),
            bstack1l1111l_opy_ (u"ࠧࡵࡻࡳࡩࠬ᤯"): bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰ࠭ᤰ"),
            bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᤱ"): bstack1l1111l_opy_ (u"ࠪࡅࡋ࡚ࡅࡓࡡࡈࡅࡈࡎࠧᤲ"),
            bstack1l1111l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡱࡥࡲ࡫ࠧᤳ"): bstack1l1111l_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴࠧᤴ")
        }
        _1lll11l1_opy_[item.nodeid + bstack1l1111l_opy_ (u"࠭࠭ࡵࡧࡤࡶࡩࡵࡷ࡯ࠩᤵ")] = bstack1l11lll1_opy_
        bstack1l1ll1ll1ll_opy_(item, bstack1l11lll1_opy_, bstack1l1111l_opy_ (u"ࠧࡉࡱࡲ࡯ࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᤶ"))
    except Exception as err:
        print(bstack1l1111l_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡳࡷࡱࡸࡪࡹࡴࡠࡶࡨࡥࡷࡪ࡯ࡸࡰ࠽ࠤࢀࢃࠧᤷ"), str(err))
@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef, request):
    if not bstack1l11l1l1_opy_.on():
        yield
        return
    start_time = datetime.datetime.now()
    if bstack1111111lll_opy_(fixturedef.argname):
        store[bstack1l1111l_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡱࡴࡪࡵ࡭ࡧࡢ࡭ࡹ࡫࡭ࠨᤸ")] = request.node
    elif bstack1111111111_opy_(fixturedef.argname):
        store[bstack1l1111l_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡨࡲࡡࡴࡵࡢ࡭ࡹ࡫࡭ࠨ᤹")] = request.node
    outcome = yield
    try:
        fixture = {
            bstack1l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ᤺"): fixturedef.argname,
            bstack1l1111l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸ᤻ࠬ"): bstack1lll1lll111_opy_(outcome),
            bstack1l1111l_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ᤼"): (datetime.datetime.now() - start_time).total_seconds() * 1000
        }
        current_test_item = store[bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡶࡨࡷࡹࡥࡩࡵࡧࡰࠫ᤽")]
        if not _1lll11l1_opy_.get(current_test_item.nodeid, None):
            _1lll11l1_opy_[current_test_item.nodeid] = {bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡼࡹࡻࡲࡦࡵࠪ᤾"): []}
        _1lll11l1_opy_[current_test_item.nodeid][bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡽࡺࡵࡳࡧࡶࠫ᤿")].append(fixture)
    except Exception as err:
        logger.debug(bstack1l1111l_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡩ࡭ࡽࡺࡵࡳࡧࡢࡷࡪࡺࡵࡱ࠼ࠣࡿࢂ࠭᥀"), str(err))
if bstack1llll1ll1_opy_() and bstack1l11l1l1_opy_.on():
    def pytest_bdd_before_step(request, step):
        try:
            _1lll11l1_opy_[request.node.nodeid][bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧ᥁")].bstack11l1ll1l_opy_(id(step))
        except Exception as err:
            print(bstack1l1111l_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡿࡴࡦࡵࡷࡣࡧࡪࡤࡠࡤࡨࡪࡴࡸࡥࡠࡵࡷࡩࡵࡀࠠࡼࡿࠪ᥂"), str(err))
    def pytest_bdd_step_error(request, step, exception):
        try:
            _1lll11l1_opy_[request.node.nodeid][bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡩࡧࡴࡢࠩ᥃")].bstack1lllll11_opy_(id(step), Result.failed(exception=exception))
        except Exception as err:
            print(bstack1l1111l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡺࡶࡨࡷࡹࡥࡢࡥࡦࡢࡷࡹ࡫ࡰࡠࡧࡵࡶࡴࡸ࠺ࠡࡽࢀࠫ᥄"), str(err))
    def pytest_bdd_after_step(request, step):
        try:
            bstack11llll1l_opy_: bstack1l1l1lll_opy_ = _1lll11l1_opy_[request.node.nodeid][bstack1l1111l_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫ᥅")]
            bstack11llll1l_opy_.bstack1lllll11_opy_(id(step), Result.passed())
        except Exception as err:
            print(bstack1l1111l_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲࡼࡸࡪࡹࡴࡠࡤࡧࡨࡤࡹࡴࡦࡲࡢࡩࡷࡸ࡯ࡳ࠼ࠣࡿࢂ࠭᥆"), str(err))
    def pytest_bdd_before_scenario(request, feature, scenario):
        global bstack1l1ll11ll1l_opy_
        try:
            if not bstack1l11l1l1_opy_.on() or bstack1l1ll11ll1l_opy_ != bstack1l1111l_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠧ᥇"):
                return
            global bstack1ll1llll_opy_
            bstack1ll1llll_opy_.start()
            driver = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪ᥈"), None)
            if not _1lll11l1_opy_.get(request.node.nodeid, None):
                _1lll11l1_opy_[request.node.nodeid] = {}
            bstack11llll1l_opy_ = bstack1l1l1lll_opy_.bstack1ll1lll1ll1_opy_(
                scenario, feature, request.node,
                name=bstack111111l111_opy_(request.node, scenario),
                bstack1l1l11ll_opy_=bstack1llll111_opy_(),
                file_path=feature.filename,
                scope=[feature.name],
                framework=bstack1l1111l_opy_ (u"ࠬࡖࡹࡵࡧࡶࡸ࠲ࡩࡵࡤࡷࡰࡦࡪࡸࠧ᥉"),
                tags=bstack111111l1l1_opy_(feature, scenario),
                bstack1ll1l11l_opy_=bstack1l11l1l1_opy_.bstack1ll1ll1l_opy_(driver) if driver and driver.session_id else {}
            )
            _1lll11l1_opy_[request.node.nodeid][bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡩࡧࡴࡢࠩ᥊")] = bstack11llll1l_opy_
            bstack1l1lll1111l_opy_(bstack11llll1l_opy_.uuid)
            bstack1l11l1l1_opy_.bstack1l1l11l1_opy_(bstack1l1111l_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨ᥋"), bstack11llll1l_opy_)
        except Exception as err:
            print(bstack1l1111l_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡣࡦࡧࡣࡧ࡫ࡦࡰࡴࡨࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴࡀࠠࡼࡿࠪ᥌"), str(err))
def bstack1l1ll1lll11_opy_(bstack11l1l1ll_opy_):
    if bstack11l1l1ll_opy_ in store[bstack1l1111l_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢ࡬ࡴࡵ࡫ࡠࡷࡸ࡭ࡩ࠭᥍")]:
        store[bstack1l1111l_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧ᥎")].remove(bstack11l1l1ll_opy_)
def bstack1l1lll1111l_opy_(bstack11l1llll_opy_):
    store[bstack1l1111l_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢࡹࡺ࡯ࡤࠨ᥏")] = bstack11l1llll_opy_
    threading.current_thread().current_test_uuid = bstack11l1llll_opy_
@bstack1l11l1l1_opy_.bstack1l1lllll11l_opy_
def bstack1l1ll1lll1l_opy_(item, call, report):
    global bstack1l1ll11ll1l_opy_
    bstack1l1l1111l_opy_ = bstack1llll111_opy_()
    if hasattr(report, bstack1l1111l_opy_ (u"ࠬࡹࡴࡰࡲࠪᥐ")):
        bstack1l1l1111l_opy_ = bstack1lll1l1111l_opy_(report.stop)
    elif hasattr(report, bstack1l1111l_opy_ (u"࠭ࡳࡵࡣࡵࡸࠬᥑ")):
        bstack1l1l1111l_opy_ = bstack1lll1l1111l_opy_(report.start)
    try:
        if getattr(report, bstack1l1111l_opy_ (u"ࠧࡸࡪࡨࡲࠬᥒ"), bstack1l1111l_opy_ (u"ࠨࠩᥓ")) == bstack1l1111l_opy_ (u"ࠩࡦࡥࡱࡲࠧᥔ"):
            bstack1ll1llll_opy_.reset()
        if getattr(report, bstack1l1111l_opy_ (u"ࠪࡻ࡭࡫࡮ࠨᥕ"), bstack1l1111l_opy_ (u"ࠫࠬᥖ")) == bstack1l1111l_opy_ (u"ࠬࡩࡡ࡭࡮ࠪᥗ"):
            if bstack1l1ll11ll1l_opy_ == bstack1l1111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᥘ"):
                _1lll11l1_opy_[item.nodeid][bstack1l1111l_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᥙ")] = bstack1l1l1111l_opy_
                bstack1l1ll11ll11_opy_(item, _1lll11l1_opy_[item.nodeid], bstack1l1111l_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᥚ"), report, call)
                store[bstack1l1111l_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭ᥛ")] = None
            elif bstack1l1ll11ll1l_opy_ == bstack1l1111l_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠢᥜ"):
                bstack11llll1l_opy_ = _1lll11l1_opy_[item.nodeid][bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧᥝ")]
                bstack11llll1l_opy_.set(hooks=_1lll11l1_opy_[item.nodeid].get(bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᥞ"), []))
                exception, bstack1ll11lll_opy_ = None, None
                if call.excinfo:
                    exception = call.excinfo.value
                    bstack1ll11lll_opy_ = [call.excinfo.exconly(), getattr(report, bstack1l1111l_opy_ (u"࠭࡬ࡰࡰࡪࡶࡪࡶࡲࡵࡧࡻࡸࠬᥟ"), bstack1l1111l_opy_ (u"ࠧࠨᥠ"))]
                bstack11llll1l_opy_.stop(time=bstack1l1l1111l_opy_, result=Result(result=getattr(report, bstack1l1111l_opy_ (u"ࠨࡱࡸࡸࡨࡵ࡭ࡦࠩᥡ"), bstack1l1111l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩᥢ")), exception=exception, bstack1ll11lll_opy_=bstack1ll11lll_opy_))
                bstack1l11l1l1_opy_.bstack1l1l11l1_opy_(bstack1l1111l_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬᥣ"), _1lll11l1_opy_[item.nodeid][bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧᥤ")])
        elif getattr(report, bstack1l1111l_opy_ (u"ࠬࡽࡨࡦࡰࠪᥥ"), bstack1l1111l_opy_ (u"࠭ࠧᥦ")) in [bstack1l1111l_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠭ᥧ"), bstack1l1111l_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࠪᥨ")]:
            bstack1l11llll_opy_ = item.nodeid + bstack1l1111l_opy_ (u"ࠩ࠰ࠫᥩ") + getattr(report, bstack1l1111l_opy_ (u"ࠪࡻ࡭࡫࡮ࠨᥪ"), bstack1l1111l_opy_ (u"ࠫࠬᥫ"))
            if getattr(report, bstack1l1111l_opy_ (u"ࠬࡹ࡫ࡪࡲࡳࡩࡩ࠭ᥬ"), False):
                hook_type = bstack1l1111l_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠫᥭ") if getattr(report, bstack1l1111l_opy_ (u"ࠧࡸࡪࡨࡲࠬ᥮"), bstack1l1111l_opy_ (u"ࠨࠩ᥯")) == bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨᥰ") else bstack1l1111l_opy_ (u"ࠪࡅࡋ࡚ࡅࡓࡡࡈࡅࡈࡎࠧᥱ")
                _1lll11l1_opy_[bstack1l11llll_opy_] = {
                    bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩᥲ"): uuid4().__str__(),
                    bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᥳ"): bstack1l1l1111l_opy_,
                    bstack1l1111l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᥴ"): hook_type
                }
            _1lll11l1_opy_[bstack1l11llll_opy_][bstack1l1111l_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬ᥵")] = bstack1l1l1111l_opy_
            bstack1l1ll1lll11_opy_(_1lll11l1_opy_[bstack1l11llll_opy_][bstack1l1111l_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭᥶")])
            bstack1l1ll1ll1ll_opy_(item, _1lll11l1_opy_[bstack1l11llll_opy_], bstack1l1111l_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫ᥷"), report, call)
            if getattr(report, bstack1l1111l_opy_ (u"ࠪࡻ࡭࡫࡮ࠨ᥸"), bstack1l1111l_opy_ (u"ࠫࠬ᥹")) == bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫ᥺"):
                if getattr(report, bstack1l1111l_opy_ (u"࠭࡯ࡶࡶࡦࡳࡲ࡫ࠧ᥻"), bstack1l1111l_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧ᥼")) == bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ᥽"):
                    bstack1l11lll1_opy_ = {
                        bstack1l1111l_opy_ (u"ࠩࡸࡹ࡮ࡪࠧ᥾"): uuid4().__str__(),
                        bstack1l1111l_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧ᥿"): bstack1llll111_opy_(),
                        bstack1l1111l_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᦀ"): bstack1llll111_opy_()
                    }
                    _1lll11l1_opy_[item.nodeid] = {**_1lll11l1_opy_[item.nodeid], **bstack1l11lll1_opy_}
                    bstack1l1ll11ll11_opy_(item, _1lll11l1_opy_[item.nodeid], bstack1l1111l_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭ᦁ"))
                    bstack1l1ll11ll11_opy_(item, _1lll11l1_opy_[item.nodeid], bstack1l1111l_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨᦂ"), report, call)
    except Exception as err:
        print(bstack1l1111l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡨࡢࡰࡧࡰࡪࡥ࡯࠲࠳ࡼࡣࡹ࡫ࡳࡵࡡࡨࡺࡪࡴࡴ࠻ࠢࡾࢁࠬᦃ"), str(err))
def bstack1l1lll111ll_opy_(test, bstack1l11lll1_opy_, result=None, call=None, bstack11llllll11_opy_=None, outcome=None):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    bstack11llll1l_opy_ = {
        bstack1l1111l_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᦄ"): bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᦅ")],
        bstack1l1111l_opy_ (u"ࠪࡸࡾࡶࡥࠨᦆ"): bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࠩᦇ"),
        bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᦈ"): test.name,
        bstack1l1111l_opy_ (u"࠭ࡢࡰࡦࡼࠫᦉ"): {
            bstack1l1111l_opy_ (u"ࠧ࡭ࡣࡱ࡫ࠬᦊ"): bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨᦋ"),
            bstack1l1111l_opy_ (u"ࠩࡦࡳࡩ࡫ࠧᦌ"): inspect.getsource(test.obj)
        },
        bstack1l1111l_opy_ (u"ࠪ࡭ࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧᦍ"): test.name,
        bstack1l1111l_opy_ (u"ࠫࡸࡩ࡯ࡱࡧࠪᦎ"): test.name,
        bstack1l1111l_opy_ (u"ࠬࡹࡣࡰࡲࡨࡷࠬᦏ"): bstack1l11l1ll_opy_.bstack1ll11l11_opy_(test),
        bstack1l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩᦐ"): file_path,
        bstack1l1111l_opy_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᦑ"): file_path,
        bstack1l1111l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᦒ"): bstack1l1111l_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪᦓ"),
        bstack1l1111l_opy_ (u"ࠪࡺࡨࡥࡦࡪ࡮ࡨࡴࡦࡺࡨࠨᦔ"): file_path,
        bstack1l1111l_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᦕ"): bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᦖ")],
        bstack1l1111l_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩᦗ"): bstack1l1111l_opy_ (u"ࠧࡑࡻࡷࡩࡸࡺࠧᦘ"),
        bstack1l1111l_opy_ (u"ࠨࡥࡸࡷࡹࡵ࡭ࡓࡧࡵࡹࡳࡖࡡࡳࡣࡰࠫᦙ"): {
            bstack1l1111l_opy_ (u"ࠩࡵࡩࡷࡻ࡮ࡠࡰࡤࡱࡪ࠭ᦚ"): test.nodeid
        },
        bstack1l1111l_opy_ (u"ࠪࡸࡦ࡭ࡳࠨᦛ"): bstack1llll11l11l_opy_(test.own_markers)
    }
    if bstack11llllll11_opy_ in [bstack1l1111l_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡱࡩࡱࡲࡨࡨࠬᦜ"), bstack1l1111l_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧᦝ")]:
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"࠭࡭ࡦࡶࡤࠫᦞ")] = {
            bstack1l1111l_opy_ (u"ࠧࡧ࡫ࡻࡸࡺࡸࡥࡴࠩᦟ"): bstack1l11lll1_opy_.get(bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡼࡹࡻࡲࡦࡵࠪᦠ"), [])
        }
    if bstack11llllll11_opy_ == bstack1l1111l_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖ࡯࡮ࡶࡰࡦࡦࠪᦡ"):
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᦢ")] = bstack1l1111l_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬᦣ")
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᦤ")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬᦥ")]
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᦦ")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᦧ")]
    if result:
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᦨ")] = result.outcome
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࡤ࡯࡮ࡠ࡯ࡶࠫᦩ")] = result.duration * 1000
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᦪ")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᦫ")]
        if result.failed:
            bstack11llll1l_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫࡟ࡵࡻࡳࡩࠬ᦬")] = bstack1l11l1l1_opy_.bstack111ll1l11l_opy_(call.excinfo.typename)
            bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡺࡸࡥࠨ᦭")] = bstack1l11l1l1_opy_.bstack1l1llllll1l_opy_(call.excinfo, result)
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧ᦮")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨ᦯")]
    if outcome:
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᦰ")] = bstack1lll1lll111_opy_(outcome)
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳࡥࡩ࡯ࡡࡰࡷࠬᦱ")] = 0
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᦲ")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᦳ")]
        if bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᦴ")] == bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᦵ"):
            bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨᦶ")] = bstack1l1111l_opy_ (u"࡙ࠪࡳ࡮ࡡ࡯ࡦ࡯ࡩࡩࡋࡲࡳࡱࡵࠫᦷ")  # bstack1l1lll11l11_opy_
            bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᦸ")] = [{bstack1l1111l_opy_ (u"ࠬࡨࡡࡤ࡭ࡷࡶࡦࡩࡥࠨᦹ"): [bstack1l1111l_opy_ (u"࠭ࡳࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠪᦺ")]}]
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠧࡩࡱࡲ࡯ࡸ࠭ᦻ")] = bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᦼ")]
    return bstack11llll1l_opy_
def bstack1l1lll1l11l_opy_(test, bstack1ll1111l_opy_, bstack11llllll11_opy_, result, call, outcome, bstack1l1ll1ll1l1_opy_):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    hook_type = bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᦽ")]
    hook_name = bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡰࡤࡱࡪ࠭ᦾ")]
    hook_data = {
        bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩᦿ"): bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠬࡻࡵࡪࡦࠪᧀ")],
        bstack1l1111l_opy_ (u"࠭ࡴࡺࡲࡨࠫᧁ"): bstack1l1111l_opy_ (u"ࠧࡩࡱࡲ࡯ࠬᧂ"),
        bstack1l1111l_opy_ (u"ࠨࡰࡤࡱࡪ࠭ᧃ"): bstack1l1111l_opy_ (u"ࠩࡾࢁࠬᧄ").format(bstack1111111ll1_opy_(hook_name)),
        bstack1l1111l_opy_ (u"ࠪࡦࡴࡪࡹࠨᧅ"): {
            bstack1l1111l_opy_ (u"ࠫࡱࡧ࡮ࡨࠩᧆ"): bstack1l1111l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬᧇ"),
            bstack1l1111l_opy_ (u"࠭ࡣࡰࡦࡨࠫᧈ"): None
        },
        bstack1l1111l_opy_ (u"ࠧࡴࡥࡲࡴࡪ࠭ᧉ"): test.name,
        bstack1l1111l_opy_ (u"ࠨࡵࡦࡳࡵ࡫ࡳࠨ᧊"): bstack1l11l1ll_opy_.bstack1ll11l11_opy_(test, hook_name),
        bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ᧋"): file_path,
        bstack1l1111l_opy_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ᧌"): file_path,
        bstack1l1111l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ᧍"): bstack1l1111l_opy_ (u"ࠬࡶࡥ࡯ࡦ࡬ࡲ࡬࠭᧎"),
        bstack1l1111l_opy_ (u"࠭ࡶࡤࡡࡩ࡭ࡱ࡫ࡰࡢࡶ࡫ࠫ᧏"): file_path,
        bstack1l1111l_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫ᧐"): bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬ᧑")],
        bstack1l1111l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ᧒"): bstack1l1111l_opy_ (u"ࠪࡔࡾࡺࡥࡴࡶ࠰ࡧࡺࡩࡵ࡮ࡤࡨࡶࠬ᧓") if bstack1l1ll11ll1l_opy_ == bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠨ᧔") else bstack1l1111l_opy_ (u"ࠬࡖࡹࡵࡧࡶࡸࠬ᧕"),
        bstack1l1111l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩ᧖"): hook_type
    }
    bstack1ll1ll1l1ll_opy_ = bstack1lll1l11_opy_(_1lll11l1_opy_.get(test.nodeid, None))
    if bstack1ll1ll1l1ll_opy_:
        hook_data[bstack1l1111l_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡ࡬ࡨࠬ᧗")] = bstack1ll1ll1l1ll_opy_
    if result:
        hook_data[bstack1l1111l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ᧘")] = result.outcome
        hook_data[bstack1l1111l_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࡣ࡮ࡴ࡟࡮ࡵࠪ᧙")] = result.duration * 1000
        hook_data[bstack1l1111l_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨ᧚")] = bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩ᧛")]
        if result.failed:
            hook_data[bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪࡥࡴࡺࡲࡨࠫ᧜")] = bstack1l11l1l1_opy_.bstack111ll1l11l_opy_(call.excinfo.typename)
            hook_data[bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫ࠧ᧝")] = bstack1l11l1l1_opy_.bstack1l1llllll1l_opy_(call.excinfo, result)
    if outcome:
        hook_data[bstack1l1111l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ᧞")] = bstack1lll1lll111_opy_(outcome)
        hook_data[bstack1l1111l_opy_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࡢ࡭ࡳࡥ࡭ࡴࠩ᧟")] = 100
        hook_data[bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧ᧠")] = bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨ᧡")]
        if hook_data[bstack1l1111l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ᧢")] == bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ᧣"):
            hook_data[bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫࡟ࡵࡻࡳࡩࠬ᧤")] = bstack1l1111l_opy_ (u"ࠧࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠨ᧥")  # bstack1l1lll11l11_opy_
            hook_data[bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࠩ᧦")] = [{bstack1l1111l_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬ᧧"): [bstack1l1111l_opy_ (u"ࠪࡷࡴࡳࡥࠡࡧࡵࡶࡴࡸࠧ᧨")]}]
    if bstack1l1ll1ll1l1_opy_:
        hook_data[bstack1l1111l_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ᧩")] = bstack1l1ll1ll1l1_opy_.result
        hook_data[bstack1l1111l_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴ࡟ࡪࡰࡢࡱࡸ࠭᧪")] = bstack1llll11ll11_opy_(bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪ᧫")], bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬ᧬")])
        hook_data[bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭᧭")] = bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧ᧮")]
        if hook_data[bstack1l1111l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ᧯")] == bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ᧰"):
            hook_data[bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪࡥࡴࡺࡲࡨࠫ᧱")] = bstack1l11l1l1_opy_.bstack111ll1l11l_opy_(bstack1l1ll1ll1l1_opy_.exception_type)
            hook_data[bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫ࠧ᧲")] = [{bstack1l1111l_opy_ (u"ࠧࡣࡣࡦ࡯ࡹࡸࡡࡤࡧࠪ᧳"): bstack1lll1l1llll_opy_(bstack1l1ll1ll1l1_opy_.exception)}]
    return hook_data
def bstack1l1ll11ll11_opy_(test, bstack1l11lll1_opy_, bstack11llllll11_opy_, result=None, call=None, outcome=None):
    bstack11llll1l_opy_ = bstack1l1lll111ll_opy_(test, bstack1l11lll1_opy_, result, call, bstack11llllll11_opy_, outcome)
    driver = getattr(test, bstack1l1111l_opy_ (u"ࠨࡡࡧࡶ࡮ࡼࡥࡳࠩ᧴"), None)
    if bstack11llllll11_opy_ == bstack1l1111l_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪ᧵") and driver:
        bstack11llll1l_opy_[bstack1l1111l_opy_ (u"ࠪ࡭ࡳࡺࡥࡨࡴࡤࡸ࡮ࡵ࡮ࡴࠩ᧶")] = bstack1l11l1l1_opy_.bstack1ll1ll1l_opy_(driver)
    if bstack11llllll11_opy_ == bstack1l1111l_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡱࡩࡱࡲࡨࡨࠬ᧷"):
        bstack11llllll11_opy_ = bstack1l1111l_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧ᧸")
    bstack1ll1lll1_opy_ = {
        bstack1l1111l_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ᧹"): bstack11llllll11_opy_,
        bstack1l1111l_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࠩ᧺"): bstack11llll1l_opy_
    }
    bstack1l11l1l1_opy_.bstack1l1ll111_opy_(bstack1ll1lll1_opy_)
    if bstack11llllll11_opy_ == bstack1l1111l_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩ᧻"):
        threading.current_thread().bstackTestMeta = {bstack1l1111l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ᧼"): bstack1l1111l_opy_ (u"ࠪࡴࡪࡴࡤࡪࡰࡪࠫ᧽")}
    elif bstack11llllll11_opy_ == bstack1l1111l_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭᧾"):
        threading.current_thread().bstackTestMeta = {bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ᧿"): getattr(result, bstack1l1111l_opy_ (u"࠭࡯ࡶࡶࡦࡳࡲ࡫ࠧᨀ"), bstack1l1111l_opy_ (u"ࠧࠨᨁ"))}
def bstack1l1ll1ll1ll_opy_(test, bstack1l11lll1_opy_, bstack11llllll11_opy_, result=None, call=None, outcome=None, bstack1l1ll1ll1l1_opy_=None):
    hook_data = bstack1l1lll1l11l_opy_(test, bstack1l11lll1_opy_, bstack11llllll11_opy_, result, call, outcome, bstack1l1ll1ll1l1_opy_)
    bstack1ll1lll1_opy_ = {
        bstack1l1111l_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬᨂ"): bstack11llllll11_opy_,
        bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࠫᨃ"): hook_data
    }
    bstack1l11l1l1_opy_.bstack1l1ll111_opy_(bstack1ll1lll1_opy_)
def bstack1lll1l11_opy_(bstack1l11lll1_opy_):
    if not bstack1l11lll1_opy_:
        return None
    if bstack1l11lll1_opy_.get(bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡦࡤࡸࡦ࠭ᨄ"), None):
        return getattr(bstack1l11lll1_opy_[bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧᨅ")], bstack1l1111l_opy_ (u"ࠬࡻࡵࡪࡦࠪᨆ"), None)
    return bstack1l11lll1_opy_.get(bstack1l1111l_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᨇ"), None)
@pytest.fixture(autouse=True)
def second_fixture(caplog, request):
    yield
    try:
        if not bstack1l11l1l1_opy_.on():
            return
        places = [bstack1l1111l_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠭ᨈ"), bstack1l1111l_opy_ (u"ࠨࡥࡤࡰࡱ࠭ᨉ"), bstack1l1111l_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࠫᨊ")]
        bstack1llll1ll_opy_ = []
        for bstack1l1ll1lllll_opy_ in places:
            records = caplog.get_records(bstack1l1ll1lllll_opy_)
            bstack1l1lll11111_opy_ = bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᨋ") if bstack1l1ll1lllll_opy_ == bstack1l1111l_opy_ (u"ࠫࡨࡧ࡬࡭ࠩᨌ") else bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᨍ")
            bstack1l1ll1l1ll1_opy_ = request.node.nodeid + (bstack1l1111l_opy_ (u"࠭ࠧᨎ") if bstack1l1ll1lllll_opy_ == bstack1l1111l_opy_ (u"ࠧࡤࡣ࡯ࡰࠬᨏ") else bstack1l1111l_opy_ (u"ࠨ࠯ࠪᨐ") + bstack1l1ll1lllll_opy_)
            bstack11l1llll_opy_ = bstack1lll1l11_opy_(_1lll11l1_opy_.get(bstack1l1ll1l1ll1_opy_, None))
            if not bstack11l1llll_opy_:
                continue
            for record in records:
                if bstack1llll11111l_opy_(record.message):
                    continue
                bstack1llll1ll_opy_.append({
                    bstack1l1111l_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬᨑ"): bstack1llll11ll1l_opy_(record.created).isoformat() + bstack1l1111l_opy_ (u"ࠪ࡞ࠬᨒ"),
                    bstack1l1111l_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᨓ"): record.levelname,
                    bstack1l1111l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᨔ"): record.message,
                    bstack1l1lll11111_opy_: bstack11l1llll_opy_
                })
        if len(bstack1llll1ll_opy_) > 0:
            bstack1l11l1l1_opy_.bstack11lllll1_opy_(bstack1llll1ll_opy_)
    except Exception as err:
        print(bstack1l1111l_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡹࡥࡤࡱࡱࡨࡤ࡬ࡩࡹࡶࡸࡶࡪࡀࠠࡼࡿࠪᨕ"), str(err))
def bstack1l1ll111l1_opy_(sequence, driver_command, response=None, driver = None, args = None):
    global bstack11111ll11_opy_
    bstack11llll11ll_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠧࡪࡵࡄ࠵࠶ࡿࡔࡦࡵࡷࠫᨖ"), None) and bstack1l111ll1_opy_(
            threading.current_thread(), bstack1l1111l_opy_ (u"ࠨࡣ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳࠧᨗ"), None)
    bstack11l111lll1_opy_ = getattr(driver, bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡃ࠴࠵ࡾ࡙ࡨࡰࡷ࡯ࡨࡘࡩࡡ࡯ᨘࠩ"), None) != None and getattr(driver, bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡄ࠵࠶ࡿࡓࡩࡱࡸࡰࡩ࡙ࡣࡢࡰࠪᨙ"), None) == True
    if sequence == bstack1l1111l_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࠫᨚ") and driver != None:
      if not bstack11111ll11_opy_ and bstack1lll11lll11_opy_() and bstack1l1111l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᨛ") in CONFIG and CONFIG[bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭᨜")] == True and bstack1l1llll1l1_opy_.bstack1l1l1ll11_opy_(driver_command) and (bstack11l111lll1_opy_ or bstack11llll11ll_opy_) and not bstack1111l1l1l_opy_(args):
        try:
          bstack11111ll11_opy_ = True
          logger.debug(bstack1l1111l_opy_ (u"ࠧࡑࡧࡵࡪࡴࡸ࡭ࡪࡰࡪࠤࡸࡩࡡ࡯ࠢࡩࡳࡷࠦࡻࡾࠩ᨝").format(driver_command))
          logger.debug(perform_scan(driver, driver_command=driver_command))
        except Exception as err:
          logger.debug(bstack1l1111l_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡵ࡫ࡲࡧࡱࡵࡱࠥࡹࡣࡢࡰࠣࡿࢂ࠭᨞").format(str(err)))
        bstack11111ll11_opy_ = False
    if sequence == bstack1l1111l_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࠨ᨟"):
        if driver_command == bstack1l1111l_opy_ (u"ࠪࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࠧᨠ"):
            bstack1l11l1l1_opy_.bstack1l1l1l1l11_opy_({
                bstack1l1111l_opy_ (u"ࠫ࡮ࡳࡡࡨࡧࠪᨡ"): response[bstack1l1111l_opy_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᨢ")],
                bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ᨣ"): store[bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡶࡨࡷࡹࡥࡵࡶ࡫ࡧࠫᨤ")]
            })
def bstack11lll1lll_opy_():
    global bstack11llll1ll_opy_
    bstack11lll111ll_opy_.bstack1l11ll1lll_opy_()
    logging.shutdown()
    bstack1l11l1l1_opy_.bstack1l1111ll_opy_()
    for driver in bstack11llll1ll_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack1l1ll1l111l_opy_(*args):
    global bstack11llll1ll_opy_
    bstack1l11l1l1_opy_.bstack1l1111ll_opy_()
    for driver in bstack11llll1ll_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack11ll11111l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1ll1lll_opy_(self, *args, **kwargs):
    bstack11l1lllll_opy_ = bstack1ll1ll111_opy_(self, *args, **kwargs)
    bstack111111l1l_opy_ = getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡕࡧࡶࡸࡒ࡫ࡴࡢࠩᨥ"), None)
    if bstack111111l1l_opy_ and bstack111111l1l_opy_.get(bstack1l1111l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩᨦ"), bstack1l1111l_opy_ (u"ࠪࠫᨧ")) == bstack1l1111l_opy_ (u"ࠫࡵ࡫࡮ࡥ࡫ࡱ࡫ࠬᨨ"):
        bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(self)
    return bstack11l1lllll_opy_
@measure(event_name=EVENTS.bstack11llll1l1l_opy_, stage=STAGE.bstack111111lll_opy_, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11lll11l1_opy_(framework_name):
    from bstack_utils.config import Config
    bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
    if bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡳ࡯ࡥࡡࡦࡥࡱࡲࡥࡥࠩᨩ")):
        return
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥ࡭ࡰࡦࡢࡧࡦࡲ࡬ࡦࡦࠪᨪ"), True)
    global bstack11ll111ll1_opy_
    global bstack1lllll1ll1_opy_
    bstack11ll111ll1_opy_ = framework_name
    logger.info(bstack1lll11111l_opy_.format(bstack11ll111ll1_opy_.split(bstack1l1111l_opy_ (u"ࠧ࠮ࠩᨫ"))[0]))
    try:
        from selenium import webdriver
        from selenium.webdriver.common.service import Service
        from selenium.webdriver.remote.webdriver import WebDriver
        if bstack1lll11lll11_opy_():
            Service.start = bstack111ll1l11_opy_
            Service.stop = bstack1l1l11ll11_opy_
            webdriver.Remote.__init__ = bstack1lll1l1111_opy_
            webdriver.Remote.get = bstack1ll1ll1l1l_opy_
            if not isinstance(os.getenv(bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑ࡛ࡗࡉࡘ࡚࡟ࡑࡃࡕࡅࡑࡒࡅࡍࠩᨬ")), str):
                return
            WebDriver.close = bstack1llll111l1_opy_
            WebDriver.quit = bstack1ll1l11l11_opy_
            WebDriver.getAccessibilityResults = getAccessibilityResults
            WebDriver.get_accessibility_results = getAccessibilityResults
            WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
            WebDriver.get_accessibility_results_summary = getAccessibilityResultsSummary
            WebDriver.performScan = perform_scan
            WebDriver.perform_scan = perform_scan
        if not bstack1lll11lll11_opy_() and bstack1l11l1l1_opy_.on():
            webdriver.Remote.__init__ = bstack1ll1ll1lll_opy_
        bstack1lllll1ll1_opy_ = True
    except Exception as e:
        pass
    bstack11lllll1ll_opy_()
    if os.environ.get(bstack1l1111l_opy_ (u"ࠩࡖࡉࡑࡋࡎࡊࡗࡐࡣࡔࡘ࡟ࡑࡎࡄ࡝࡜ࡘࡉࡈࡊࡗࡣࡎࡔࡓࡕࡃࡏࡐࡊࡊࠧᨭ")):
        bstack1lllll1ll1_opy_ = eval(os.environ.get(bstack1l1111l_opy_ (u"ࠪࡗࡊࡒࡅࡏࡋࡘࡑࡤࡕࡒࡠࡒࡏࡅ࡞࡝ࡒࡊࡉࡋࡘࡤࡏࡎࡔࡖࡄࡐࡑࡋࡄࠨᨮ")))
    if not bstack1lllll1ll1_opy_:
        bstack11ll1ll1l1_opy_(bstack1l1111l_opy_ (u"ࠦࡕࡧࡣ࡬ࡣࡪࡩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠨᨯ"), bstack1l1llll1l_opy_)
    if bstack11ll11lll1_opy_():
        try:
            from selenium.webdriver.remote.remote_connection import RemoteConnection
            RemoteConnection._11l11l1lll_opy_ = bstack111l111ll_opy_
        except Exception as e:
            logger.error(bstack11l1l11l11_opy_.format(str(e)))
    if bstack1l1111l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬᨰ") in str(framework_name).lower():
        if not bstack1lll11lll11_opy_():
            return
        try:
            from pytest_selenium import pytest_selenium
            from _pytest.config import Config
            pytest_selenium.pytest_report_header = bstack1ll1l11ll_opy_
            from pytest_selenium.drivers import browserstack
            browserstack.pytest_selenium_runtest_makereport = bstack1l11ll11ll_opy_
            Config.getoption = bstack1l1lllll1_opy_
        except Exception as e:
            pass
        try:
            from pytest_bdd import reporting
            reporting.runtest_makereport = bstack11ll1llll1_opy_
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack111l1ll11_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1l11l11_opy_(self):
    global bstack11ll111ll1_opy_
    global bstack11lll1ll1l_opy_
    global bstack1l111l1lll_opy_
    try:
        if bstack1l1111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᨱ") in bstack11ll111ll1_opy_ and self.session_id != None and bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠧࡵࡧࡶࡸࡘࡺࡡࡵࡷࡶࠫᨲ"), bstack1l1111l_opy_ (u"ࠨࠩᨳ")) != bstack1l1111l_opy_ (u"ࠩࡶ࡯࡮ࡶࡰࡦࡦࠪᨴ"):
            bstack11ll11lll_opy_ = bstack1l1111l_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪᨵ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack1l1111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᨶ")
            bstack1ll1lll11l_opy_(logger, True)
            if self != None:
                bstack11ll1111ll_opy_(self, bstack11ll11lll_opy_, bstack1l1111l_opy_ (u"ࠬ࠲ࠠࠨᨷ").join(threading.current_thread().bstackTestErrorMessages))
        item = store.get(bstack1l1111l_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡵࡧࡶࡸࡤ࡯ࡴࡦ࡯ࠪᨸ"), None)
        if item is not None and bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠧࡢ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭ᨹ"), None):
            bstack11l11111_opy_.bstack1111l1ll_opy_(self, bstack1l1l11l11_opy_, logger, item)
        threading.current_thread().testStatus = bstack1l1111l_opy_ (u"ࠨࠩᨺ")
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠ࡮ࡣࡵ࡯࡮ࡴࡧࠡࡵࡷࡥࡹࡻࡳ࠻ࠢࠥᨻ") + str(e))
    bstack1l111l1lll_opy_(self)
    self.session_id = None
@measure(event_name=EVENTS.bstack11l1llll1l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1lll1l1111_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
    global CONFIG
    global bstack11lll1ll1l_opy_
    global bstack1l1l11l1l_opy_
    global bstack1l1ll1ll1l_opy_
    global bstack11ll111ll1_opy_
    global bstack1ll1ll111_opy_
    global bstack11llll1ll_opy_
    global bstack11l11l111l_opy_
    global bstack111111ll1_opy_
    global bstack1l1l11l11_opy_
    CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡕࡇࡏࠬᨼ")] = str(bstack11ll111ll1_opy_) + str(__version__)
    command_executor = bstack1ll111111l_opy_(bstack11l11l111l_opy_, CONFIG)
    logger.debug(bstack1l1l1l11ll_opy_.format(command_executor))
    proxy = bstack1lll1l111l_opy_(CONFIG, proxy)
    bstack1l1l1l111l_opy_ = 0
    try:
        if bstack1l1ll1ll1l_opy_ is True:
            bstack1l1l1l111l_opy_ = int(os.environ.get(bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫᨽ")))
    except:
        bstack1l1l1l111l_opy_ = 0
    bstack1l11lllll_opy_ = bstack1l111ll111_opy_(CONFIG, bstack1l1l1l111l_opy_)
    logger.debug(bstack11l1l1ll11_opy_.format(str(bstack1l11lllll_opy_)))
    bstack1l1l11l11_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨᨾ"))[bstack1l1l1l111l_opy_]
    if bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪᨿ") in CONFIG and CONFIG[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫᩀ")]:
        bstack11ll1l11l1_opy_(bstack1l11lllll_opy_, bstack111111ll1_opy_)
    if bstack1111ll11_opy_.bstack111ll111l_opy_(CONFIG, bstack1l1l1l111l_opy_) and bstack1111ll11_opy_.bstack1lll11111_opy_(bstack1l11lllll_opy_, options, desired_capabilities):
        threading.current_thread().a11yPlatform = True
        bstack1111ll11_opy_.set_capabilities(bstack1l11lllll_opy_, CONFIG)
    if desired_capabilities:
        bstack111l1llll_opy_ = bstack1l111lll1_opy_(desired_capabilities)
        bstack111l1llll_opy_[bstack1l1111l_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨᩁ")] = bstack1llll1111_opy_(CONFIG)
        bstack11l11lll1_opy_ = bstack1l111ll111_opy_(bstack111l1llll_opy_)
        if bstack11l11lll1_opy_:
            bstack1l11lllll_opy_ = update(bstack11l11lll1_opy_, bstack1l11lllll_opy_)
        desired_capabilities = None
    if options:
        bstack111lll1ll_opy_(options, bstack1l11lllll_opy_)
    if not options:
        options = bstack11lllll11_opy_(bstack1l11lllll_opy_)
    if proxy and bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠩ࠷࠲࠶࠶࠮࠱ࠩᩂ")):
        options.proxy(proxy)
    if options and bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩᩃ")):
        desired_capabilities = None
    if (
            not options and not desired_capabilities
    ) or (
            bstack1ll11llll1_opy_() < version.parse(bstack1l1111l_opy_ (u"ࠫ࠸࠴࠸࠯࠲ࠪᩄ")) and not desired_capabilities
    ):
        desired_capabilities = {}
        desired_capabilities.update(bstack1l11lllll_opy_)
    logger.info(bstack1ll111l11l_opy_)
    bstack1ll1111ll1_opy_.end(EVENTS.bstack11llll1l1l_opy_.value, EVENTS.bstack11llll1l1l_opy_.value + bstack1l1111l_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧᩅ"),
                               EVENTS.bstack11llll1l1l_opy_.value + bstack1l1111l_opy_ (u"ࠨ࠺ࡦࡰࡧࠦᩆ"), True, None)
    if bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠧ࠵࠰࠴࠴࠳࠶ࠧᩇ")):
        bstack1ll1ll111_opy_(self, command_executor=command_executor,
                  options=options, keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠨ࠵࠱࠼࠳࠶ࠧᩈ")):
        bstack1ll1ll111_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities, options=options,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠩ࠵࠲࠺࠹࠮࠱ࠩᩉ")):
        bstack1ll1ll111_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    else:
        bstack1ll1ll111_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive)
    try:
        bstack111lllll1l_opy_ = bstack1l1111l_opy_ (u"ࠪࠫᩊ")
        if bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠫ࠹࠴࠰࠯࠲ࡥ࠵ࠬᩋ")):
            bstack111lllll1l_opy_ = self.caps.get(bstack1l1111l_opy_ (u"ࠧࡵࡰࡵ࡫ࡰࡥࡱࡎࡵࡣࡗࡵࡰࠧᩌ"))
        else:
            bstack111lllll1l_opy_ = self.capabilities.get(bstack1l1111l_opy_ (u"ࠨ࡯ࡱࡶ࡬ࡱࡦࡲࡈࡶࡤࡘࡶࡱࠨᩍ"))
        if bstack111lllll1l_opy_:
            bstack11l1ll1ll_opy_(bstack111lllll1l_opy_)
            if bstack1ll11llll1_opy_() <= version.parse(bstack1l1111l_opy_ (u"ࠧ࠴࠰࠴࠷࠳࠶ࠧᩎ")):
                self.command_executor._url = bstack1l1111l_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤᩏ") + bstack11l11l111l_opy_ + bstack1l1111l_opy_ (u"ࠤ࠽࠼࠵࠵ࡷࡥ࠱࡫ࡹࡧࠨᩐ")
            else:
                self.command_executor._url = bstack1l1111l_opy_ (u"ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠧᩑ") + bstack111lllll1l_opy_ + bstack1l1111l_opy_ (u"ࠦ࠴ࡽࡤ࠰ࡪࡸࡦࠧᩒ")
            logger.debug(bstack1l1111l1l1_opy_.format(bstack111lllll1l_opy_))
        else:
            logger.debug(bstack11lll11lll_opy_.format(bstack1l1111l_opy_ (u"ࠧࡕࡰࡵ࡫ࡰࡥࡱࠦࡈࡶࡤࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨᩓ")))
    except Exception as e:
        logger.debug(bstack11lll11lll_opy_.format(e))
    bstack11lll1ll1l_opy_ = self.session_id
    if bstack1l1111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᩔ") in bstack11ll111ll1_opy_:
        threading.current_thread().bstackSessionId = self.session_id
        threading.current_thread().bstackSessionDriver = self
        threading.current_thread().bstackTestErrorMessages = []
        item = store.get(bstack1l1111l_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡶࡨࡷࡹࡥࡩࡵࡧࡰࠫᩕ"), None)
        if item:
            bstack1l1lll1l111_opy_ = getattr(item, bstack1l1111l_opy_ (u"ࠨࡡࡷࡩࡸࡺ࡟ࡤࡣࡶࡩࡤࡹࡴࡢࡴࡷࡩࡩ࠭ᩖ"), False)
            if not getattr(item, bstack1l1111l_opy_ (u"ࠩࡢࡨࡷ࡯ࡶࡦࡴࠪᩗ"), None) and bstack1l1lll1l111_opy_:
                setattr(store[bstack1l1111l_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧᩘ")], bstack1l1111l_opy_ (u"ࠫࡤࡪࡲࡪࡸࡨࡶࠬᩙ"), self)
        bstack111111l1l_opy_ = getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࡙࡫ࡳࡵࡏࡨࡸࡦ࠭ᩚ"), None)
        if bstack111111l1l_opy_ and bstack111111l1l_opy_.get(bstack1l1111l_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ᩛ"), bstack1l1111l_opy_ (u"ࠧࠨᩜ")) == bstack1l1111l_opy_ (u"ࠨࡲࡨࡲࡩ࡯࡮ࡨࠩᩝ"):
            bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(self)
    bstack11llll1ll_opy_.append(self)
    if bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬᩞ") in CONFIG and bstack1l1111l_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ᩟") in CONFIG[bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹ᩠ࠧ")][bstack1l1l1l111l_opy_]:
        bstack1l1l11l1l_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨᩡ")][bstack1l1l1l111l_opy_][bstack1l1111l_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫᩢ")]
    logger.debug(bstack11llll1l11_opy_.format(bstack11lll1ll1l_opy_))
@measure(event_name=EVENTS.bstack11l11lllll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1ll1l1l_opy_(self, url):
    global bstack1ll11ll1ll_opy_
    global CONFIG
    try:
        bstack111l1lll1_opy_(url, CONFIG, logger)
    except Exception as err:
        logger.debug(bstack1l11l1lll1_opy_.format(str(err)))
    try:
        bstack1ll11ll1ll_opy_(self, url)
    except Exception as e:
        try:
            parsed_error = str(e)
            if any(err_msg in parsed_error for err_msg in bstack11111lll1_opy_):
                bstack111l1lll1_opy_(url, CONFIG, logger, True)
        except Exception as err:
            logger.debug(bstack1l11l1lll1_opy_.format(str(err)))
        raise e
def bstack11llllll1l_opy_(item, when):
    global bstack11lll1llll_opy_
    try:
        bstack11lll1llll_opy_(item, when)
    except Exception as e:
        pass
def bstack11ll1llll1_opy_(item, call, rep):
    global bstack11llll1ll1_opy_
    global bstack11llll1ll_opy_
    name = bstack1l1111l_opy_ (u"ࠧࠨᩣ")
    try:
        if rep.when == bstack1l1111l_opy_ (u"ࠨࡥࡤࡰࡱ࠭ᩤ"):
            bstack11lll1ll1l_opy_ = threading.current_thread().bstackSessionId
            bstack1l1ll1l11ll_opy_ = item.config.getoption(bstack1l1111l_opy_ (u"ࠩࡶ࡯࡮ࡶࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫᩥ"))
            try:
                if (str(bstack1l1ll1l11ll_opy_).lower() != bstack1l1111l_opy_ (u"ࠪࡸࡷࡻࡥࠨᩦ")):
                    name = str(rep.nodeid)
                    bstack1l11l1l1l_opy_ = bstack1l11l1lll_opy_(bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬᩧ"), name, bstack1l1111l_opy_ (u"ࠬ࠭ᩨ"), bstack1l1111l_opy_ (u"࠭ࠧᩩ"), bstack1l1111l_opy_ (u"ࠧࠨᩪ"), bstack1l1111l_opy_ (u"ࠨࠩᩫ"))
                    os.environ[bstack1l1111l_opy_ (u"ࠩࡓ࡝࡙ࡋࡓࡕࡡࡗࡉࡘ࡚࡟ࡏࡃࡐࡉࠬᩬ")] = name
                    for driver in bstack11llll1ll_opy_:
                        if bstack11lll1ll1l_opy_ == driver.session_id:
                            driver.execute_script(bstack1l11l1l1l_opy_)
            except Exception as e:
                logger.debug(bstack1l1111l_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠤ࡫ࡵࡲࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡹࡥࡴࡵ࡬ࡳࡳࡀࠠࡼࡿࠪᩭ").format(str(e)))
            try:
                bstack1l111l11l_opy_(rep.outcome.lower())
                if rep.outcome.lower() != bstack1l1111l_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬᩮ"):
                    status = bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᩯ") if rep.outcome.lower() == bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᩰ") else bstack1l1111l_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧᩱ")
                    reason = bstack1l1111l_opy_ (u"ࠨࠩᩲ")
                    if status == bstack1l1111l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᩳ"):
                        reason = rep.longrepr.reprcrash.message
                        if (not threading.current_thread().bstackTestErrorMessages):
                            threading.current_thread().bstackTestErrorMessages = []
                        threading.current_thread().bstackTestErrorMessages.append(reason)
                    level = bstack1l1111l_opy_ (u"ࠪ࡭ࡳ࡬࡯ࠨᩴ") if status == bstack1l1111l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫ᩵") else bstack1l1111l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫ᩶")
                    data = name + bstack1l1111l_opy_ (u"࠭ࠠࡱࡣࡶࡷࡪࡪࠡࠨ᩷") if status == bstack1l1111l_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧ᩸") else name + bstack1l1111l_opy_ (u"ࠨࠢࡩࡥ࡮ࡲࡥࡥࠣࠣࠫ᩹") + reason
                    bstack1111l1111_opy_ = bstack1l11l1lll_opy_(bstack1l1111l_opy_ (u"ࠩࡤࡲࡳࡵࡴࡢࡶࡨࠫ᩺"), bstack1l1111l_opy_ (u"ࠪࠫ᩻"), bstack1l1111l_opy_ (u"ࠫࠬ᩼"), bstack1l1111l_opy_ (u"ࠬ࠭᩽"), level, data)
                    for driver in bstack11llll1ll_opy_:
                        if bstack11lll1ll1l_opy_ == driver.session_id:
                            driver.execute_script(bstack1111l1111_opy_)
            except Exception as e:
                logger.debug(bstack1l1111l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࠢࡶࡩࡸࡹࡩࡰࡰࠣࡧࡴࡴࡴࡦࡺࡷࠤ࡫ࡵࡲࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡹࡥࡴࡵ࡬ࡳࡳࡀࠠࡼࡿࠪ᩾").format(str(e)))
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡷࡹࡧࡴࡦࠢ࡬ࡲࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡷࡩࡸࡺࠠࡴࡶࡤࡸࡺࡹ࠺ࠡࡽࢀ᩿ࠫ").format(str(e)))
    bstack11llll1ll1_opy_(item, call, rep)
notset = Notset()
def bstack1l1lllll1_opy_(self, name: str, default=notset, skip: bool = False):
    global bstack11lll11l1l_opy_
    if str(name).lower() == bstack1l1111l_opy_ (u"ࠨࡦࡵ࡭ࡻ࡫ࡲࠨ᪀"):
        return bstack1l1111l_opy_ (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠣ᪁")
    else:
        return bstack11lll11l1l_opy_(self, name, default, skip)
def bstack111l111ll_opy_(self):
    global CONFIG
    global bstack111ll11l1_opy_
    try:
        proxy = bstack1ll1llll11_opy_(CONFIG)
        if proxy:
            if proxy.endswith(bstack1l1111l_opy_ (u"ࠪ࠲ࡵࡧࡣࠨ᪂")):
                proxies = bstack111lll11l1_opy_(proxy, bstack1ll111111l_opy_())
                if len(proxies) > 0:
                    protocol, bstack1l11l111ll_opy_ = proxies.popitem()
                    if bstack1l1111l_opy_ (u"ࠦ࠿࠵࠯ࠣ᪃") in bstack1l11l111ll_opy_:
                        return bstack1l11l111ll_opy_
                    else:
                        return bstack1l1111l_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨ᪄") + bstack1l11l111ll_opy_
            else:
                return proxy
    except Exception as e:
        logger.error(bstack1l1111l_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࠢࡳࡶࡴࡾࡹࠡࡷࡵࡰࠥࡀࠠࡼࡿࠥ᪅").format(str(e)))
    return bstack111ll11l1_opy_(self)
def bstack11ll11lll1_opy_():
    return (bstack1l1111l_opy_ (u"ࠧࡩࡶࡷࡴࡕࡸ࡯ࡹࡻࠪ᪆") in CONFIG or bstack1l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬ᪇") in CONFIG) and bstack11ll1llll_opy_() and bstack1ll11llll1_opy_() >= version.parse(
        bstack1lll111ll_opy_)
def bstack11ll111l1l_opy_(self,
               executablePath=None,
               channel=None,
               args=None,
               ignoreDefaultArgs=None,
               handleSIGINT=None,
               handleSIGTERM=None,
               handleSIGHUP=None,
               timeout=None,
               env=None,
               headless=None,
               devtools=None,
               proxy=None,
               downloadsPath=None,
               slowMo=None,
               tracesDir=None,
               chromiumSandbox=None,
               firefoxUserPrefs=None
               ):
    global CONFIG
    global bstack1l1l11l1l_opy_
    global bstack1l1ll1ll1l_opy_
    global bstack11ll111ll1_opy_
    CONFIG[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫ᪈")] = str(bstack11ll111ll1_opy_) + str(__version__)
    bstack1l1l1l111l_opy_ = 0
    try:
        if bstack1l1ll1ll1l_opy_ is True:
            bstack1l1l1l111l_opy_ = int(os.environ.get(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡎࡔࡄࡆ࡚ࠪ᪉")))
    except:
        bstack1l1l1l111l_opy_ = 0
    CONFIG[bstack1l1111l_opy_ (u"ࠦ࡮ࡹࡐ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥ᪊")] = True
    bstack1l11lllll_opy_ = bstack1l111ll111_opy_(CONFIG, bstack1l1l1l111l_opy_)
    logger.debug(bstack11l1l1ll11_opy_.format(str(bstack1l11lllll_opy_)))
    if CONFIG.get(bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩ᪋")):
        bstack11ll1l11l1_opy_(bstack1l11lllll_opy_, bstack111111ll1_opy_)
    if bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ᪌") in CONFIG and bstack1l1111l_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ᪍") in CONFIG[bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ᪎")][bstack1l1l1l111l_opy_]:
        bstack1l1l11l1l_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ᪏")][bstack1l1l1l111l_opy_][bstack1l1111l_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ᪐")]
    import urllib
    import json
    if bstack1l1111l_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨ᪑") in CONFIG and str(CONFIG[bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩ᪒")]).lower() != bstack1l1111l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ᪓"):
        bstack1ll1llll1_opy_ = bstack11111l111_opy_()
        bstack1l1111l1l_opy_ = bstack1ll1llll1_opy_ + urllib.parse.quote(json.dumps(bstack1l11lllll_opy_))
    else:
        bstack1l1111l1l_opy_ = bstack1l1111l_opy_ (u"ࠧࡸࡵࡶ࠾࠴࠵ࡣࡥࡲ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࡂࡧࡦࡶࡳ࠾ࠩ᪔") + urllib.parse.quote(json.dumps(bstack1l11lllll_opy_))
    browser = self.connect(bstack1l1111l1l_opy_)
    return browser
def bstack11lllll1ll_opy_():
    global bstack1lllll1ll1_opy_
    global bstack11ll111ll1_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        from bstack_utils.helper import bstack1l11111ll_opy_
        if not bstack1lll11lll11_opy_():
            global bstack11l1l11l1_opy_
            if not bstack11l1l11l1_opy_:
                from bstack_utils.helper import bstack111lll11l_opy_, bstack1l1l1l11l1_opy_
                bstack11l1l11l1_opy_ = bstack111lll11l_opy_()
                bstack1l1l1l11l1_opy_(bstack11ll111ll1_opy_)
            BrowserType.connect = bstack1l11111ll_opy_
            return
        BrowserType.launch = bstack11ll111l1l_opy_
        bstack1lllll1ll1_opy_ = True
    except Exception as e:
        pass
def bstack1l1ll1l1lll_opy_():
    global CONFIG
    global bstack11l1lll1l_opy_
    global bstack11l11l111l_opy_
    global bstack111111ll1_opy_
    global bstack1l1ll1ll1l_opy_
    global bstack1l1l1lllll_opy_
    CONFIG = json.loads(os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡄࡑࡑࡊࡎࡍࠧ᪕")))
    bstack11l1lll1l_opy_ = eval(os.environ.get(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪ᪖")))
    bstack11l11l111l_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡋ࡙ࡇࡥࡕࡓࡎࠪ᪗"))
    bstack111111l11_opy_(CONFIG, bstack11l1lll1l_opy_)
    bstack1l1l1lllll_opy_ = bstack11lll111ll_opy_.bstack1lllll1lll_opy_(CONFIG, bstack1l1l1lllll_opy_)
    global bstack1ll1ll111_opy_
    global bstack1l111l1lll_opy_
    global bstack11l1l1l11l_opy_
    global bstack1lll1ll1l_opy_
    global bstack1111l1lll_opy_
    global bstack1lll11l11l_opy_
    global bstack1ll1111111_opy_
    global bstack1ll11ll1ll_opy_
    global bstack111ll11l1_opy_
    global bstack11lll11l1l_opy_
    global bstack11lll1llll_opy_
    global bstack11llll1ll1_opy_
    try:
        from selenium import webdriver
        from selenium.webdriver.remote.webdriver import WebDriver
        bstack1ll1ll111_opy_ = webdriver.Remote.__init__
        bstack1l111l1lll_opy_ = WebDriver.quit
        bstack1ll1111111_opy_ = WebDriver.close
        bstack1ll11ll1ll_opy_ = WebDriver.get
    except Exception as e:
        pass
    if (bstack1l1111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧ᪘") in CONFIG or bstack1l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩ᪙") in CONFIG) and bstack11ll1llll_opy_():
        if bstack1ll11llll1_opy_() < version.parse(bstack1lll111ll_opy_):
            logger.error(bstack1ll11111ll_opy_.format(bstack1ll11llll1_opy_()))
        else:
            try:
                from selenium.webdriver.remote.remote_connection import RemoteConnection
                bstack111ll11l1_opy_ = RemoteConnection._11l11l1lll_opy_
            except Exception as e:
                logger.error(bstack11l1l11l11_opy_.format(str(e)))
    try:
        from _pytest.config import Config
        bstack11lll11l1l_opy_ = Config.getoption
        from _pytest import runner
        bstack11lll1llll_opy_ = runner._update_current_test_var
    except Exception as e:
        logger.warn(e, bstack111lllll_opy_)
    try:
        from pytest_bdd import reporting
        bstack11llll1ll1_opy_ = reporting.runtest_makereport
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡩ࡯ࡵࡷࡥࡱࡲࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹࡵࠠࡳࡷࡱࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡶࡨࡷࡹࡹࠧ᪚"))
    bstack111111ll1_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ᪛"), {}).get(bstack1l1111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ᪜"))
    bstack1l1ll1ll1l_opy_ = True
    bstack11lll11l1_opy_(bstack1lll11ll11_opy_)
if (bstack1llll1ll1ll_opy_()):
    bstack1l1ll1l1lll_opy_()
@bstack11llllll_opy_(class_method=False)
def bstack1l1lll11lll_opy_(hook_name, event, bstack1l1ll1llll1_opy_=None):
    if hook_name not in [bstack1l1111l_opy_ (u"ࠩࡶࡩࡹࡻࡰࡠࡨࡸࡲࡨࡺࡩࡰࡰࠪ᪝"), bstack1l1111l_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ᪞"), bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡱࡴࡪࡵ࡭ࡧࠪ᪟"), bstack1l1111l_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡱࡧࡹࡱ࡫ࠧ᪠"), bstack1l1111l_opy_ (u"࠭ࡳࡦࡶࡸࡴࡤࡩ࡬ࡢࡵࡶࠫ᪡"), bstack1l1111l_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡦࡰࡦࡹࡳࠨ᪢"), bstack1l1111l_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟࡮ࡧࡷ࡬ࡴࡪࠧ᪣"), bstack1l1111l_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲ࡫ࡴࡩࡱࡧࠫ᪤")]:
        return
    node = store[bstack1l1111l_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧ᪥")]
    if hook_name in [bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡱࡴࡪࡵ࡭ࡧࠪ᪦"), bstack1l1111l_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡱࡧࡹࡱ࡫ࠧᪧ")]:
        node = store[bstack1l1111l_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟࡮ࡱࡧࡹࡱ࡫࡟ࡪࡶࡨࡱࠬ᪨")]
    elif hook_name in [bstack1l1111l_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥࡣ࡭ࡣࡶࡷࠬ᪩"), bstack1l1111l_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡧࡱࡧࡳࡴࠩ᪪")]:
        node = store[bstack1l1111l_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡧࡱࡧࡳࡴࡡ࡬ࡸࡪࡳࠧ᪫")]
    if event == bstack1l1111l_opy_ (u"ࠪࡦࡪ࡬࡯ࡳࡧࠪ᪬"):
        hook_type = bstack111111ll11_opy_(hook_name)
        uuid = uuid4().__str__()
        bstack1ll1111l_opy_ = {
            bstack1l1111l_opy_ (u"ࠫࡺࡻࡩࡥࠩ᪭"): uuid,
            bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩ᪮"): bstack1llll111_opy_(),
            bstack1l1111l_opy_ (u"࠭ࡴࡺࡲࡨࠫ᪯"): bstack1l1111l_opy_ (u"ࠧࡩࡱࡲ࡯ࠬ᪰"),
            bstack1l1111l_opy_ (u"ࠨࡪࡲࡳࡰࡥࡴࡺࡲࡨࠫ᪱"): hook_type,
            bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟࡯ࡣࡰࡩࠬ᪲"): hook_name
        }
        store[bstack1l1111l_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧ᪳")].append(uuid)
        bstack1l1lll11l1l_opy_ = node.nodeid
        if hook_type == bstack1l1111l_opy_ (u"ࠫࡇࡋࡆࡐࡔࡈࡣࡊࡇࡃࡉࠩ᪴"):
            if not _1lll11l1_opy_.get(bstack1l1lll11l1l_opy_, None):
                _1lll11l1_opy_[bstack1l1lll11l1l_opy_] = {bstack1l1111l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶ᪵ࠫ"): []}
            _1lll11l1_opy_[bstack1l1lll11l1l_opy_][bstack1l1111l_opy_ (u"࠭ࡨࡰࡱ࡮ࡷ᪶ࠬ")].append(bstack1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠧࡶࡷ࡬ࡨ᪷ࠬ")])
        _1lll11l1_opy_[bstack1l1lll11l1l_opy_ + bstack1l1111l_opy_ (u"ࠨ࠯᪸ࠪ") + hook_name] = bstack1ll1111l_opy_
        bstack1l1ll1ll1ll_opy_(node, bstack1ll1111l_opy_, bstack1l1111l_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦ᪹ࠪ"))
    elif event == bstack1l1111l_opy_ (u"ࠪࡥ࡫ࡺࡥࡳ᪺ࠩ"):
        bstack1l11llll_opy_ = node.nodeid + bstack1l1111l_opy_ (u"ࠫ࠲࠭᪻") + hook_name
        _1lll11l1_opy_[bstack1l11llll_opy_][bstack1l1111l_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪ᪼")] = bstack1llll111_opy_()
        bstack1l1ll1lll11_opy_(_1lll11l1_opy_[bstack1l11llll_opy_][bstack1l1111l_opy_ (u"࠭ࡵࡶ࡫ࡧ᪽ࠫ")])
        bstack1l1ll1ll1ll_opy_(node, _1lll11l1_opy_[bstack1l11llll_opy_], bstack1l1111l_opy_ (u"ࠧࡉࡱࡲ࡯ࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ᪾"), bstack1l1ll1ll1l1_opy_=bstack1l1ll1llll1_opy_)
def bstack1l1ll1l1l11_opy_():
    global bstack1l1ll11ll1l_opy_
    if bstack1llll1ll1_opy_():
        bstack1l1ll11ll1l_opy_ = bstack1l1111l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨᪿࠬ")
    else:
        bstack1l1ll11ll1l_opy_ = bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵᫀࠩ")
@bstack1l11l1l1_opy_.bstack1l1lllll11l_opy_
def bstack1l1ll1l11l1_opy_():
    bstack1l1ll1l1l11_opy_()
    if bstack11ll1llll_opy_():
        bstack1ll1l1l11l_opy_(bstack1l1ll111l1_opy_)
    try:
        bstack111l11l11l_opy_(bstack1l1lll11lll_opy_)
    except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢ࡫ࡳࡴࡱࡳࠡࡲࡤࡸࡨ࡮࠺ࠡࡽࢀࠦ᫁").format(e))
bstack1l1ll1l11l1_opy_()