# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
class RobotHandler():
    def __init__(self, args, logger, bstack111ll1l1_opy_, bstack1111llll_opy_):
        self.args = args
        self.logger = logger
        self.bstack111ll1l1_opy_ = bstack111ll1l1_opy_
        self.bstack1111llll_opy_ = bstack1111llll_opy_
    @staticmethod
    def version():
        import robot
        return robot.__version__
    @staticmethod
    def bstack1ll11l11_opy_(bstack111ll1l1ll_opy_):
        bstack111ll1l111_opy_ = []
        if bstack111ll1l1ll_opy_:
            tokens = str(os.path.basename(bstack111ll1l1ll_opy_)).split(bstack1l1111l_opy_ (u"ࠣࡡཻࠥ"))
            camelcase_name = bstack1l1111l_opy_ (u"ࠤོࠣࠦ").join(t.title() for t in tokens)
            suite_name, bstack111ll1l1l1_opy_ = os.path.splitext(camelcase_name)
            bstack111ll1l111_opy_.append(suite_name)
        return bstack111ll1l111_opy_
    @staticmethod
    def bstack111ll1l11l_opy_(typename):
        if bstack1l1111l_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࠨཽ") in typename:
            return bstack1l1111l_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࡅࡳࡴࡲࡶࠧཾ")
        return bstack1l1111l_opy_ (u"࡛ࠧ࡮ࡩࡣࡱࡨࡱ࡫ࡤࡆࡴࡵࡳࡷࠨཿ")