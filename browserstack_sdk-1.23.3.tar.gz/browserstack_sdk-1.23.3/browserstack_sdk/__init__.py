# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import atexit
import signal
import yaml
import socket
import datetime
import string
import random
import collections.abc
import traceback
import copy
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from dotenv import load_dotenv
from bstack_utils.measure import bstack1ll1111ll1_opy_
from bstack_utils.percy import *
from browserstack_sdk.bstack1llllllll_opy_ import *
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.bstack1lll1l11ll_opy_ import bstack1lllllllll_opy_
import time
import requests
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.measure import measure
def bstack1ll11l11ll_opy_():
  global CONFIG
  headers = {
        bstack1l1111l_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫ৖"): bstack1l1111l_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩৗ"),
      }
  proxies = bstack1lll11llll_opy_(CONFIG, bstack1l1ll11111_opy_)
  try:
    response = requests.get(bstack1l1ll11111_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack1l1ll1l1ll_opy_ = response.json()[bstack1l1111l_opy_ (u"ࠧࡩࡷࡥࡷࠬ৘")]
      logger.debug(bstack1ll11l1111_opy_.format(response.json()))
      return bstack1l1ll1l1ll_opy_
    else:
      logger.debug(bstack1l1l1111ll_opy_.format(bstack1l1111l_opy_ (u"ࠣࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡎࡘࡕࡎࠡࡲࡤࡶࡸ࡫ࠠࡦࡴࡵࡳࡷࠦࠢ৙")))
  except Exception as e:
    logger.debug(bstack1l1l1111ll_opy_.format(e))
def bstack11l11111l1_opy_(hub_url):
  global CONFIG
  url = bstack1l1111l_opy_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠦ৚")+  hub_url + bstack1l1111l_opy_ (u"ࠥ࠳ࡨ࡮ࡥࡤ࡭ࠥ৛")
  headers = {
        bstack1l1111l_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪড়"): bstack1l1111l_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨঢ়"),
      }
  proxies = bstack1lll11llll_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack11ll1ll111_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack1ll1llll1l_opy_.format(hub_url, e))
@measure(event_name=EVENTS.bstack1llll11l1l_opy_, stage=STAGE.SINGLE)
def bstack1llll1l1ll_opy_():
  try:
    global bstack11l11l111l_opy_
    bstack1l1ll1l1ll_opy_ = bstack1ll11l11ll_opy_()
    bstack1111ll111_opy_ = []
    results = []
    for bstack1lllll1l1_opy_ in bstack1l1ll1l1ll_opy_:
      bstack1111ll111_opy_.append(bstack11ll1l11ll_opy_(target=bstack11l11111l1_opy_,args=(bstack1lllll1l1_opy_,)))
    for t in bstack1111ll111_opy_:
      t.start()
    for t in bstack1111ll111_opy_:
      results.append(t.join())
    bstack1l11l11l1_opy_ = {}
    for item in results:
      hub_url = item[bstack1l1111l_opy_ (u"࠭ࡨࡶࡤࡢࡹࡷࡲࠧ৞")]
      latency = item[bstack1l1111l_opy_ (u"ࠧ࡭ࡣࡷࡩࡳࡩࡹࠨয়")]
      bstack1l11l11l1_opy_[hub_url] = latency
    bstack1l111ll11l_opy_ = min(bstack1l11l11l1_opy_, key= lambda x: bstack1l11l11l1_opy_[x])
    bstack11l11l111l_opy_ = bstack1l111ll11l_opy_
    logger.debug(bstack1l1l1llll1_opy_.format(bstack1l111ll11l_opy_))
  except Exception as e:
    logger.debug(bstack1l1llllll_opy_.format(e))
from bstack_utils.messages import *
from bstack_utils import bstack11lll111ll_opy_
from bstack_utils.helper import bstack11ll11ll11_opy_, bstack1ll1l11111_opy_, bstack111l1l1ll_opy_, bstack1l111ll1_opy_, \
  bstack1l11lll11_opy_, \
  Notset, bstack1llll1111_opy_, \
  bstack1ll11l1ll_opy_, bstack11l1lll11_opy_, bstack1lll111l11_opy_, bstack11l11llll1_opy_, bstack1llll1ll1_opy_, bstack11ll1llll_opy_, \
  bstack111l1111l_opy_, \
  bstack1ll11l1l1l_opy_, bstack1ll11l1l11_opy_, bstack11l1ll1ll_opy_, bstack1l11l1l1ll_opy_, \
  bstack1ll1lll11l_opy_, bstack11l1l11ll_opy_, bstack11ll111lll_opy_, bstack1l1l1ll1l_opy_
from bstack_utils.bstack111ll1ll1_opy_ import bstack1ll11l111_opy_
from bstack_utils.bstack1l1ll111l_opy_ import bstack1ll1l1l11l_opy_
from bstack_utils.bstack1llll11ll_opy_ import bstack11ll1111ll_opy_, bstack11l1l1l1ll_opy_
from bstack_utils.bstack1l1llll1l1_opy_ import bstack1l1llll1l1_opy_
from bstack_utils.proxy import bstack111lll11l1_opy_, bstack1lll11llll_opy_, bstack1ll1llll11_opy_, bstack1l1llll111_opy_
from browserstack_sdk.bstack1111l11l_opy_ import *
from browserstack_sdk.bstack1111lll1_opy_ import *
from bstack_utils.bstack11l11lll1l_opy_ import bstack1l111l11l_opy_
from browserstack_sdk.bstack11l11l1l_opy_ import *
import logging
import requests
from bstack_utils.constants import *
from bstack_utils.bstack11lll111ll_opy_ import get_logger
from bstack_utils.measure import measure
logger = get_logger(__name__)
@measure(event_name=EVENTS.bstack11lll1l111_opy_, stage=STAGE.SINGLE)
def bstack1111l1l11_opy_():
    global bstack11l11l111l_opy_
    try:
        bstack11lll1l1ll_opy_ = bstack1ll1ll1l11_opy_()
        bstack1lll1ll111_opy_(bstack11lll1l1ll_opy_)
        hub_url = bstack11lll1l1ll_opy_.get(bstack1l1111l_opy_ (u"ࠣࡷࡵࡰࠧৠ"), bstack1l1111l_opy_ (u"ࠤࠥৡ"))
        if hub_url.endswith(bstack1l1111l_opy_ (u"ࠪ࠳ࡼࡪ࠯ࡩࡷࡥࠫৢ")):
            hub_url = hub_url.rsplit(bstack1l1111l_opy_ (u"ࠫ࠴ࡽࡤ࠰ࡪࡸࡦࠬৣ"), 1)[0]
        if hub_url.startswith(bstack1l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭৤")):
            hub_url = hub_url[7:]
        elif hub_url.startswith(bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ৥")):
            hub_url = hub_url[8:]
        bstack11l11l111l_opy_ = hub_url
    except Exception as e:
        raise RuntimeError(e)
def bstack1ll1ll1l11_opy_():
    global CONFIG
    bstack1ll11l11l1_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠧࡵࡷࡵࡦࡴ࡙ࡣࡢ࡮ࡨࡓࡵࡺࡩࡰࡰࡶࠫ০"), {}).get(bstack1l1111l_opy_ (u"ࠨࡩࡵ࡭ࡩࡔࡡ࡮ࡧࠪ১"), bstack1l1111l_opy_ (u"ࠩࡑࡓࡤࡍࡒࡊࡆࡢࡒࡆࡓࡅࡠࡒࡄࡗࡘࡋࡄࠨ২"))
    if not isinstance(bstack1ll11l11l1_opy_, str):
        raise ValueError(bstack1l1111l_opy_ (u"ࠥࡅ࡙࡙ࠠ࠻ࠢࡊࡶ࡮ࡪࠠ࡯ࡣࡰࡩࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡸࡤࡰ࡮ࡪࠠࡴࡶࡵ࡭ࡳ࡭ࠢ৩"))
    try:
        bstack11lll1l1ll_opy_ = bstack1lll111l1l_opy_(bstack1ll11l11l1_opy_)
        return bstack11lll1l1ll_opy_
    except Exception as e:
        logger.error(bstack1l1111l_opy_ (u"ࠦࡆ࡚ࡓࠡ࠼ࠣࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡧࡳ࡫ࡧࠤࡩ࡫ࡴࡢ࡫࡯ࡷࠥࡀࠠࡼࡿࠥ৪").format(str(e)))
        return {}
def bstack1lll111l1l_opy_(bstack1ll11l11l1_opy_):
    global CONFIG
    try:
        if not CONFIG[bstack1l1111l_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧ৫")] or not CONFIG[bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩ৬")]:
            raise ValueError(bstack1l1111l_opy_ (u"ࠢࡎ࡫ࡶࡷ࡮ࡴࡧࠡࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠠࡶࡵࡨࡶࡳࡧ࡭ࡦࠢࡲࡶࠥࡧࡣࡤࡧࡶࡷࠥࡱࡥࡺࠤ৭"))
        url = bstack11l1ll1l1_opy_ + bstack1ll11l11l1_opy_
        auth = (CONFIG[bstack1l1111l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪ৮")], CONFIG[bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬ৯")])
        response = requests.get(url, auth=auth)
        if response.status_code == 200 and response.text:
            bstack1ll111lll1_opy_ = json.loads(response.text)
            return bstack1ll111lll1_opy_
    except ValueError as ve:
        logger.error(bstack1l1111l_opy_ (u"ࠥࡅ࡙࡙ࠠ࠻ࠢࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡫࡫ࡴࡤࡪ࡬ࡲ࡬ࠦࡧࡳ࡫ࡧࠤࡩ࡫ࡴࡢ࡫࡯ࡷࠥࡀࠠࡼࡿࠥৰ").format(str(ve)))
        raise ValueError(ve)
    except Exception as e:
        logger.error(bstack1l1111l_opy_ (u"ࠦࡆ࡚ࡓࠡ࠼ࠣࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡬ࡥࡵࡥ࡫࡭ࡳ࡭ࠠࡨࡴ࡬ࡨࠥࡪࡥࡵࡣ࡬ࡰࡸࠦ࠺ࠡࡽࢀࠦৱ").format(str(e)))
        raise RuntimeError(e)
    return {}
def bstack1lll1ll111_opy_(bstack1l1l111ll_opy_):
    global CONFIG
    if bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩ৲") not in CONFIG or str(CONFIG[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ৳")]).lower() == bstack1l1111l_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭৴"):
        CONFIG[bstack1l1111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࠧ৵")] = False
    elif bstack1l1111l_opy_ (u"ࠩ࡬ࡷ࡙ࡸࡩࡢ࡮ࡊࡶ࡮ࡪࠧ৶") in bstack1l1l111ll_opy_:
        bstack1l1ll111ll_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧ৷"), {})
        logger.debug(bstack1l1111l_opy_ (u"ࠦࡆ࡚ࡓࠡ࠼ࠣࡉࡽ࡯ࡳࡵ࡫ࡱ࡫ࠥࡲ࡯ࡤࡣ࡯ࠤࡴࡶࡴࡪࡱࡱࡷ࠿ࠦࠥࡴࠤ৸"), bstack1l1ll111ll_opy_)
        bstack1ll1ll111l_opy_ = bstack1l1l111ll_opy_.get(bstack1l1111l_opy_ (u"ࠧࡩࡵࡴࡶࡲࡱࡗ࡫ࡰࡦࡣࡷࡩࡷࡹࠢ৹"), [])
        bstack1ll1l111ll_opy_ = bstack1l1111l_opy_ (u"ࠨࠬࠣ৺").join(bstack1ll1ll111l_opy_)
        logger.debug(bstack1l1111l_opy_ (u"ࠢࡂࡖࡖࠤ࠿ࠦࡃࡶࡵࡷࡳࡲࠦࡲࡦࡲࡨࡥࡹ࡫ࡲࠡࡵࡷࡶ࡮ࡴࡧ࠻ࠢࠨࡷࠧ৻"), bstack1ll1l111ll_opy_)
        bstack111lll1l1l_opy_ = {
            bstack1l1111l_opy_ (u"ࠣ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠥৼ"): bstack1l1111l_opy_ (u"ࠤࡤࡸࡸ࠳ࡲࡦࡲࡨࡥࡹ࡫ࡲࠣ৽"),
            bstack1l1111l_opy_ (u"ࠥࡪࡴࡸࡣࡦࡎࡲࡧࡦࡲࠢ৾"): bstack1l1111l_opy_ (u"ࠦࡹࡸࡵࡦࠤ৿"),
            bstack1l1111l_opy_ (u"ࠧࡩࡵࡴࡶࡲࡱ࠲ࡸࡥࡱࡧࡤࡸࡪࡸࠢ਀"): bstack1ll1l111ll_opy_
        }
        bstack1l1ll111ll_opy_.update(bstack111lll1l1l_opy_)
        logger.debug(bstack1l1111l_opy_ (u"ࠨࡁࡕࡕࠣ࠾࡛ࠥࡰࡥࡣࡷࡩࡩࠦ࡬ࡰࡥࡤࡰࠥࡵࡰࡵ࡫ࡲࡲࡸࡀࠠࠦࡵࠥਁ"), bstack1l1ll111ll_opy_)
        CONFIG[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫਂ")] = bstack1l1ll111ll_opy_
        logger.debug(bstack1l1111l_opy_ (u"ࠣࡃࡗࡗࠥࡀࠠࡇ࡫ࡱࡥࡱࠦࡃࡐࡐࡉࡍࡌࡀࠠࠦࡵࠥਃ"), CONFIG)
def bstack11111l111_opy_():
    bstack11lll1l1ll_opy_ = bstack1ll1ll1l11_opy_()
    if not bstack11lll1l1ll_opy_[bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࡛ࡲ࡭ࠩ਄")]:
      raise ValueError(bstack1l1111l_opy_ (u"ࠥࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࡕࡳ࡮ࠣ࡭ࡸࠦ࡭ࡪࡵࡶ࡭ࡳ࡭ࠠࡧࡴࡲࡱࠥ࡭ࡲࡪࡦࠣࡨࡪࡺࡡࡪ࡮ࡶ࠲ࠧਅ"))
    return bstack11lll1l1ll_opy_[bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࡖࡴ࡯ࠫਆ")] + bstack1l1111l_opy_ (u"ࠬࡅࡣࡢࡲࡶࡁࠬਇ")
@measure(event_name=EVENTS.bstack1l1l11llll_opy_, stage=STAGE.SINGLE)
def bstack1l1ll1lll1_opy_() -> list:
    global CONFIG
    result = []
    if CONFIG:
        auth = (CONFIG[bstack1l1111l_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨਈ")], CONFIG[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪਉ")])
        url = bstack1lll11ll1l_opy_
        logger.debug(bstack1l1111l_opy_ (u"ࠣࡃࡷࡸࡪࡳࡰࡵ࡫ࡱ࡫ࠥࡺ࡯ࠡࡨࡨࡸࡨ࡮ࠠࡣࡷ࡬ࡰࡩࡹࠠࡧࡴࡲࡱࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤ࡙ࡻࡲࡣࡱࡖࡧࡦࡲࡥࠡࡃࡓࡍࠧਊ"))
        try:
            response = requests.get(url, auth=auth, headers={bstack1l1111l_opy_ (u"ࠤࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠣ਋"): bstack1l1111l_opy_ (u"ࠥࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳࠨ਌")})
            if response.status_code == 200:
                bstack1ll111l1l1_opy_ = json.loads(response.text)
                bstack1l111ll1l_opy_ = bstack1ll111l1l1_opy_.get(bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡶࠫ਍"), [])
                if bstack1l111ll1l_opy_:
                    bstack1ll1l11lll_opy_ = bstack1l111ll1l_opy_[0]
                    bstack1ll1l1l1l_opy_ = bstack1ll1l11lll_opy_.get(bstack1l1111l_opy_ (u"ࠬ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨ਎"))
                    bstack1l1lll11l1_opy_ = bstack1l11l111l1_opy_ + bstack1ll1l1l1l_opy_
                    result.extend([bstack1ll1l1l1l_opy_, bstack1l1lll11l1_opy_])
                    logger.info(bstack1l1l11l111_opy_.format(bstack1l1lll11l1_opy_))
                    bstack1l111111l_opy_ = CONFIG[bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩਏ")]
                    if bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩਐ") in CONFIG:
                      bstack1l111111l_opy_ += bstack1l1111l_opy_ (u"ࠨࠢࠪ਑") + CONFIG[bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ਒")]
                    if bstack1l111111l_opy_ != bstack1ll1l11lll_opy_.get(bstack1l1111l_opy_ (u"ࠪࡲࡦࡳࡥࠨਓ")):
                      logger.debug(bstack1l1lll1l11_opy_.format(bstack1ll1l11lll_opy_.get(bstack1l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩਔ")), bstack1l111111l_opy_))
                    return result
                else:
                    logger.debug(bstack1l1111l_opy_ (u"ࠧࡇࡔࡔࠢ࠽ࠤࡓࡵࠠࡣࡷ࡬ࡰࡩࡹࠠࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࠤਕ"))
            else:
                logger.debug(bstack1l1111l_opy_ (u"ࠨࡁࡕࡕࠣ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡨࡨࡸࡨ࡮ࠠࡣࡷ࡬ࡰࡩࡹ࠮ࠣਖ"))
        except Exception as e:
            logger.error(bstack1l1111l_opy_ (u"ࠢࡂࡖࡖࠤ࠿ࠦࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡩࡨࡸࡹ࡯࡮ࡨࠢࡥࡹ࡮ࡲࡤࡴࠢ࠽ࠤࢀࢃࠢਗ").format(str(e)))
    else:
        logger.debug(bstack1l1111l_opy_ (u"ࠣࡃࡗࡗࠥࡀࠠࡄࡑࡑࡊࡎࡍࠠࡪࡵࠣࡲࡴࡺࠠࡴࡧࡷ࠲࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡨࡨࡸࡨ࡮ࠠࡣࡷ࡬ࡰࡩࡹ࠮ࠣਘ"))
    return [None, None]
import bstack_utils.bstack11111ll1l_opy_ as bstack1lllllll1l_opy_
import bstack_utils.bstack1ll1ll1111_opy_ as bstack1ll1l1lll1_opy_
bstack1l111llll_opy_ = bstack1l1111l_opy_ (u"ࠩࠣࠤ࠴࠰ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤ࠯࠵࡜࡯ࠢࠣ࡭࡫࠮ࡰࡢࡩࡨࠤࡂࡃ࠽ࠡࡸࡲ࡭ࡩࠦ࠰ࠪࠢࡾࡠࡳࠦࠠࠡࡶࡵࡽࢀࡢ࡮ࠡࡥࡲࡲࡸࡺࠠࡧࡵࠣࡁࠥࡸࡥࡲࡷ࡬ࡶࡪ࠮࡜ࠨࡨࡶࡠࠬ࠯࠻࡝ࡰࠣࠤࠥࠦࠠࡧࡵ࠱ࡥࡵࡶࡥ࡯ࡦࡉ࡭ࡱ࡫ࡓࡺࡰࡦࠬࡧࡹࡴࡢࡥ࡮ࡣࡵࡧࡴࡩ࠮ࠣࡎࡘࡕࡎ࠯ࡵࡷࡶ࡮ࡴࡧࡪࡨࡼࠬࡵࡥࡩ࡯ࡦࡨࡼ࠮ࠦࠫࠡࠤ࠽ࠦࠥ࠱ࠠࡋࡕࡒࡒ࠳ࡹࡴࡳ࡫ࡱ࡫࡮࡬ࡹࠩࡌࡖࡓࡓ࠴ࡰࡢࡴࡶࡩ࠭࠮ࡡࡸࡣ࡬ࡸࠥࡴࡥࡸࡒࡤ࡫ࡪ࠸࠮ࡦࡸࡤࡰࡺࡧࡴࡦࠪࠥࠬ࠮ࠦ࠽࠿ࠢࡾࢁࠧ࠲ࠠ࡝ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡪࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡥࡵࡣ࡬ࡰࡸࠨࡽ࡝ࠩࠬ࠭࠮ࡡࠢࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠥࡡ࠮ࠦࠫࠡࠤ࠯ࡠࡡࡴࠢࠪ࡞ࡱࠤࠥࠦࠠࡾࡥࡤࡸࡨ࡮ࠨࡦࡺࠬࡿࡡࡴࠠࠡࠢࠣࢁࡡࡴࠠࠡࡿ࡟ࡲࠥࠦ࠯ࠫࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࠪ࠰ࠩਙ")
bstack1l11ll1l11_opy_ = bstack1l1111l_opy_ (u"ࠪࡠࡳ࠵ࠪࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠥ࠰࠯࡝ࡰࡦࡳࡳࡹࡴࠡࡤࡶࡸࡦࡩ࡫ࡠࡲࡤࡸ࡭ࠦ࠽ࠡࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࡛ࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠵ࡠࡠࡳࡩ࡯࡯ࡵࡷࠤࡧࡹࡴࡢࡥ࡮ࡣࡨࡧࡰࡴࠢࡀࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࡞ࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰࡯ࡩࡳ࡭ࡴࡩࠢ࠰ࠤ࠶ࡣ࡜࡯ࡥࡲࡲࡸࡺࠠࡱࡡ࡬ࡲࡩ࡫ࡸࠡ࠿ࠣࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࡝ࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࠯࡮ࡨࡲ࡬ࡺࡨࠡ࠯ࠣ࠶ࡢࡢ࡮ࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻࠦ࠽ࠡࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࠮ࡴ࡮࡬ࡧࡪ࠮࠰࠭ࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࠯࡮ࡨࡲ࡬ࡺࡨࠡ࠯ࠣ࠷࠮ࡢ࡮ࡤࡱࡱࡷࡹࠦࡩ࡮ࡲࡲࡶࡹࡥࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶ࠷ࡣࡧࡹࡴࡢࡥ࡮ࠤࡂࠦࡲࡦࡳࡸ࡭ࡷ࡫ࠨࠣࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠧ࠯࠻࡝ࡰ࡬ࡱࡵࡵࡲࡵࡡࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠺࡟ࡣࡵࡷࡥࡨࡱ࠮ࡤࡪࡵࡳࡲ࡯ࡵ࡮࠰࡯ࡥࡺࡴࡣࡩࠢࡀࠤࡦࡹࡹ࡯ࡥࠣࠬࡱࡧࡵ࡯ࡥ࡫ࡓࡵࡺࡩࡰࡰࡶ࠭ࠥࡃ࠾ࠡࡽ࡟ࡲࡱ࡫ࡴࠡࡥࡤࡴࡸࡁ࡜࡯ࡶࡵࡽࠥࢁ࡜࡯ࡥࡤࡴࡸࠦ࠽ࠡࡌࡖࡓࡓ࠴ࡰࡢࡴࡶࡩ࠭ࡨࡳࡵࡣࡦ࡯ࡤࡩࡡࡱࡵࠬࡠࡳࠦࠠࡾࠢࡦࡥࡹࡩࡨࠩࡧࡻ࠭ࠥࢁ࡜࡯ࠢࠣࠤࠥࢃ࡜࡯ࠢࠣࡶࡪࡺࡵࡳࡰࠣࡥࡼࡧࡩࡵࠢ࡬ࡱࡵࡵࡲࡵࡡࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠺࡟ࡣࡵࡷࡥࡨࡱ࠮ࡤࡪࡵࡳࡲ࡯ࡵ࡮࠰ࡦࡳࡳࡴࡥࡤࡶࠫࡿࡡࡴࠠࠡࠢࠣࡻࡸࡋ࡮ࡥࡲࡲ࡭ࡳࡺ࠺ࠡࡢࡺࡷࡸࡀ࠯࠰ࡥࡧࡴ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࡄࡩࡡࡱࡵࡀࠨࢀ࡫࡮ࡤࡱࡧࡩ࡚ࡘࡉࡄࡱࡰࡴࡴࡴࡥ࡯ࡶࠫࡎࡘࡕࡎ࠯ࡵࡷࡶ࡮ࡴࡧࡪࡨࡼࠬࡨࡧࡰࡴࠫࠬࢁࡥ࠲࡜࡯ࠢࠣࠤࠥ࠴࠮࠯࡮ࡤࡹࡳࡩࡨࡐࡲࡷ࡭ࡴࡴࡳ࡝ࡰࠣࠤࢂ࠯࡜࡯ࡿ࡟ࡲ࠴࠰ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤ࠯࠵࡜࡯ࠩਚ")
from ._version import __version__
bstack1l1lll1ll1_opy_ = None
CONFIG = {}
bstack1l111l1111_opy_ = {}
bstack11ll11l11l_opy_ = {}
bstack11lll1ll1l_opy_ = None
bstack11ll1l1l1_opy_ = None
bstack1l1l11l1l_opy_ = None
bstack11ll1111l1_opy_ = -1
bstack1l1llllll1_opy_ = 0
bstack1l1l1lllll_opy_ = bstack11ll11l1ll_opy_
bstack111lll111_opy_ = 1
bstack1l1ll1ll1l_opy_ = False
bstack1llll1lll_opy_ = False
bstack11ll111ll1_opy_ = bstack1l1111l_opy_ (u"ࠫࠬਛ")
bstack111111ll1_opy_ = bstack1l1111l_opy_ (u"ࠬ࠭ਜ")
bstack11l1lll1l_opy_ = False
bstack1ll1111lll_opy_ = True
bstack11l1l1lll_opy_ = bstack1l1111l_opy_ (u"࠭ࠧਝ")
bstack11llll1ll_opy_ = []
bstack11l11l111l_opy_ = bstack1l1111l_opy_ (u"ࠧࠨਞ")
bstack1lllll1ll1_opy_ = False
bstack1l11111l11_opy_ = None
bstack111llll1l1_opy_ = None
bstack111l11111_opy_ = None
bstack1lll1lll1_opy_ = -1
bstack11ll11ll1l_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠨࢀࠪਟ")), bstack1l1111l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩਠ"), bstack1l1111l_opy_ (u"ࠪ࠲ࡷࡵࡢࡰࡶ࠰ࡶࡪࡶ࡯ࡳࡶ࠰࡬ࡪࡲࡰࡦࡴ࠱࡮ࡸࡵ࡮ࠨਡ"))
bstack1l11lllll1_opy_ = 0
bstack111llll1ll_opy_ = 0
bstack11ll1lll1l_opy_ = []
bstack11lllll11l_opy_ = []
bstack11l1lll1l1_opy_ = []
bstack11lll11ll_opy_ = []
bstack1l1ll11ll_opy_ = bstack1l1111l_opy_ (u"ࠫࠬਢ")
bstack11l1llllll_opy_ = bstack1l1111l_opy_ (u"ࠬ࠭ਣ")
bstack11l1ll111_opy_ = False
bstack1lll11lll1_opy_ = False
bstack1l1l11l11_opy_ = {}
bstack1ll1ll111_opy_ = None
bstack1l111l1lll_opy_ = None
bstack1ll1l1l1l1_opy_ = None
bstack1l11l11ll1_opy_ = None
bstack1l1ll1111_opy_ = None
bstack11ll1ll11_opy_ = None
bstack11l1l1l11l_opy_ = None
bstack1lll1ll1l_opy_ = None
bstack1l1l1l1ll_opy_ = None
bstack1111l1lll_opy_ = None
bstack1lll11l11l_opy_ = None
bstack111ll11l1_opy_ = None
bstack1ll1111111_opy_ = None
bstack1ll11ll1ll_opy_ = None
bstack11lllllll_opy_ = None
bstack11lll11l1l_opy_ = None
bstack11lll1llll_opy_ = None
bstack11l1llll11_opy_ = None
bstack11llll1ll1_opy_ = None
bstack1ll1l1lll_opy_ = None
bstack1l11l1ll1_opy_ = None
bstack11l1l11l1_opy_ = None
bstack11111ll11_opy_ = False
bstack111l11l1l_opy_ = bstack1l1111l_opy_ (u"ࠨࠢਤ")
logger = bstack11lll111ll_opy_.get_logger(__name__, bstack1l1l1lllll_opy_)
bstack11l11l11_opy_ = Config.bstack111l1111_opy_()
percy = bstack1111l1ll1_opy_()
bstack1111lll11_opy_ = bstack1lllllllll_opy_()
bstack1l1l11l1ll_opy_ = bstack11l11l1l_opy_()
def bstack1l1lll1111_opy_():
  global CONFIG
  global bstack11l1ll111_opy_
  global bstack11l11l11_opy_
  bstack1llll11l1_opy_ = bstack1ll1ll11ll_opy_(CONFIG)
  if bstack1l11lll11_opy_(CONFIG):
    if (bstack1l1111l_opy_ (u"ࠧࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩਥ") in bstack1llll11l1_opy_ and str(bstack1llll11l1_opy_[bstack1l1111l_opy_ (u"ࠨࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪਦ")]).lower() == bstack1l1111l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧਧ")):
      bstack11l1ll111_opy_ = True
    bstack11l11l11_opy_.bstack1l1l111l11_opy_(bstack1llll11l1_opy_.get(bstack1l1111l_opy_ (u"ࠪࡷࡰ࡯ࡰࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧਨ"), False))
  else:
    bstack11l1ll111_opy_ = True
    bstack11l11l11_opy_.bstack1l1l111l11_opy_(True)
def bstack1l11l1ll1l_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack1ll11llll1_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack11ll1l1ll_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack1l1111l_opy_ (u"ࠦ࠲࠳ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡨࡵ࡮ࡧ࡫ࡪࡪ࡮ࡲࡥࠣ਩") == args[i].lower() or bstack1l1111l_opy_ (u"ࠧ࠳࠭ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰࡰࡩ࡭࡬ࠨਪ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack11l1l1lll_opy_
      bstack11l1l1lll_opy_ += bstack1l1111l_opy_ (u"࠭࠭࠮ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡃࡰࡰࡩ࡭࡬ࡌࡩ࡭ࡧࠣࠫਫ") + path
      return path
  return None
bstack11ll1l111_opy_ = re.compile(bstack1l1111l_opy_ (u"ࡲࠣ࠰࠭ࡃࡡࠪࡻࠩ࠰࠭ࡃ࠮ࢃ࠮ࠫࡁࠥਬ"))
def bstack111ll1lll1_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack11ll1l111_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack1l1111l_opy_ (u"ࠣࠦࡾࠦਭ") + group + bstack1l1111l_opy_ (u"ࠤࢀࠦਮ"), os.environ.get(group))
  return value
def bstack11l1llll1_opy_():
  bstack1l1l1ll111_opy_ = bstack11ll1l1ll_opy_()
  if bstack1l1l1ll111_opy_ and os.path.exists(os.path.abspath(bstack1l1l1ll111_opy_)):
    fileName = bstack1l1l1ll111_opy_
  if bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡆࡓࡓࡌࡉࡈࡡࡉࡍࡑࡋࠧਯ") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡇࡔࡔࡆࡊࡉࡢࡊࡎࡒࡅࠨਰ")])) and not bstack1l1111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡑࡥࡲ࡫ࠧ਱") in locals():
    fileName = os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡉࡏࡏࡈࡌࡋࡤࡌࡉࡍࡇࠪਲ")]
  if bstack1l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡓࡧ࡭ࡦࠩਲ਼") in locals():
    bstack11lll11_opy_ = os.path.abspath(fileName)
  else:
    bstack11lll11_opy_ = bstack1l1111l_opy_ (u"ࠨࠩ਴")
  bstack111lll1111_opy_ = os.getcwd()
  bstack11ll11l111_opy_ = bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡻࡰࡰࠬਵ")
  bstack1l1llll1ll_opy_ = bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡼࡥࡲࡲࠧਸ਼")
  while (not os.path.exists(bstack11lll11_opy_)) and bstack111lll1111_opy_ != bstack1l1111l_opy_ (u"ࠦࠧ਷"):
    bstack11lll11_opy_ = os.path.join(bstack111lll1111_opy_, bstack11ll11l111_opy_)
    if not os.path.exists(bstack11lll11_opy_):
      bstack11lll11_opy_ = os.path.join(bstack111lll1111_opy_, bstack1l1llll1ll_opy_)
    if bstack111lll1111_opy_ != os.path.dirname(bstack111lll1111_opy_):
      bstack111lll1111_opy_ = os.path.dirname(bstack111lll1111_opy_)
    else:
      bstack111lll1111_opy_ = bstack1l1111l_opy_ (u"ࠧࠨਸ")
  if not os.path.exists(bstack11lll11_opy_):
    bstack11ll1l1ll1_opy_(
      bstack111111111_opy_.format(os.getcwd()))
  try:
    with open(bstack11lll11_opy_, bstack1l1111l_opy_ (u"࠭ࡲࠨਹ")) as stream:
      yaml.add_implicit_resolver(bstack1l1111l_opy_ (u"ࠢࠢࡲࡤࡸ࡭࡫ࡸࠣ਺"), bstack11ll1l111_opy_)
      yaml.add_constructor(bstack1l1111l_opy_ (u"ࠣࠣࡳࡥࡹ࡮ࡥࡹࠤ਻"), bstack111ll1lll1_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      return config
  except:
    with open(bstack11lll11_opy_, bstack1l1111l_opy_ (u"ࠩࡵ਼ࠫ")) as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        bstack11ll1l1ll1_opy_(bstack1l111111ll_opy_.format(str(exc)))
def bstack1lll11l111_opy_(config):
  bstack1l1ll11l1_opy_ = bstack11l1l1l1l_opy_(config)
  for option in list(bstack1l1ll11l1_opy_):
    if option.lower() in bstack1lll1111l_opy_ and option != bstack1lll1111l_opy_[option.lower()]:
      bstack1l1ll11l1_opy_[bstack1lll1111l_opy_[option.lower()]] = bstack1l1ll11l1_opy_[option]
      del bstack1l1ll11l1_opy_[option]
  return config
def bstack11l1ll111l_opy_():
  global bstack11ll11l11l_opy_
  for key, bstack1llll111ll_opy_ in bstack1llllll1l1_opy_.items():
    if isinstance(bstack1llll111ll_opy_, list):
      for var in bstack1llll111ll_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack11ll11l11l_opy_[key] = os.environ[var]
          break
    elif bstack1llll111ll_opy_ in os.environ and os.environ[bstack1llll111ll_opy_] and str(os.environ[bstack1llll111ll_opy_]).strip():
      bstack11ll11l11l_opy_[key] = os.environ[bstack1llll111ll_opy_]
  if bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡏࡓࡈࡇࡌࡠࡋࡇࡉࡓ࡚ࡉࡇࡋࡈࡖࠬ਽") in os.environ:
    bstack11ll11l11l_opy_[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨਾ")] = {}
    bstack11ll11l11l_opy_[bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩਿ")][bstack1l1111l_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨੀ")] = os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩੁ")]
def bstack11lll11l11_opy_():
  global bstack1l111l1111_opy_
  global bstack11l1l1lll_opy_
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) and bstack1l1111l_opy_ (u"ࠨ࠯࠰ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫੂ").lower() == val.lower():
      bstack1l111l1111_opy_[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭੃")] = {}
      bstack1l111l1111_opy_[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧ੄")][bstack1l1111l_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭੅")] = sys.argv[idx + 1]
      del sys.argv[idx:idx + 2]
      break
  for key, bstack11ll1l11l_opy_ in bstack1l111l1ll1_opy_.items():
    if isinstance(bstack11ll1l11l_opy_, list):
      for idx, val in enumerate(sys.argv):
        for var in bstack11ll1l11l_opy_:
          if idx < len(sys.argv) and bstack1l1111l_opy_ (u"ࠬ࠳࠭ࠨ੆") + var.lower() == val.lower() and not key in bstack1l111l1111_opy_:
            bstack1l111l1111_opy_[key] = sys.argv[idx + 1]
            bstack11l1l1lll_opy_ += bstack1l1111l_opy_ (u"࠭ࠠ࠮࠯ࠪੇ") + var + bstack1l1111l_opy_ (u"ࠧࠡࠩੈ") + sys.argv[idx + 1]
            del sys.argv[idx:idx + 2]
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx < len(sys.argv) and bstack1l1111l_opy_ (u"ࠨ࠯࠰ࠫ੉") + bstack11ll1l11l_opy_.lower() == val.lower() and not key in bstack1l111l1111_opy_:
          bstack1l111l1111_opy_[key] = sys.argv[idx + 1]
          bstack11l1l1lll_opy_ += bstack1l1111l_opy_ (u"ࠩࠣ࠱࠲࠭੊") + bstack11ll1l11l_opy_ + bstack1l1111l_opy_ (u"ࠪࠤࠬੋ") + sys.argv[idx + 1]
          del sys.argv[idx:idx + 2]
def bstack1l111lll1_opy_(config):
  bstack1l111l1l11_opy_ = config.keys()
  for bstack11l1l1ll1l_opy_, bstack1l1llll11l_opy_ in bstack11lll1111_opy_.items():
    if bstack1l1llll11l_opy_ in bstack1l111l1l11_opy_:
      config[bstack11l1l1ll1l_opy_] = config[bstack1l1llll11l_opy_]
      del config[bstack1l1llll11l_opy_]
  for bstack11l1l1ll1l_opy_, bstack1l1llll11l_opy_ in bstack1ll11lll1l_opy_.items():
    if isinstance(bstack1l1llll11l_opy_, list):
      for bstack11ll1l1111_opy_ in bstack1l1llll11l_opy_:
        if bstack11ll1l1111_opy_ in bstack1l111l1l11_opy_:
          config[bstack11l1l1ll1l_opy_] = config[bstack11ll1l1111_opy_]
          del config[bstack11ll1l1111_opy_]
          break
    elif bstack1l1llll11l_opy_ in bstack1l111l1l11_opy_:
      config[bstack11l1l1ll1l_opy_] = config[bstack1l1llll11l_opy_]
      del config[bstack1l1llll11l_opy_]
  for bstack11ll1l1111_opy_ in list(config):
    for bstack1ll1l1l11_opy_ in bstack1ll111111_opy_:
      if bstack11ll1l1111_opy_.lower() == bstack1ll1l1l11_opy_.lower() and bstack11ll1l1111_opy_ != bstack1ll1l1l11_opy_:
        config[bstack1ll1l1l11_opy_] = config[bstack11ll1l1111_opy_]
        del config[bstack11ll1l1111_opy_]
  bstack1llllll11_opy_ = [{}]
  if not config.get(bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧੌ")):
    config[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ੍")] = [{}]
  bstack1llllll11_opy_ = config[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ੎")]
  for platform in bstack1llllll11_opy_:
    for bstack11ll1l1111_opy_ in list(platform):
      for bstack1ll1l1l11_opy_ in bstack1ll111111_opy_:
        if bstack11ll1l1111_opy_.lower() == bstack1ll1l1l11_opy_.lower() and bstack11ll1l1111_opy_ != bstack1ll1l1l11_opy_:
          platform[bstack1ll1l1l11_opy_] = platform[bstack11ll1l1111_opy_]
          del platform[bstack11ll1l1111_opy_]
  for bstack11l1l1ll1l_opy_, bstack1l1llll11l_opy_ in bstack1ll11lll1l_opy_.items():
    for platform in bstack1llllll11_opy_:
      if isinstance(bstack1l1llll11l_opy_, list):
        for bstack11ll1l1111_opy_ in bstack1l1llll11l_opy_:
          if bstack11ll1l1111_opy_ in platform:
            platform[bstack11l1l1ll1l_opy_] = platform[bstack11ll1l1111_opy_]
            del platform[bstack11ll1l1111_opy_]
            break
      elif bstack1l1llll11l_opy_ in platform:
        platform[bstack11l1l1ll1l_opy_] = platform[bstack1l1llll11l_opy_]
        del platform[bstack1l1llll11l_opy_]
  for bstack1ll1l1111_opy_ in bstack111llll111_opy_:
    if bstack1ll1l1111_opy_ in config:
      if not bstack111llll111_opy_[bstack1ll1l1111_opy_] in config:
        config[bstack111llll111_opy_[bstack1ll1l1111_opy_]] = {}
      config[bstack111llll111_opy_[bstack1ll1l1111_opy_]].update(config[bstack1ll1l1111_opy_])
      del config[bstack1ll1l1111_opy_]
  for platform in bstack1llllll11_opy_:
    for bstack1ll1l1111_opy_ in bstack111llll111_opy_:
      if bstack1ll1l1111_opy_ in list(platform):
        if not bstack111llll111_opy_[bstack1ll1l1111_opy_] in platform:
          platform[bstack111llll111_opy_[bstack1ll1l1111_opy_]] = {}
        platform[bstack111llll111_opy_[bstack1ll1l1111_opy_]].update(platform[bstack1ll1l1111_opy_])
        del platform[bstack1ll1l1111_opy_]
  config = bstack1lll11l111_opy_(config)
  return config
def bstack111lll111l_opy_(config):
  global bstack111111ll1_opy_
  bstack1lllll1l11_opy_ = False
  if bstack1l1111l_opy_ (u"ࠧࡵࡷࡵࡦࡴ࡙ࡣࡢ࡮ࡨࠫ੏") in config and str(config[bstack1l1111l_opy_ (u"ࠨࡶࡸࡶࡧࡵࡓࡤࡣ࡯ࡩࠬ੐")]).lower() != bstack1l1111l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨੑ"):
    if bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ੒") not in config or str(config[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨ੓")]).lower() == bstack1l1111l_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ੔"):
      config[bstack1l1111l_opy_ (u"࠭࡬ࡰࡥࡤࡰࠬ੕")] = False
    else:
      bstack11lll1l1ll_opy_ = bstack1ll1ll1l11_opy_()
      if bstack1l1111l_opy_ (u"ࠧࡪࡵࡗࡶ࡮ࡧ࡬ࡈࡴ࡬ࡨࠬ੖") in bstack11lll1l1ll_opy_:
        if not bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ੗") in config:
          config[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭੘")] = {}
        config[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧਖ਼")][bstack1l1111l_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ਗ਼")] = bstack1l1111l_opy_ (u"ࠬࡧࡴࡴ࠯ࡵࡩࡵ࡫ࡡࡵࡧࡵࠫਜ਼")
        bstack1lllll1l11_opy_ = True
        bstack111111ll1_opy_ = config[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪੜ")].get(bstack1l1111l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ੝"))
  if bstack1l11lll11_opy_(config) and bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬਫ਼") in config and str(config[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭੟")]).lower() != bstack1l1111l_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩ੠") and not bstack1lllll1l11_opy_:
    if not bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨ੡") in config:
      config[bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩ੢")] = {}
    if not config[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ੣")].get(bstack1l1111l_opy_ (u"ࠧࡴ࡭࡬ࡴࡇ࡯࡮ࡢࡴࡼࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡸࡧࡴࡪࡱࡱࠫ੤")) and not bstack1l1111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ੥") in config[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭੦")]:
      bstack1llll111_opy_ = datetime.datetime.now()
      bstack1ll11lll11_opy_ = bstack1llll111_opy_.strftime(bstack1l1111l_opy_ (u"ࠪࠩࡩࡥࠥࡣࡡࠨࡌࠪࡓࠧ੧"))
      hostname = socket.gethostname()
      bstack11111l1ll_opy_ = bstack1l1111l_opy_ (u"ࠫࠬ੨").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack1l1111l_opy_ (u"ࠬࢁࡽࡠࡽࢀࡣࢀࢃࠧ੩").format(bstack1ll11lll11_opy_, hostname, bstack11111l1ll_opy_)
      config[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ੪")][bstack1l1111l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ੫")] = identifier
    bstack111111ll1_opy_ = config[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ੬")].get(bstack1l1111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ੭"))
  return config
def bstack1l1l1l1lll_opy_():
  bstack111lll1ll1_opy_ =  bstack11l11llll1_opy_()[bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠩ੮")]
  return bstack111lll1ll1_opy_ if bstack111lll1ll1_opy_ else -1
def bstack1l1111l111_opy_(bstack111lll1ll1_opy_):
  global CONFIG
  if not bstack1l1111l_opy_ (u"ࠫࠩࢁࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࢂ࠭੯") in CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧੰ")]:
    return
  CONFIG[bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨੱ")] = CONFIG[bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩੲ")].replace(
    bstack1l1111l_opy_ (u"ࠨࠦࡾࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࡿࠪੳ"),
    str(bstack111lll1ll1_opy_)
  )
def bstack11l111lll_opy_():
  global CONFIG
  if not bstack1l1111l_opy_ (u"ࠩࠧࡿࡉࡇࡔࡆࡡࡗࡍࡒࡋࡽࠨੴ") in CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬੵ")]:
    return
  bstack1llll111_opy_ = datetime.datetime.now()
  bstack1ll11lll11_opy_ = bstack1llll111_opy_.strftime(bstack1l1111l_opy_ (u"ࠫࠪࡪ࠭ࠦࡤ࠰ࠩࡍࡀࠥࡎࠩ੶"))
  CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ੷")] = CONFIG[bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ੸")].replace(
    bstack1l1111l_opy_ (u"ࠧࠥࡽࡇࡅ࡙ࡋ࡟ࡕࡋࡐࡉࢂ࠭੹"),
    bstack1ll11lll11_opy_
  )
def bstack1l1ll1lll_opy_():
  global CONFIG
  if bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ੺") in CONFIG and not bool(CONFIG[bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ੻")]):
    del CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ੼")]
    return
  if not bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭੽") in CONFIG:
    CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ੾")] = bstack1l1111l_opy_ (u"࠭ࠣࠥࡽࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࡾࠩ੿")
  if bstack1l1111l_opy_ (u"ࠧࠥࡽࡇࡅ࡙ࡋ࡟ࡕࡋࡐࡉࢂ࠭઀") in CONFIG[bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪઁ")]:
    bstack11l111lll_opy_()
    os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡡࡆࡓࡒࡈࡉࡏࡇࡇࡣࡇ࡛ࡉࡍࡆࡢࡍࡉ࠭ં")] = CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬઃ")]
  if not bstack1l1111l_opy_ (u"ࠫࠩࢁࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࢂ࠭઄") in CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧઅ")]:
    return
  bstack111lll1ll1_opy_ = bstack1l1111l_opy_ (u"࠭ࠧઆ")
  bstack11l1ll1111_opy_ = bstack1l1l1l1lll_opy_()
  if bstack11l1ll1111_opy_ != -1:
    bstack111lll1ll1_opy_ = bstack1l1111l_opy_ (u"ࠧࡄࡋࠣࠫઇ") + str(bstack11l1ll1111_opy_)
  if bstack111lll1ll1_opy_ == bstack1l1111l_opy_ (u"ࠨࠩઈ"):
    bstack1l11ll1ll1_opy_ = bstack1lll1lll1l_opy_(CONFIG[bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬઉ")])
    if bstack1l11ll1ll1_opy_ != -1:
      bstack111lll1ll1_opy_ = str(bstack1l11ll1ll1_opy_)
  if bstack111lll1ll1_opy_:
    bstack1l1111l111_opy_(bstack111lll1ll1_opy_)
    os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡢࡇࡔࡓࡂࡊࡐࡈࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠧઊ")] = CONFIG[bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ઋ")]
def bstack1ll1lllll1_opy_(bstack111l11lll_opy_, bstack1llll1ll11_opy_, path):
  json_data = {
    bstack1l1111l_opy_ (u"ࠬ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩઌ"): bstack1llll1ll11_opy_
  }
  if os.path.exists(path):
    bstack1l1l1l111_opy_ = json.load(open(path, bstack1l1111l_opy_ (u"࠭ࡲࡣࠩઍ")))
  else:
    bstack1l1l1l111_opy_ = {}
  bstack1l1l1l111_opy_[bstack111l11lll_opy_] = json_data
  with open(path, bstack1l1111l_opy_ (u"ࠢࡸ࠭ࠥ઎")) as outfile:
    json.dump(bstack1l1l1l111_opy_, outfile)
def bstack1lll1lll1l_opy_(bstack111l11lll_opy_):
  bstack111l11lll_opy_ = str(bstack111l11lll_opy_)
  bstack1l111ll1l1_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠨࢀࠪએ")), bstack1l1111l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩઐ"))
  try:
    if not os.path.exists(bstack1l111ll1l1_opy_):
      os.makedirs(bstack1l111ll1l1_opy_)
    file_path = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠪࢂࠬઑ")), bstack1l1111l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ઒"), bstack1l1111l_opy_ (u"ࠬ࠴ࡢࡶ࡫࡯ࡨ࠲ࡴࡡ࡮ࡧ࠰ࡧࡦࡩࡨࡦ࠰࡭ࡷࡴࡴࠧઓ"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack1l1111l_opy_ (u"࠭ࡷࠨઔ")):
        pass
      with open(file_path, bstack1l1111l_opy_ (u"ࠢࡸ࠭ࠥક")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack1l1111l_opy_ (u"ࠨࡴࠪખ")) as bstack11l11l1ll_opy_:
      bstack11l11l1ll1_opy_ = json.load(bstack11l11l1ll_opy_)
    if bstack111l11lll_opy_ in bstack11l11l1ll1_opy_:
      bstack1111ll1ll_opy_ = bstack11l11l1ll1_opy_[bstack111l11lll_opy_][bstack1l1111l_opy_ (u"ࠩ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ગ")]
      bstack11l1l1111l_opy_ = int(bstack1111ll1ll_opy_) + 1
      bstack1ll1lllll1_opy_(bstack111l11lll_opy_, bstack11l1l1111l_opy_, file_path)
      return bstack11l1l1111l_opy_
    else:
      bstack1ll1lllll1_opy_(bstack111l11lll_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack1llll11lll_opy_.format(str(e)))
    return -1
def bstack111llll11l_opy_(config):
  if not config[bstack1l1111l_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬઘ")] or not config[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧઙ")]:
    return True
  else:
    return False
def bstack1l11l11ll_opy_(config, index=0):
  global bstack11l1lll1l_opy_
  bstack11l11l1l11_opy_ = {}
  caps = bstack1l1111llll_opy_ + bstack11l111llll_opy_
  if config.get(bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩચ"), False):
    bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"࠭ࡴࡶࡴࡥࡳࡸࡩࡡ࡭ࡧࠪછ")] = True
    bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠧࡵࡷࡵࡦࡴ࡙ࡣࡢ࡮ࡨࡓࡵࡺࡩࡰࡰࡶࠫજ")] = config.get(bstack1l1111l_opy_ (u"ࠨࡶࡸࡶࡧࡵࡓࡤࡣ࡯ࡩࡔࡶࡴࡪࡱࡱࡷࠬઝ"), {})
  if bstack11l1lll1l_opy_:
    caps += bstack1l1111ll1_opy_
  for key in config:
    if key in caps + [bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬઞ")]:
      continue
    bstack11l11l1l11_opy_[key] = config[key]
  if bstack1l1111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ટ") in config:
    for bstack1l1ll1ll11_opy_ in config[bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧઠ")][index]:
      if bstack1l1ll1ll11_opy_ in caps:
        continue
      bstack11l11l1l11_opy_[bstack1l1ll1ll11_opy_] = config[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨડ")][index][bstack1l1ll1ll11_opy_]
  bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"࠭ࡨࡰࡵࡷࡒࡦࡳࡥࠨઢ")] = socket.gethostname()
  if bstack1l1111l_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨણ") in bstack11l11l1l11_opy_:
    del (bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩત")])
  return bstack11l11l1l11_opy_
def bstack1lll1l1lll_opy_(config):
  global bstack11l1lll1l_opy_
  bstack1ll11ll111_opy_ = {}
  caps = bstack11l111llll_opy_
  if bstack11l1lll1l_opy_:
    caps += bstack1l1111ll1_opy_
  for key in caps:
    if key in config:
      bstack1ll11ll111_opy_[key] = config[key]
  return bstack1ll11ll111_opy_
def bstack1lll1l111_opy_(bstack11l11l1l11_opy_, bstack1ll11ll111_opy_):
  bstack1l11llll1l_opy_ = {}
  for key in bstack11l11l1l11_opy_.keys():
    if key in bstack11lll1111_opy_:
      bstack1l11llll1l_opy_[bstack11lll1111_opy_[key]] = bstack11l11l1l11_opy_[key]
    else:
      bstack1l11llll1l_opy_[key] = bstack11l11l1l11_opy_[key]
  for key in bstack1ll11ll111_opy_:
    if key in bstack11lll1111_opy_:
      bstack1l11llll1l_opy_[bstack11lll1111_opy_[key]] = bstack1ll11ll111_opy_[key]
    else:
      bstack1l11llll1l_opy_[key] = bstack1ll11ll111_opy_[key]
  return bstack1l11llll1l_opy_
def bstack1l111ll111_opy_(config, index=0):
  global bstack11l1lll1l_opy_
  caps = {}
  config = copy.deepcopy(config)
  bstack11lllll1l1_opy_ = bstack11ll11ll11_opy_(bstack1l1ll11ll1_opy_, config, logger)
  bstack1ll11ll111_opy_ = bstack1lll1l1lll_opy_(config)
  bstack1l1lll11l_opy_ = bstack11l111llll_opy_
  bstack1l1lll11l_opy_ += bstack1lll1ll1ll_opy_
  bstack1ll11ll111_opy_ = update(bstack1ll11ll111_opy_, bstack11lllll1l1_opy_)
  if bstack11l1lll1l_opy_:
    bstack1l1lll11l_opy_ += bstack1l1111ll1_opy_
  if bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬથ") in config:
    if bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨદ") in config[bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧધ")][index]:
      caps[bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪન")] = config[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ઩")][index][bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬપ")]
    if bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩફ") in config[bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬબ")][index]:
      caps[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫભ")] = str(config[bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧમ")][index][bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ય")])
    bstack11llll1lll_opy_ = bstack11ll11ll11_opy_(bstack1l1ll11ll1_opy_, config[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩર")][index], logger)
    bstack1l1lll11l_opy_ += list(bstack11llll1lll_opy_.keys())
    for bstack111ll1ll1l_opy_ in bstack1l1lll11l_opy_:
      if bstack111ll1ll1l_opy_ in config[bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ઱")][index]:
        if bstack111ll1ll1l_opy_ == bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯࡙ࡩࡷࡹࡩࡰࡰࠪલ"):
          try:
            bstack11llll1lll_opy_[bstack111ll1ll1l_opy_] = str(config[bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬળ")][index][bstack111ll1ll1l_opy_] * 1.0)
          except:
            bstack11llll1lll_opy_[bstack111ll1ll1l_opy_] = str(config[bstack1l1111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭઴")][index][bstack111ll1ll1l_opy_])
        else:
          bstack11llll1lll_opy_[bstack111ll1ll1l_opy_] = config[bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧવ")][index][bstack111ll1ll1l_opy_]
        del (config[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨશ")][index][bstack111ll1ll1l_opy_])
    bstack1ll11ll111_opy_ = update(bstack1ll11ll111_opy_, bstack11llll1lll_opy_)
  bstack11l11l1l11_opy_ = bstack1l11l11ll_opy_(config, index)
  for bstack11ll1l1111_opy_ in bstack11l111llll_opy_ + list(bstack11lllll1l1_opy_.keys()):
    if bstack11ll1l1111_opy_ in bstack11l11l1l11_opy_:
      bstack1ll11ll111_opy_[bstack11ll1l1111_opy_] = bstack11l11l1l11_opy_[bstack11ll1l1111_opy_]
      del (bstack11l11l1l11_opy_[bstack11ll1l1111_opy_])
  if bstack1llll1111_opy_(config):
    bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"࠭ࡵࡴࡧ࡚࠷ࡈ࠭ષ")] = True
    caps.update(bstack1ll11ll111_opy_)
    caps[bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨસ")] = bstack11l11l1l11_opy_
  else:
    bstack11l11l1l11_opy_[bstack1l1111l_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨહ")] = False
    caps.update(bstack1lll1l111_opy_(bstack11l11l1l11_opy_, bstack1ll11ll111_opy_))
    if bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ઺") in caps:
      caps[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ઻")] = caps[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦ઼ࠩ")]
      del (caps[bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪઽ")])
    if bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧા") in caps:
      caps[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠩિ")] = caps[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩી")]
      del (caps[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪુ")])
  return caps
def bstack1ll111111l_opy_():
  global bstack11l11l111l_opy_
  global CONFIG
  if bstack1ll11llll1_opy_() <= version.parse(bstack1l1111l_opy_ (u"ࠪ࠷࠳࠷࠳࠯࠲ࠪૂ")):
    if bstack11l11l111l_opy_ != bstack1l1111l_opy_ (u"ࠫࠬૃ"):
      return bstack1l1111l_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨૄ") + bstack11l11l111l_opy_ + bstack1l1111l_opy_ (u"ࠨ࠺࠹࠲࠲ࡻࡩ࠵ࡨࡶࡤࠥૅ")
    return bstack1lll1111l1_opy_
  if bstack11l11l111l_opy_ != bstack1l1111l_opy_ (u"ࠧࠨ૆"):
    return bstack1l1111l_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥે") + bstack11l11l111l_opy_ + bstack1l1111l_opy_ (u"ࠤ࠲ࡻࡩ࠵ࡨࡶࡤࠥૈ")
  return bstack1ll111l1l_opy_
def bstack11l11l1l1l_opy_(options):
  return hasattr(options, bstack1l1111l_opy_ (u"ࠪࡷࡪࡺ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶࡼࠫૉ"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack11lll1111l_opy_(options, bstack111l1l111_opy_):
  for bstack111l11l11_opy_ in bstack111l1l111_opy_:
    if bstack111l11l11_opy_ in [bstack1l1111l_opy_ (u"ࠫࡦࡸࡧࡴࠩ૊"), bstack1l1111l_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩો")]:
      continue
    if bstack111l11l11_opy_ in options._experimental_options:
      options._experimental_options[bstack111l11l11_opy_] = update(options._experimental_options[bstack111l11l11_opy_],
                                                         bstack111l1l111_opy_[bstack111l11l11_opy_])
    else:
      options.add_experimental_option(bstack111l11l11_opy_, bstack111l1l111_opy_[bstack111l11l11_opy_])
  if bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡶࠫૌ") in bstack111l1l111_opy_:
    for arg in bstack111l1l111_opy_[bstack1l1111l_opy_ (u"ࠧࡢࡴࡪࡷ્ࠬ")]:
      options.add_argument(arg)
    del (bstack111l1l111_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭૎")])
  if bstack1l1111l_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭૏") in bstack111l1l111_opy_:
    for ext in bstack111l1l111_opy_[bstack1l1111l_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧૐ")]:
      options.add_extension(ext)
    del (bstack111l1l111_opy_[bstack1l1111l_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨ૑")])
def bstack1ll1111l11_opy_(options, bstack11ll1lllll_opy_):
  if bstack1l1111l_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫ૒") in bstack11ll1lllll_opy_:
    for bstack11111llll_opy_ in bstack11ll1lllll_opy_[bstack1l1111l_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬ૓")]:
      if bstack11111llll_opy_ in options._preferences:
        options._preferences[bstack11111llll_opy_] = update(options._preferences[bstack11111llll_opy_], bstack11ll1lllll_opy_[bstack1l1111l_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭૔")][bstack11111llll_opy_])
      else:
        options.set_preference(bstack11111llll_opy_, bstack11ll1lllll_opy_[bstack1l1111l_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧ૕")][bstack11111llll_opy_])
  if bstack1l1111l_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ૖") in bstack11ll1lllll_opy_:
    for arg in bstack11ll1lllll_opy_[bstack1l1111l_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ૗")]:
      options.add_argument(arg)
def bstack11l1111ll_opy_(options, bstack1l111l1ll_opy_):
  if bstack1l1111l_opy_ (u"ࠫࡼ࡫ࡢࡷ࡫ࡨࡻࠬ૘") in bstack1l111l1ll_opy_:
    options.use_webview(bool(bstack1l111l1ll_opy_[bstack1l1111l_opy_ (u"ࠬࡽࡥࡣࡸ࡬ࡩࡼ࠭૙")]))
  bstack11lll1111l_opy_(options, bstack1l111l1ll_opy_)
def bstack1lllll111_opy_(options, bstack1llll1l111_opy_):
  for bstack111ll1111_opy_ in bstack1llll1l111_opy_:
    if bstack111ll1111_opy_ in [bstack1l1111l_opy_ (u"࠭ࡴࡦࡥ࡫ࡲࡴࡲ࡯ࡨࡻࡓࡶࡪࡼࡩࡦࡹࠪ૚"), bstack1l1111l_opy_ (u"ࠧࡢࡴࡪࡷࠬ૛")]:
      continue
    options.set_capability(bstack111ll1111_opy_, bstack1llll1l111_opy_[bstack111ll1111_opy_])
  if bstack1l1111l_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭૜") in bstack1llll1l111_opy_:
    for arg in bstack1llll1l111_opy_[bstack1l1111l_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ૝")]:
      options.add_argument(arg)
  if bstack1l1111l_opy_ (u"ࠪࡸࡪࡩࡨ࡯ࡱ࡯ࡳ࡬ࡿࡐࡳࡧࡹ࡭ࡪࡽࠧ૞") in bstack1llll1l111_opy_:
    options.bstack11llll111_opy_(bool(bstack1llll1l111_opy_[bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡣࡩࡰࡲࡰࡴ࡭ࡹࡑࡴࡨࡺ࡮࡫ࡷࠨ૟")]))
def bstack1l1l1lll1_opy_(options, bstack1lll1lllll_opy_):
  for bstack1111111ll_opy_ in bstack1lll1lllll_opy_:
    if bstack1111111ll_opy_ in [bstack1l1111l_opy_ (u"ࠬࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩૠ"), bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡶࠫૡ")]:
      continue
    options._options[bstack1111111ll_opy_] = bstack1lll1lllll_opy_[bstack1111111ll_opy_]
  if bstack1l1111l_opy_ (u"ࠧࡢࡦࡧ࡭ࡹ࡯࡯࡯ࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫૢ") in bstack1lll1lllll_opy_:
    for bstack1l1ll1l111_opy_ in bstack1lll1lllll_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡧࡨ࡮ࡺࡩࡰࡰࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬૣ")]:
      options.bstack1l1ll11lll_opy_(
        bstack1l1ll1l111_opy_, bstack1lll1lllll_opy_[bstack1l1111l_opy_ (u"ࠩࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭૤")][bstack1l1ll1l111_opy_])
  if bstack1l1111l_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ૥") in bstack1lll1lllll_opy_:
    for arg in bstack1lll1lllll_opy_[bstack1l1111l_opy_ (u"ࠫࡦࡸࡧࡴࠩ૦")]:
      options.add_argument(arg)
def bstack1111111l1_opy_(options, caps):
  if not hasattr(options, bstack1l1111l_opy_ (u"ࠬࡑࡅ࡚ࠩ૧")):
    return
  if options.KEY == bstack1l1111l_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫ૨") and options.KEY in caps:
    bstack11lll1111l_opy_(options, caps[bstack1l1111l_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬ૩")])
  elif options.KEY == bstack1l1111l_opy_ (u"ࠨ࡯ࡲࡾ࠿࡬ࡩࡳࡧࡩࡳࡽࡕࡰࡵ࡫ࡲࡲࡸ࠭૪") and options.KEY in caps:
    bstack1ll1111l11_opy_(options, caps[bstack1l1111l_opy_ (u"ࠩࡰࡳࡿࡀࡦࡪࡴࡨࡪࡴࡾࡏࡱࡶ࡬ࡳࡳࡹࠧ૫")])
  elif options.KEY == bstack1l1111l_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫࠱ࡳࡵࡺࡩࡰࡰࡶࠫ૬") and options.KEY in caps:
    bstack1lllll111_opy_(options, caps[bstack1l1111l_opy_ (u"ࠫࡸࡧࡦࡢࡴ࡬࠲ࡴࡶࡴࡪࡱࡱࡷࠬ૭")])
  elif options.KEY == bstack1l1111l_opy_ (u"ࠬࡳࡳ࠻ࡧࡧ࡫ࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭૮") and options.KEY in caps:
    bstack11l1111ll_opy_(options, caps[bstack1l1111l_opy_ (u"࠭࡭ࡴ࠼ࡨࡨ࡬࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧ૯")])
  elif options.KEY == bstack1l1111l_opy_ (u"ࠧࡴࡧ࠽࡭ࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭૰") and options.KEY in caps:
    bstack1l1l1lll1_opy_(options, caps[bstack1l1111l_opy_ (u"ࠨࡵࡨ࠾࡮࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧ૱")])
def bstack11lllll11_opy_(caps):
  global bstack11l1lll1l_opy_
  if isinstance(os.environ.get(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪ૲")), str):
    bstack11l1lll1l_opy_ = eval(os.getenv(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫ૳")))
  if bstack11l1lll1l_opy_:
    if bstack1l11l1ll1l_opy_() < version.parse(bstack1l1111l_opy_ (u"ࠫ࠷࠴࠳࠯࠲ࠪ૴")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack1l1111l_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬ૵")
    if bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫ૶") in caps:
      browser = caps[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ૷")]
    elif bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩ૸") in caps:
      browser = caps[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪૹ")]
    browser = str(browser).lower()
    if browser == bstack1l1111l_opy_ (u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪૺ") or browser == bstack1l1111l_opy_ (u"ࠫ࡮ࡶࡡࡥࠩૻ"):
      browser = bstack1l1111l_opy_ (u"ࠬࡹࡡࡧࡣࡵ࡭ࠬૼ")
    if browser == bstack1l1111l_opy_ (u"࠭ࡳࡢ࡯ࡶࡹࡳ࡭ࠧ૽"):
      browser = bstack1l1111l_opy_ (u"ࠧࡤࡪࡵࡳࡲ࡫ࠧ૾")
    if browser not in [bstack1l1111l_opy_ (u"ࠨࡥ࡫ࡶࡴࡳࡥࠨ૿"), bstack1l1111l_opy_ (u"ࠩࡨࡨ࡬࡫ࠧ଀"), bstack1l1111l_opy_ (u"ࠪ࡭ࡪ࠭ଁ"), bstack1l1111l_opy_ (u"ࠫࡸࡧࡦࡢࡴ࡬ࠫଂ"), bstack1l1111l_opy_ (u"ࠬ࡬ࡩࡳࡧࡩࡳࡽ࠭ଃ")]:
      return None
    try:
      package = bstack1l1111l_opy_ (u"࠭ࡳࡦ࡮ࡨࡲ࡮ࡻ࡭࠯ࡹࡨࡦࡩࡸࡩࡷࡧࡵ࠲ࢀࢃ࠮ࡰࡲࡷ࡭ࡴࡴࡳࠨ଄").format(browser)
      name = bstack1l1111l_opy_ (u"ࠧࡐࡲࡷ࡭ࡴࡴࡳࠨଅ")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack11l11l1l1l_opy_(options):
        return None
      for bstack11ll1l1111_opy_ in caps.keys():
        options.set_capability(bstack11ll1l1111_opy_, caps[bstack11ll1l1111_opy_])
      bstack1111111l1_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack111lll1ll_opy_(options, bstack1l11lllll_opy_):
  if not bstack11l11l1l1l_opy_(options):
    return
  for bstack11ll1l1111_opy_ in bstack1l11lllll_opy_.keys():
    if bstack11ll1l1111_opy_ in bstack1lll1ll1ll_opy_:
      continue
    if bstack11ll1l1111_opy_ in options._caps and type(options._caps[bstack11ll1l1111_opy_]) in [dict, list]:
      options._caps[bstack11ll1l1111_opy_] = update(options._caps[bstack11ll1l1111_opy_], bstack1l11lllll_opy_[bstack11ll1l1111_opy_])
    else:
      options.set_capability(bstack11ll1l1111_opy_, bstack1l11lllll_opy_[bstack11ll1l1111_opy_])
  bstack1111111l1_opy_(options, bstack1l11lllll_opy_)
  if bstack1l1111l_opy_ (u"ࠨ࡯ࡲࡾ࠿ࡪࡥࡣࡷࡪ࡫ࡪࡸࡁࡥࡦࡵࡩࡸࡹࠧଆ") in options._caps:
    if options._caps[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧଇ")] and options._caps[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨଈ")].lower() != bstack1l1111l_opy_ (u"ࠫ࡫࡯ࡲࡦࡨࡲࡼࠬଉ"):
      del options._caps[bstack1l1111l_opy_ (u"ࠬࡳ࡯ࡻ࠼ࡧࡩࡧࡻࡧࡨࡧࡵࡅࡩࡪࡲࡦࡵࡶࠫଊ")]
def bstack11l1lll11l_opy_(proxy_config):
  if bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪଋ") in proxy_config:
    proxy_config[bstack1l1111l_opy_ (u"ࠧࡴࡵ࡯ࡔࡷࡵࡸࡺࠩଌ")] = proxy_config[bstack1l1111l_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬ଍")]
    del (proxy_config[bstack1l1111l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭଎")])
  if bstack1l1111l_opy_ (u"ࠪࡴࡷࡵࡸࡺࡖࡼࡴࡪ࠭ଏ") in proxy_config and proxy_config[bstack1l1111l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠧଐ")].lower() != bstack1l1111l_opy_ (u"ࠬࡪࡩࡳࡧࡦࡸࠬ଑"):
    proxy_config[bstack1l1111l_opy_ (u"࠭ࡰࡳࡱࡻࡽ࡙ࡿࡰࡦࠩ଒")] = bstack1l1111l_opy_ (u"ࠧ࡮ࡣࡱࡹࡦࡲࠧଓ")
  if bstack1l1111l_opy_ (u"ࠨࡲࡵࡳࡽࡿࡁࡶࡶࡲࡧࡴࡴࡦࡪࡩࡘࡶࡱ࠭ଔ") in proxy_config:
    proxy_config[bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡾࡹࡕࡻࡳࡩࠬକ")] = bstack1l1111l_opy_ (u"ࠪࡴࡦࡩࠧଖ")
  return proxy_config
def bstack1lll1l111l_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack1l1111l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࠪଗ") in config:
    return proxy
  config[bstack1l1111l_opy_ (u"ࠬࡶࡲࡰࡺࡼࠫଘ")] = bstack11l1lll11l_opy_(config[bstack1l1111l_opy_ (u"࠭ࡰࡳࡱࡻࡽࠬଙ")])
  if proxy == None:
    proxy = Proxy(config[bstack1l1111l_opy_ (u"ࠧࡱࡴࡲࡼࡾ࠭ଚ")])
  return proxy
def bstack111l111ll_opy_(self):
  global CONFIG
  global bstack111ll11l1_opy_
  try:
    proxy = bstack1ll1llll11_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack1l1111l_opy_ (u"ࠨ࠰ࡳࡥࡨ࠭ଛ")):
        proxies = bstack111lll11l1_opy_(proxy, bstack1ll111111l_opy_())
        if len(proxies) > 0:
          protocol, bstack1l11l111ll_opy_ = proxies.popitem()
          if bstack1l1111l_opy_ (u"ࠤ࠽࠳࠴ࠨଜ") in bstack1l11l111ll_opy_:
            return bstack1l11l111ll_opy_
          else:
            return bstack1l1111l_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦଝ") + bstack1l11l111ll_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack1l1111l_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡱࡴࡲࡼࡾࠦࡵࡳ࡮ࠣ࠾ࠥࢁࡽࠣଞ").format(str(e)))
  return bstack111ll11l1_opy_(self)
def bstack11ll11lll1_opy_():
  global CONFIG
  return bstack1l1llll111_opy_(CONFIG) and bstack11ll1llll_opy_() and bstack1ll11llll1_opy_() >= version.parse(bstack1lll111ll_opy_)
def bstack1l11l11l1l_opy_():
  global CONFIG
  return (bstack1l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨଟ") in CONFIG or bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪଠ") in CONFIG) and bstack111l1111l_opy_()
def bstack11l1l1l1l_opy_(config):
  bstack1l1ll11l1_opy_ = {}
  if bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫଡ") in config:
    bstack1l1ll11l1_opy_ = config[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬଢ")]
  if bstack1l1111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨଣ") in config:
    bstack1l1ll11l1_opy_ = config[bstack1l1111l_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩତ")]
  proxy = bstack1ll1llll11_opy_(config)
  if proxy:
    if proxy.endswith(bstack1l1111l_opy_ (u"ࠫ࠳ࡶࡡࡤࠩଥ")) and os.path.isfile(proxy):
      bstack1l1ll11l1_opy_[bstack1l1111l_opy_ (u"ࠬ࠳ࡰࡢࡥ࠰ࡪ࡮ࡲࡥࠨଦ")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack1l1111l_opy_ (u"࠭࠮ࡱࡣࡦࠫଧ")):
        proxies = bstack1lll11llll_opy_(config, bstack1ll111111l_opy_())
        if len(proxies) > 0:
          protocol, bstack1l11l111ll_opy_ = proxies.popitem()
          if bstack1l1111l_opy_ (u"ࠢ࠻࠱࠲ࠦନ") in bstack1l11l111ll_opy_:
            parsed_url = urlparse(bstack1l11l111ll_opy_)
          else:
            parsed_url = urlparse(protocol + bstack1l1111l_opy_ (u"ࠣ࠼࠲࠳ࠧ଩") + bstack1l11l111ll_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack1l1ll11l1_opy_[bstack1l1111l_opy_ (u"ࠩࡳࡶࡴࡾࡹࡉࡱࡶࡸࠬପ")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack1l1ll11l1_opy_[bstack1l1111l_opy_ (u"ࠪࡴࡷࡵࡸࡺࡒࡲࡶࡹ࠭ଫ")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack1l1ll11l1_opy_[bstack1l1111l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡘࡷࡪࡸࠧବ")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack1l1ll11l1_opy_[bstack1l1111l_opy_ (u"ࠬࡶࡲࡰࡺࡼࡔࡦࡹࡳࠨଭ")] = str(parsed_url.password)
  return bstack1l1ll11l1_opy_
def bstack1ll1ll11ll_opy_(config):
  if bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡇࡴࡴࡴࡦࡺࡷࡓࡵࡺࡩࡰࡰࡶࠫମ") in config:
    return config[bstack1l1111l_opy_ (u"ࠧࡵࡧࡶࡸࡈࡵ࡮ࡵࡧࡻࡸࡔࡶࡴࡪࡱࡱࡷࠬଯ")]
  return {}
def bstack11ll1l11l1_opy_(caps):
  global bstack111111ll1_opy_
  if bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩର") in caps:
    caps[bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪ଱")][bstack1l1111l_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࠩଲ")] = True
    if bstack111111ll1_opy_:
      caps[bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬଳ")][bstack1l1111l_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ଴")] = bstack111111ll1_opy_
  else:
    caps[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࠫଵ")] = True
    if bstack111111ll1_opy_:
      caps[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨଶ")] = bstack111111ll1_opy_
@measure(event_name=EVENTS.bstack1l1111111l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1l11l11111_opy_():
  global CONFIG
  if not bstack1l11lll11_opy_(CONFIG):
    return
  if bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬଷ") in CONFIG and bstack11ll111lll_opy_(CONFIG[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ସ")]):
    if (
      bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧହ") in CONFIG
      and bstack11ll111lll_opy_(CONFIG[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨ଺")].get(bstack1l1111l_opy_ (u"ࠬࡹ࡫ࡪࡲࡅ࡭ࡳࡧࡲࡺࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡶࡥࡹ࡯࡯࡯ࠩ଻")))
    ):
      logger.debug(bstack1l1111l_opy_ (u"ࠨࡌࡰࡥࡤࡰࠥࡨࡩ࡯ࡣࡵࡽࠥࡴ࡯ࡵࠢࡶࡸࡦࡸࡴࡦࡦࠣࡥࡸࠦࡳ࡬࡫ࡳࡆ࡮ࡴࡡࡳࡻࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡷࡦࡺࡩࡰࡰࠣ࡭ࡸࠦࡥ࡯ࡣࡥࡰࡪࡪ଼ࠢ"))
      return
    bstack1l1ll11l1_opy_ = bstack11l1l1l1l_opy_(CONFIG)
    bstack1ll1l11l1l_opy_(CONFIG[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪଽ")], bstack1l1ll11l1_opy_)
def bstack1ll1l11l1l_opy_(key, bstack1l1ll11l1_opy_):
  global bstack1l1lll1ll1_opy_
  logger.info(bstack1lllll1ll_opy_)
  try:
    bstack1l1lll1ll1_opy_ = Local()
    bstack1l1l1ll11l_opy_ = {bstack1l1111l_opy_ (u"ࠨ࡭ࡨࡽࠬା"): key}
    bstack1l1l1ll11l_opy_.update(bstack1l1ll11l1_opy_)
    logger.debug(bstack1l1111lll1_opy_.format(str(bstack1l1l1ll11l_opy_)))
    bstack1l1lll1ll1_opy_.start(**bstack1l1l1ll11l_opy_)
    if bstack1l1lll1ll1_opy_.isRunning():
      logger.info(bstack11l1l111ll_opy_)
  except Exception as e:
    bstack11ll1l1ll1_opy_(bstack1ll11l1lll_opy_.format(str(e)))
def bstack11lll11ll1_opy_():
  global bstack1l1lll1ll1_opy_
  if bstack1l1lll1ll1_opy_.isRunning():
    logger.info(bstack11lll111l_opy_)
    bstack1l1lll1ll1_opy_.stop()
  bstack1l1lll1ll1_opy_ = None
def bstack1ll1l1111l_opy_(bstack1l1111ll11_opy_=[]):
  global CONFIG
  bstack1lll11ll1_opy_ = []
  bstack1l1ll11l11_opy_ = [bstack1l1111l_opy_ (u"ࠩࡲࡷࠬି"), bstack1l1111l_opy_ (u"ࠪࡳࡸ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ୀ"), bstack1l1111l_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࡒࡦࡳࡥࠨୁ"), bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧୂ"), bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫୃ"), bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨୄ")]
  try:
    for err in bstack1l1111ll11_opy_:
      bstack1l111l11l1_opy_ = {}
      for k in bstack1l1ll11l11_opy_:
        val = CONFIG[bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ୅")][int(err[bstack1l1111l_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ୆")])].get(k)
        if val:
          bstack1l111l11l1_opy_[k] = val
      if(err[bstack1l1111l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩେ")] != bstack1l1111l_opy_ (u"ࠫࠬୈ")):
        bstack1l111l11l1_opy_[bstack1l1111l_opy_ (u"ࠬࡺࡥࡴࡶࡶࠫ୉")] = {
          err[bstack1l1111l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ୊")]: err[bstack1l1111l_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ୋ")]
        }
        bstack1lll11ll1_opy_.append(bstack1l111l11l1_opy_)
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡪࡴࡸ࡭ࡢࡶࡷ࡭ࡳ࡭ࠠࡥࡣࡷࡥࠥ࡬࡯ࡳࠢࡨࡺࡪࡴࡴ࠻ࠢࠪୌ") + str(e))
  finally:
    return bstack1lll11ll1_opy_
def bstack11111l11l_opy_(file_name):
  bstack1ll111l111_opy_ = []
  try:
    bstack1ll1llllll_opy_ = os.path.join(tempfile.gettempdir(), file_name)
    if os.path.exists(bstack1ll1llllll_opy_):
      with open(bstack1ll1llllll_opy_) as f:
        bstack1111llll1_opy_ = json.load(f)
        bstack1ll111l111_opy_ = bstack1111llll1_opy_
      os.remove(bstack1ll1llllll_opy_)
    return bstack1ll111l111_opy_
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡫࡯࡮ࡥ࡫ࡱ࡫ࠥ࡫ࡲࡳࡱࡵࠤࡱ࡯ࡳࡵ࠼୍ࠣࠫ") + str(e))
    return bstack1ll111l111_opy_
def bstack11lll1lll_opy_():
  global bstack111l11l1l_opy_
  global bstack11llll1ll_opy_
  global bstack11ll1lll1l_opy_
  global bstack11lllll11l_opy_
  global bstack11l1lll1l1_opy_
  global bstack11l1llllll_opy_
  global CONFIG
  bstack11ll11l1l_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠪࡊࡗࡇࡍࡆ࡙ࡒࡖࡐࡥࡕࡔࡇࡇࠫ୎"))
  if bstack11ll11l1l_opy_ in [bstack1l1111l_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪ୏"), bstack1l1111l_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫ୐")]:
    bstack1l1lllll1l_opy_()
  percy.shutdown()
  if bstack111l11l1l_opy_:
    logger.warning(bstack1l1ll1l1l1_opy_.format(str(bstack111l11l1l_opy_)))
  else:
    try:
      bstack1l1l1l111_opy_ = bstack1ll11l1ll_opy_(bstack1l1111l_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ୑"), logger)
      if bstack1l1l1l111_opy_.get(bstack1l1111l_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬ୒")) and bstack1l1l1l111_opy_.get(bstack1l1111l_opy_ (u"ࠨࡰࡸࡨ࡬࡫࡟࡭ࡱࡦࡥࡱ࠭୓")).get(bstack1l1111l_opy_ (u"ࠩ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠫ୔")):
        logger.warning(bstack1l1ll1l1l1_opy_.format(str(bstack1l1l1l111_opy_[bstack1l1111l_opy_ (u"ࠪࡲࡺࡪࡧࡦࡡ࡯ࡳࡨࡧ࡬ࠨ୕")][bstack1l1111l_opy_ (u"ࠫ࡭ࡵࡳࡵࡰࡤࡱࡪ࠭ୖ")])))
    except Exception as e:
      logger.error(e)
  logger.info(bstack1l1ll1l11_opy_)
  global bstack1l1lll1ll1_opy_
  if bstack1l1lll1ll1_opy_:
    bstack11lll11ll1_opy_()
  try:
    for driver in bstack11llll1ll_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack11l1111lll_opy_)
  if bstack11l1llllll_opy_ == bstack1l1111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫୗ"):
    bstack11l1lll1l1_opy_ = bstack11111l11l_opy_(bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸࡤ࡫ࡲࡳࡱࡵࡣࡱ࡯ࡳࡵ࠰࡭ࡷࡴࡴࠧ୘"))
  if bstack11l1llllll_opy_ == bstack1l1111l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ୙") and len(bstack11lllll11l_opy_) == 0:
    bstack11lllll11l_opy_ = bstack11111l11l_opy_(bstack1l1111l_opy_ (u"ࠨࡲࡺࡣࡵࡿࡴࡦࡵࡷࡣࡪࡸࡲࡰࡴࡢࡰ࡮ࡹࡴ࠯࡬ࡶࡳࡳ࠭୚"))
    if len(bstack11lllll11l_opy_) == 0:
      bstack11lllll11l_opy_ = bstack11111l11l_opy_(bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡳࡴࡵࡥࡥࡳࡴࡲࡶࡤࡲࡩࡴࡶ࠱࡮ࡸࡵ࡮ࠨ୛"))
  bstack1l111lll1l_opy_ = bstack1l1111l_opy_ (u"ࠪࠫଡ଼")
  if len(bstack11ll1lll1l_opy_) > 0:
    bstack1l111lll1l_opy_ = bstack1ll1l1111l_opy_(bstack11ll1lll1l_opy_)
  elif len(bstack11lllll11l_opy_) > 0:
    bstack1l111lll1l_opy_ = bstack1ll1l1111l_opy_(bstack11lllll11l_opy_)
  elif len(bstack11l1lll1l1_opy_) > 0:
    bstack1l111lll1l_opy_ = bstack1ll1l1111l_opy_(bstack11l1lll1l1_opy_)
  elif len(bstack11lll11ll_opy_) > 0:
    bstack1l111lll1l_opy_ = bstack1ll1l1111l_opy_(bstack11lll11ll_opy_)
  if bool(bstack1l111lll1l_opy_):
    bstack1ll111lll_opy_(bstack1l111lll1l_opy_)
  else:
    bstack1ll111lll_opy_()
  bstack11l1lll11_opy_(bstack11lll1lll1_opy_, logger)
  bstack11lll111ll_opy_.bstack11lllll1_opy_(CONFIG)
  if len(bstack11l1lll1l1_opy_) > 0:
    sys.exit(len(bstack11l1lll1l1_opy_))
def bstack1l1111l11l_opy_(bstack1l1l11ll1_opy_, frame):
  global bstack11l11l11_opy_
  logger.error(bstack1llllll111_opy_)
  bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠫࡸࡪ࡫ࡌ࡫࡯ࡰࡓࡵࠧଢ଼"), bstack1l1l11ll1_opy_)
  if hasattr(signal, bstack1l1111l_opy_ (u"࡙ࠬࡩࡨࡰࡤࡰࡸ࠭୞")):
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"࠭ࡳࡥ࡭ࡎ࡭ࡱࡲࡓࡪࡩࡱࡥࡱ࠭ୟ"), signal.Signals(bstack1l1l11ll1_opy_).name)
  else:
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠧࡴࡦ࡮ࡏ࡮ࡲ࡬ࡔ࡫ࡪࡲࡦࡲࠧୠ"), bstack1l1111l_opy_ (u"ࠨࡕࡌࡋ࡚ࡔࡋࡏࡑ࡚ࡒࠬୡ"))
  bstack11ll11l1l_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠩࡉࡖࡆࡓࡅࡘࡑࡕࡏࡤ࡛ࡓࡆࡆࠪୢ"))
  if bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪୣ"):
    bstack1l11l1l1_opy_.stop(bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠫࡸࡪ࡫ࡌ࡫࡯ࡰࡘ࡯ࡧ࡯ࡣ࡯ࠫ୤")))
  bstack11lll1lll_opy_()
  sys.exit(1)
def bstack11ll1l1ll1_opy_(err):
  logger.critical(bstack1l11l111l_opy_.format(str(err)))
  bstack1ll111lll_opy_(bstack1l11l111l_opy_.format(str(err)), True)
  atexit.unregister(bstack11lll1lll_opy_)
  bstack1l1lllll1l_opy_()
  sys.exit(1)
def bstack11ll1ll1l1_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack1ll111lll_opy_(message, True)
  atexit.unregister(bstack11lll1lll_opy_)
  bstack1l1lllll1l_opy_()
  sys.exit(1)
def bstack1ll11111l_opy_():
  global CONFIG
  global bstack1l111l1111_opy_
  global bstack11ll11l11l_opy_
  global bstack1ll1111lll_opy_
  CONFIG = bstack11l1llll1_opy_()
  load_dotenv(CONFIG.get(bstack1l1111l_opy_ (u"ࠬ࡫࡮ࡷࡈ࡬ࡰࡪ࠭୥")))
  bstack11l1ll111l_opy_()
  bstack11lll11l11_opy_()
  CONFIG = bstack1l111lll1_opy_(CONFIG)
  update(CONFIG, bstack11ll11l11l_opy_)
  update(CONFIG, bstack1l111l1111_opy_)
  CONFIG = bstack111lll111l_opy_(CONFIG)
  bstack1ll1111lll_opy_ = bstack1l11lll11_opy_(CONFIG)
  os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩ୦")] = bstack1ll1111lll_opy_.__str__()
  bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ୧"), bstack1ll1111lll_opy_)
  if (bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ୨") in CONFIG and bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ୩") in bstack1l111l1111_opy_) or (
          bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭୪") in CONFIG and bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧ୫") not in bstack11ll11l11l_opy_):
    if os.getenv(bstack1l1111l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡤࡉࡏࡎࡄࡌࡒࡊࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩ୬")):
      CONFIG[bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ୭")] = os.getenv(bstack1l1111l_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑ࡟ࡄࡑࡐࡆࡎࡔࡅࡅࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠫ୮"))
    else:
      bstack1l1ll1lll_opy_()
  elif (bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ୯") not in CONFIG and bstack1l1111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ୰") in CONFIG) or (
          bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ୱ") in bstack11ll11l11l_opy_ and bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧ୲") not in bstack1l111l1111_opy_):
    del (CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ୳")])
  if bstack111llll11l_opy_(CONFIG):
    bstack11ll1l1ll1_opy_(bstack1ll11ll11_opy_)
  Config.bstack111l1111_opy_().set_property(bstack1l1111l_opy_ (u"ࠨࡵࡴࡧࡵࡒࡦࡳࡥࠣ୴"), CONFIG[bstack1l1111l_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩ୵")])
  bstack11l111ll1l_opy_()
  bstack1l1lll1ll_opy_()
  if bstack11l1lll1l_opy_:
    CONFIG[bstack1l1111l_opy_ (u"ࠨࡣࡳࡴࠬ୶")] = bstack1l11l1llll_opy_(CONFIG)
    logger.info(bstack1ll111ll1_opy_.format(CONFIG[bstack1l1111l_opy_ (u"ࠩࡤࡴࡵ࠭୷")]))
  if not bstack1ll1111lll_opy_:
    CONFIG[bstack1l1111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭୸")] = [{}]
def bstack111111l11_opy_(config, bstack1l11ll1ll_opy_):
  global CONFIG
  global bstack11l1lll1l_opy_
  CONFIG = config
  bstack11l1lll1l_opy_ = bstack1l11ll1ll_opy_
def bstack1l1lll1ll_opy_():
  global CONFIG
  global bstack11l1lll1l_opy_
  if bstack1l1111l_opy_ (u"ࠫࡦࡶࡰࠨ୹") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1lll1llll_opy_)
    bstack11l1lll1l_opy_ = True
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫ୺"), True)
def bstack1l11l1llll_opy_(config):
  bstack11ll11l11_opy_ = bstack1l1111l_opy_ (u"࠭ࠧ୻")
  app = config[bstack1l1111l_opy_ (u"ࠧࡢࡲࡳࠫ୼")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack1llll11ll1_opy_:
      if os.path.exists(app):
        bstack11ll11l11_opy_ = bstack11l1111l1l_opy_(config, app)
      elif bstack1l1111l1ll_opy_(app):
        bstack11ll11l11_opy_ = app
      else:
        bstack11ll1l1ll1_opy_(bstack1ll11ll1l1_opy_.format(app))
    else:
      if bstack1l1111l1ll_opy_(app):
        bstack11ll11l11_opy_ = app
      elif os.path.exists(app):
        bstack11ll11l11_opy_ = bstack11l1111l1l_opy_(app)
      else:
        bstack11ll1l1ll1_opy_(bstack1l1l1lll1l_opy_)
  else:
    if len(app) > 2:
      bstack11ll1l1ll1_opy_(bstack1lllll111l_opy_)
    elif len(app) == 2:
      if bstack1l1111l_opy_ (u"ࠨࡲࡤࡸ࡭࠭୽") in app and bstack1l1111l_opy_ (u"ࠩࡦࡹࡸࡺ࡯࡮ࡡ࡬ࡨࠬ୾") in app:
        if os.path.exists(app[bstack1l1111l_opy_ (u"ࠪࡴࡦࡺࡨࠨ୿")]):
          bstack11ll11l11_opy_ = bstack11l1111l1l_opy_(config, app[bstack1l1111l_opy_ (u"ࠫࡵࡧࡴࡩࠩ஀")], app[bstack1l1111l_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱࡤ࡯ࡤࠨ஁")])
        else:
          bstack11ll1l1ll1_opy_(bstack1ll11ll1l1_opy_.format(app))
      else:
        bstack11ll1l1ll1_opy_(bstack1lllll111l_opy_)
    else:
      for key in app:
        if key in bstack1lll1l11l1_opy_:
          if key == bstack1l1111l_opy_ (u"࠭ࡰࡢࡶ࡫ࠫஂ"):
            if os.path.exists(app[key]):
              bstack11ll11l11_opy_ = bstack11l1111l1l_opy_(config, app[key])
            else:
              bstack11ll1l1ll1_opy_(bstack1ll11ll1l1_opy_.format(app))
          else:
            bstack11ll11l11_opy_ = app[key]
        else:
          bstack11ll1l1ll1_opy_(bstack11lllll1l_opy_)
  return bstack11ll11l11_opy_
def bstack1l1111l1ll_opy_(bstack11ll11l11_opy_):
  import re
  bstack1l111l111_opy_ = re.compile(bstack1l1111l_opy_ (u"ࡲࠣࡠ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡢ࡟࠯࡞࠰ࡡ࠯ࠪࠢஃ"))
  bstack1ll1ll1ll1_opy_ = re.compile(bstack1l1111l_opy_ (u"ࡳࠤࡡ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡜ࡠ࠰࡟࠱ࡢ࠰࠯࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡠࡤ࠴࡜࠮࡟࠭ࠨࠧ஄"))
  if bstack1l1111l_opy_ (u"ࠩࡥࡷ࠿࠵࠯ࠨஅ") in bstack11ll11l11_opy_ or re.fullmatch(bstack1l111l111_opy_, bstack11ll11l11_opy_) or re.fullmatch(bstack1ll1ll1ll1_opy_, bstack11ll11l11_opy_):
    return True
  else:
    return False
@measure(event_name=EVENTS.bstack11ll1l1lll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11l1111l1l_opy_(config, path, bstack111llllll1_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack1l1111l_opy_ (u"ࠪࡶࡧ࠭ஆ")).read()).hexdigest()
  bstack1111ll1l1_opy_ = bstack1l11111111_opy_(md5_hash)
  bstack11ll11l11_opy_ = None
  if bstack1111ll1l1_opy_:
    logger.info(bstack1l11ll111l_opy_.format(bstack1111ll1l1_opy_, md5_hash))
    return bstack1111ll1l1_opy_
  multipart_data = MultipartEncoder(
    fields={
      bstack1l1111l_opy_ (u"ࠫ࡫࡯࡬ࡦࠩஇ"): (os.path.basename(path), open(os.path.abspath(path), bstack1l1111l_opy_ (u"ࠬࡸࡢࠨஈ")), bstack1l1111l_opy_ (u"࠭ࡴࡦࡺࡷ࠳ࡵࡲࡡࡪࡰࠪஉ")),
      bstack1l1111l_opy_ (u"ࠧࡤࡷࡶࡸࡴࡳ࡟ࡪࡦࠪஊ"): bstack111llllll1_opy_
    }
  )
  response = requests.post(bstack1l1ll1ll1_opy_, data=multipart_data,
                           headers={bstack1l1111l_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ஋"): multipart_data.content_type},
                           auth=(config[bstack1l1111l_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ஌")], config[bstack1l1111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭஍")]))
  try:
    res = json.loads(response.text)
    bstack11ll11l11_opy_ = res[bstack1l1111l_opy_ (u"ࠫࡦࡶࡰࡠࡷࡵࡰࠬஎ")]
    logger.info(bstack1lll11l1l_opy_.format(bstack11ll11l11_opy_))
    bstack1ll1l1llll_opy_(md5_hash, bstack11ll11l11_opy_)
  except ValueError as err:
    bstack11ll1l1ll1_opy_(bstack1ll1l111l1_opy_.format(str(err)))
  return bstack11ll11l11_opy_
def bstack11l111ll1l_opy_(framework_name=None, args=None):
  global CONFIG
  global bstack111lll111_opy_
  bstack11111111_opy_ = 1
  bstack1l1ll1llll_opy_ = 1
  if bstack1l1111l_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬஏ") in CONFIG:
    bstack1l1ll1llll_opy_ = CONFIG[bstack1l1111l_opy_ (u"࠭ࡰࡢࡴࡤࡰࡱ࡫࡬ࡴࡒࡨࡶࡕࡲࡡࡵࡨࡲࡶࡲ࠭ஐ")]
  else:
    bstack1l1ll1llll_opy_ = bstack1llllll11l_opy_(framework_name, args) or 1
  if bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ஑") in CONFIG:
    bstack11111111_opy_ = len(CONFIG[bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫஒ")])
  bstack111lll111_opy_ = int(bstack1l1ll1llll_opy_) * int(bstack11111111_opy_)
def bstack1llllll11l_opy_(framework_name, args):
  if framework_name == bstack1lll1l1l1l_opy_ and args and bstack1l1111l_opy_ (u"ࠩ࠰࠱ࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠧஓ") in args:
      bstack1ll111ll11_opy_ = args.index(bstack1l1111l_opy_ (u"ࠪ࠱࠲ࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠨஔ"))
      return int(args[bstack1ll111ll11_opy_ + 1]) or 1
  return 1
def bstack1l11111111_opy_(md5_hash):
  bstack11llll11l_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠫࢃ࠭க")), bstack1l1111l_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ஖"), bstack1l1111l_opy_ (u"࠭ࡡࡱࡲࡘࡴࡱࡵࡡࡥࡏࡇ࠹ࡍࡧࡳࡩ࠰࡭ࡷࡴࡴࠧ஗"))
  if os.path.exists(bstack11llll11l_opy_):
    bstack1l1l1111l1_opy_ = json.load(open(bstack11llll11l_opy_, bstack1l1111l_opy_ (u"ࠧࡳࡤࠪ஘")))
    if md5_hash in bstack1l1l1111l1_opy_:
      bstack1ll11111l1_opy_ = bstack1l1l1111l1_opy_[md5_hash]
      bstack1l1l1111l_opy_ = datetime.datetime.now()
      bstack11llllllll_opy_ = datetime.datetime.strptime(bstack1ll11111l1_opy_[bstack1l1111l_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫங")], bstack1l1111l_opy_ (u"ࠩࠨࡨ࠴ࠫ࡭࠰ࠧ࡜ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ச"))
      if (bstack1l1l1111l_opy_ - bstack11llllllll_opy_).days > 30:
        return None
      elif version.parse(str(__version__)) > version.parse(bstack1ll11111l1_opy_[bstack1l1111l_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ஛")]):
        return None
      return bstack1ll11111l1_opy_[bstack1l1111l_opy_ (u"ࠫ࡮ࡪࠧஜ")]
  else:
    return None
def bstack1ll1l1llll_opy_(md5_hash, bstack11ll11l11_opy_):
  bstack1l111ll1l1_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠬࢄࠧ஝")), bstack1l1111l_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ஞ"))
  if not os.path.exists(bstack1l111ll1l1_opy_):
    os.makedirs(bstack1l111ll1l1_opy_)
  bstack11llll11l_opy_ = os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠧࡿࠩட")), bstack1l1111l_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨ஠"), bstack1l1111l_opy_ (u"ࠩࡤࡴࡵ࡛ࡰ࡭ࡱࡤࡨࡒࡊ࠵ࡉࡣࡶ࡬࠳ࡰࡳࡰࡰࠪ஡"))
  bstack1lll1llll1_opy_ = {
    bstack1l1111l_opy_ (u"ࠪ࡭ࡩ࠭஢"): bstack11ll11l11_opy_,
    bstack1l1111l_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧண"): datetime.datetime.strftime(datetime.datetime.now(), bstack1l1111l_opy_ (u"ࠬࠫࡤ࠰ࠧࡰ࠳ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩத")),
    bstack1l1111l_opy_ (u"࠭ࡳࡥ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠫ஥"): str(__version__)
  }
  if os.path.exists(bstack11llll11l_opy_):
    bstack1l1l1111l1_opy_ = json.load(open(bstack11llll11l_opy_, bstack1l1111l_opy_ (u"ࠧࡳࡤࠪ஦")))
  else:
    bstack1l1l1111l1_opy_ = {}
  bstack1l1l1111l1_opy_[md5_hash] = bstack1lll1llll1_opy_
  with open(bstack11llll11l_opy_, bstack1l1111l_opy_ (u"ࠣࡹ࠮ࠦ஧")) as outfile:
    json.dump(bstack1l1l1111l1_opy_, outfile)
def bstack111ll1l11_opy_(self):
  return
def bstack1l1l11ll11_opy_(self):
  return
def bstack1llll111l1_opy_(self):
  global bstack1ll1111111_opy_
  bstack1ll1111111_opy_(self)
def bstack11l1l1l11_opy_():
  global bstack111l11111_opy_
  bstack111l11111_opy_ = True
@measure(event_name=EVENTS.bstack111l1ll11_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1l11l11_opy_(self):
  global bstack11ll111ll1_opy_
  global bstack11lll1ll1l_opy_
  global bstack1l111l1lll_opy_
  try:
    if bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩந") in bstack11ll111ll1_opy_ and self.session_id != None and bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠪࡸࡪࡹࡴࡔࡶࡤࡸࡺࡹࠧன"), bstack1l1111l_opy_ (u"ࠫࠬப")) != bstack1l1111l_opy_ (u"ࠬࡹ࡫ࡪࡲࡳࡩࡩ࠭஫"):
      bstack11ll11lll_opy_ = bstack1l1111l_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭஬") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack1l1111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ஭")
      if bstack11ll11lll_opy_ == bstack1l1111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨம"):
        bstack1ll1lll11l_opy_(logger)
      if self != None:
        bstack11ll1111ll_opy_(self, bstack11ll11lll_opy_, bstack1l1111l_opy_ (u"ࠩ࠯ࠤࠬய").join(threading.current_thread().bstackTestErrorMessages))
    threading.current_thread().testStatus = bstack1l1111l_opy_ (u"ࠪࠫர")
    if bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫற") in bstack11ll111ll1_opy_ and getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫல"), None):
      bstack11l11111_opy_.bstack1111l1ll_opy_(self, bstack1l1l11l11_opy_, logger, wait=True)
    if bstack1l1111l_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ள") in bstack11ll111ll1_opy_:
      if not threading.currentThread().behave_test_status:
        bstack11ll1111ll_opy_(self, bstack1l1111l_opy_ (u"ࠢࡱࡣࡶࡷࡪࡪࠢழ"))
      bstack1ll1l1lll1_opy_.bstack1l1111lll_opy_(self)
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡸࡪ࡬ࡰࡪࠦ࡭ࡢࡴ࡮࡭ࡳ࡭ࠠࡴࡶࡤࡸࡺࡹ࠺ࠡࠤவ") + str(e))
  bstack1l111l1lll_opy_(self)
  self.session_id = None
def bstack1llll1l11_opy_(self, *args, **kwargs):
  try:
    from selenium.webdriver.remote.remote_connection import RemoteConnection
    from bstack_utils.helper import bstack111l1l11l_opy_
    global bstack11ll111ll1_opy_
    command_executor = kwargs.get(bstack1l1111l_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡢࡩࡽ࡫ࡣࡶࡶࡲࡶࠬஶ"), bstack1l1111l_opy_ (u"ࠪࠫஷ"))
    bstack11l1111l11_opy_ = False
    if type(command_executor) == str and bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳࠧஸ") in command_executor:
      bstack11l1111l11_opy_ = True
    elif isinstance(command_executor, RemoteConnection) and bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭ࠨஹ") in str(getattr(command_executor, bstack1l1111l_opy_ (u"࠭࡟ࡶࡴ࡯ࠫ஺"), bstack1l1111l_opy_ (u"ࠧࠨ஻"))):
      bstack11l1111l11_opy_ = True
    else:
      return bstack1ll1ll111_opy_(self, *args, **kwargs)
    if bstack11l1111l11_opy_:
      bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1ll11l1l_opy_(CONFIG, bstack11ll111ll1_opy_)
      if kwargs.get(bstack1l1111l_opy_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࡴࠩ஼")):
        kwargs[bstack1l1111l_opy_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡵࠪ஽")] = bstack111l1l11l_opy_(kwargs[bstack1l1111l_opy_ (u"ࠪࡳࡵࡺࡩࡰࡰࡶࠫா")], bstack11ll111ll1_opy_, bstack111lll1l11_opy_)
      elif kwargs.get(bstack1l1111l_opy_ (u"ࠫࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫி")):
        kwargs[bstack1l1111l_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬீ")] = bstack111l1l11l_opy_(kwargs[bstack1l1111l_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ு")], bstack11ll111ll1_opy_, bstack111lll1l11_opy_)
  except Exception as e:
    logger.error(bstack1l1111l_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡷࡩࡧࡱࠤࡵࡸ࡯ࡤࡧࡶࡷ࡮ࡴࡧࠡࡕࡇࡏࠥࡩࡡࡱࡵ࠽ࠤࢀࢃࠢூ").format(str(e)))
  return bstack1ll1ll111_opy_(self, *args, **kwargs)
@measure(event_name=EVENTS.bstack11ll11111l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1ll1lll_opy_(self, command_executor=bstack1l1111l_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠹࠺࠴࠵ࠤ௃"), *args, **kwargs):
  bstack11l1lllll_opy_ = bstack1llll1l11_opy_(self, command_executor=command_executor, *args, **kwargs)
  if not bstack1l11l1ll_opy_.on():
    return bstack11l1lllll_opy_
  try:
    logger.debug(bstack1l1111l_opy_ (u"ࠩࡆࡳࡲࡳࡡ࡯ࡦࠣࡉࡽ࡫ࡣࡶࡶࡲࡶࠥࡽࡨࡦࡰࠣࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡩࡴࠢࡩࡥࡱࡹࡥࠡ࠯ࠣࡿࢂ࠭௄").format(str(command_executor)))
    logger.debug(bstack1l1111l_opy_ (u"ࠪࡌࡺࡨࠠࡖࡔࡏࠤ࡮ࡹࠠ࠮ࠢࡾࢁࠬ௅").format(str(command_executor._url)))
    from selenium.webdriver.remote.remote_connection import RemoteConnection
    if isinstance(command_executor, RemoteConnection) and bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳࠧெ") in command_executor._url:
      bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ே"), True)
  except:
    pass
  if (isinstance(command_executor, str) and bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮ࠩை") in command_executor):
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ௉"), True)
  threading.current_thread().bstackSessionDriver = self
  bstack111111l1l_opy_ = getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡕࡧࡶࡸࡒ࡫ࡴࡢࠩொ"), None)
  if bstack1l1111l_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩோ") in bstack11ll111ll1_opy_ or bstack1l1111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩௌ") in bstack11ll111ll1_opy_:
    bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(self)
  if bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷ்ࠫ") in bstack11ll111ll1_opy_ and bstack111111l1l_opy_ and bstack111111l1l_opy_.get(bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ௎"), bstack1l1111l_opy_ (u"࠭ࠧ௏")) == bstack1l1111l_opy_ (u"ࠧࡱࡧࡱࡨ࡮ࡴࡧࠨௐ"):
    bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(self)
  return bstack11l1lllll_opy_
def bstack1111l1l1l_opy_(args):
  return bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳࠩ௑") in str(args)
def bstack1ll11ll1l_opy_(self, driver_command, *args, **kwargs):
  global bstack1ll1l1lll_opy_
  global bstack11111ll11_opy_
  bstack11llll11ll_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠩ࡬ࡷࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭௒"), None) and bstack1l111ll1_opy_(
          threading.current_thread(), bstack1l1111l_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ௓"), None)
  bstack11l111lll1_opy_ = getattr(self, bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡅ࠶࠷ࡹࡔࡪࡲࡹࡱࡪࡓࡤࡣࡱࠫ௔"), None) != None and getattr(self, bstack1l1111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡆ࠷࠱ࡺࡕ࡫ࡳࡺࡲࡤࡔࡥࡤࡲࠬ௕"), None) == True
  if not bstack11111ll11_opy_ and bstack1ll1111lll_opy_ and bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭௖") in CONFIG and CONFIG[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧௗ")] == True and bstack1l1llll1l1_opy_.bstack1l1l1ll11_opy_(driver_command) and (bstack11l111lll1_opy_ or bstack11llll11ll_opy_) and not bstack1111l1l1l_opy_(args):
    try:
      bstack11111ll11_opy_ = True
      logger.debug(bstack1l1111l_opy_ (u"ࠨࡒࡨࡶ࡫ࡵࡲ࡮࡫ࡱ࡫ࠥࡹࡣࡢࡰࠣࡪࡴࡸࠠࡼࡿࠪ௘").format(driver_command))
      logger.debug(perform_scan(self, driver_command=driver_command))
    except Exception as err:
      logger.debug(bstack1l1111l_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡶࡥࡳࡨࡲࡶࡲࠦࡳࡤࡣࡱࠤࢀࢃࠧ௙").format(str(err)))
    bstack11111ll11_opy_ = False
  response = bstack1ll1l1lll_opy_(self, driver_command, *args, **kwargs)
  if (bstack1l1111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௚") in str(bstack11ll111ll1_opy_).lower() or bstack1l1111l_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨࠫ௛") in str(bstack11ll111ll1_opy_).lower()) and bstack1l11l1ll_opy_.on():
    try:
      if driver_command == bstack1l1111l_opy_ (u"ࠬࡹࡣࡳࡧࡨࡲࡸ࡮࡯ࡵࠩ௜"):
        bstack1l11l1l1_opy_.bstack1l1l1l1l11_opy_({
            bstack1l1111l_opy_ (u"࠭ࡩ࡮ࡣࡪࡩࠬ௝"): response[bstack1l1111l_opy_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭௞")],
            bstack1l1111l_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ௟"): bstack1l11l1l1_opy_.current_test_uuid() if bstack1l11l1l1_opy_.current_test_uuid() else bstack1l11l1ll_opy_.current_hook_uuid()
        })
    except:
      pass
  return response
@measure(event_name=EVENTS.bstack11l1llll1l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1lll1l1111_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None, *args, **kwargs):
  global CONFIG
  global bstack11lll1ll1l_opy_
  global bstack11ll1111l1_opy_
  global bstack1l1l11l1l_opy_
  global bstack1l1ll1ll1l_opy_
  global bstack1llll1lll_opy_
  global bstack11ll111ll1_opy_
  global bstack1ll1ll111_opy_
  global bstack11llll1ll_opy_
  global bstack1lll1lll1_opy_
  global bstack1l1l11l11_opy_
  CONFIG[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫ௠")] = str(bstack11ll111ll1_opy_) + str(__version__)
  bstack11l1lll111_opy_ = os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨ௡")]
  bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1ll11l1l_opy_(CONFIG, bstack11ll111ll1_opy_)
  CONFIG[bstack1l1111l_opy_ (u"ࠫࡹ࡫ࡳࡵࡪࡸࡦࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧ௢")] = bstack11l1lll111_opy_
  CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡔࡷࡵࡤࡶࡥࡷࡑࡦࡶࠧ௣")] = bstack111lll1l11_opy_
  command_executor = bstack1ll111111l_opy_()
  logger.debug(bstack1l1l1l11ll_opy_.format(command_executor))
  proxy = bstack1lll1l111l_opy_(CONFIG, proxy)
  bstack1l1l1l111l_opy_ = 0 if bstack11ll1111l1_opy_ < 0 else bstack11ll1111l1_opy_
  try:
    if bstack1l1ll1ll1l_opy_ is True:
      bstack1l1l1l111l_opy_ = int(multiprocessing.current_process().name)
    elif bstack1llll1lll_opy_ is True:
      bstack1l1l1l111l_opy_ = int(threading.current_thread().name)
  except:
    bstack1l1l1l111l_opy_ = 0
  bstack1l11lllll_opy_ = bstack1l111ll111_opy_(CONFIG, bstack1l1l1l111l_opy_)
  logger.debug(bstack11l1l1ll11_opy_.format(str(bstack1l11lllll_opy_)))
  if bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ௤") in CONFIG and bstack11ll111lll_opy_(CONFIG[bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ௥")]):
    bstack11ll1l11l1_opy_(bstack1l11lllll_opy_)
  if bstack1111ll11_opy_.bstack111ll111l_opy_(CONFIG, bstack1l1l1l111l_opy_) and bstack1111ll11_opy_.bstack1lll11111_opy_(bstack1l11lllll_opy_, options, desired_capabilities):
    threading.current_thread().a11yPlatform = True
    bstack1111ll11_opy_.set_capabilities(bstack1l11lllll_opy_, CONFIG)
  if desired_capabilities:
    bstack111l1llll_opy_ = bstack1l111lll1_opy_(desired_capabilities)
    bstack111l1llll_opy_[bstack1l1111l_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨ௦")] = bstack1llll1111_opy_(CONFIG)
    bstack11l11lll1_opy_ = bstack1l111ll111_opy_(bstack111l1llll_opy_)
    if bstack11l11lll1_opy_:
      bstack1l11lllll_opy_ = update(bstack11l11lll1_opy_, bstack1l11lllll_opy_)
    desired_capabilities = None
  if options:
    bstack111lll1ll_opy_(options, bstack1l11lllll_opy_)
  if not options:
    options = bstack11lllll11_opy_(bstack1l11lllll_opy_)
  bstack1l1l11l11_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ௧"))[bstack1l1l1l111l_opy_]
  if proxy and bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠪ࠸࠳࠷࠰࠯࠲ࠪ௨")):
    options.proxy(proxy)
  if options and bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠫ࠸࠴࠸࠯࠲ࠪ௩")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack1ll11llll1_opy_() < version.parse(bstack1l1111l_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫ௪")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack1l11lllll_opy_)
  logger.info(bstack1ll111l11l_opy_)
  bstack1ll1111ll1_opy_.end(EVENTS.bstack11llll1l1l_opy_.value, EVENTS.bstack11llll1l1l_opy_.value + bstack1l1111l_opy_ (u"ࠨ࠺ࡴࡶࡤࡶࡹࠨ௫"), EVENTS.bstack11llll1l1l_opy_.value + bstack1l1111l_opy_ (u"ࠢ࠻ࡧࡱࡨࠧ௬"), status=True, failure=None, test_name=bstack1l1l11l1l_opy_)
  if bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠨ࠶࠱࠵࠵࠴࠰ࠨ௭")):
    bstack1ll1ll111_opy_(self, command_executor=command_executor,
              options=options, keep_alive=keep_alive, file_detector=file_detector, *args, **kwargs)
  elif bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠩ࠶࠲࠽࠴࠰ࠨ௮")):
    bstack1ll1ll111_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities, options=options,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠪ࠶࠳࠻࠳࠯࠲ࠪ௯")):
    bstack1ll1ll111_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  else:
    bstack1ll1ll111_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive)
  try:
    bstack111lllll1l_opy_ = bstack1l1111l_opy_ (u"ࠫࠬ௰")
    if bstack1ll11llll1_opy_() >= version.parse(bstack1l1111l_opy_ (u"ࠬ࠺࠮࠱࠰࠳ࡦ࠶࠭௱")):
      bstack111lllll1l_opy_ = self.caps.get(bstack1l1111l_opy_ (u"ࠨ࡯ࡱࡶ࡬ࡱࡦࡲࡈࡶࡤࡘࡶࡱࠨ௲"))
    else:
      bstack111lllll1l_opy_ = self.capabilities.get(bstack1l1111l_opy_ (u"ࠢࡰࡲࡷ࡭ࡲࡧ࡬ࡉࡷࡥ࡙ࡷࡲࠢ௳"))
    if bstack111lllll1l_opy_:
      bstack11l1ll1ll_opy_(bstack111lllll1l_opy_)
      if bstack1ll11llll1_opy_() <= version.parse(bstack1l1111l_opy_ (u"ࠨ࠵࠱࠵࠸࠴࠰ࠨ௴")):
        self.command_executor._url = bstack1l1111l_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥ௵") + bstack11l11l111l_opy_ + bstack1l1111l_opy_ (u"ࠥ࠾࠽࠶࠯ࡸࡦ࠲࡬ࡺࡨࠢ௶")
      else:
        self.command_executor._url = bstack1l1111l_opy_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࠨ௷") + bstack111lllll1l_opy_ + bstack1l1111l_opy_ (u"ࠧ࠵ࡷࡥ࠱࡫ࡹࡧࠨ௸")
      logger.debug(bstack1l1111l1l1_opy_.format(bstack111lllll1l_opy_))
    else:
      logger.debug(bstack11lll11lll_opy_.format(bstack1l1111l_opy_ (u"ࠨࡏࡱࡶ࡬ࡱࡦࡲࠠࡉࡷࡥࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠢ௹")))
  except Exception as e:
    logger.debug(bstack11lll11lll_opy_.format(e))
  if bstack1l1111l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭௺") in bstack11ll111ll1_opy_:
    bstack1l11lll1l_opy_(bstack11ll1111l1_opy_, bstack1lll1lll1_opy_)
  bstack11lll1ll1l_opy_ = self.session_id
  if bstack1l1111l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ௻") in bstack11ll111ll1_opy_ or bstack1l1111l_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ௼") in bstack11ll111ll1_opy_ or bstack1l1111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௽") in bstack11ll111ll1_opy_:
    threading.current_thread().bstackSessionId = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
  bstack111111l1l_opy_ = getattr(threading.current_thread(), bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡘࡪࡹࡴࡎࡧࡷࡥࠬ௾"), None)
  if bstack1l1111l_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬ௿") in bstack11ll111ll1_opy_ or bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬఀ") in bstack11ll111ll1_opy_:
    bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(self)
  if bstack1l1111l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧఁ") in bstack11ll111ll1_opy_ and bstack111111l1l_opy_ and bstack111111l1l_opy_.get(bstack1l1111l_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨం"), bstack1l1111l_opy_ (u"ࠩࠪః")) == bstack1l1111l_opy_ (u"ࠪࡴࡪࡴࡤࡪࡰࡪࠫఄ"):
    bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(self)
  bstack11llll1ll_opy_.append(self)
  if bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧఅ") in CONFIG and bstack1l1111l_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪఆ") in CONFIG[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩఇ")][bstack1l1l1l111l_opy_]:
    bstack1l1l11l1l_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪఈ")][bstack1l1l1l111l_opy_][bstack1l1111l_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ఉ")]
  logger.debug(bstack11llll1l11_opy_.format(bstack11lll1ll1l_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    from browserstack_sdk.__init__ import bstack11111l111_opy_
    def bstack1llll1111l_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack1lllll1ll1_opy_
      if(bstack1l1111l_opy_ (u"ࠤ࡬ࡲࡩ࡫ࡸ࠯࡬ࡶࠦఊ") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠪࢂࠬఋ")), bstack1l1111l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫఌ"), bstack1l1111l_opy_ (u"ࠬ࠴ࡳࡦࡵࡶ࡭ࡴࡴࡩࡥࡵ࠱ࡸࡽࡺࠧ఍")), bstack1l1111l_opy_ (u"࠭ࡷࠨఎ")) as fp:
          fp.write(bstack1l1111l_opy_ (u"ࠢࠣఏ"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack1l1111l_opy_ (u"ࠣ࡫ࡱࡨࡪࡾ࡟ࡣࡵࡷࡥࡨࡱ࠮࡫ࡵࠥఐ")))):
          with open(args[1], bstack1l1111l_opy_ (u"ࠩࡵࠫ఑")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack1l1111l_opy_ (u"ࠪࡥࡸࡿ࡮ࡤࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡤࡴࡥࡸࡒࡤ࡫ࡪ࠮ࡣࡰࡰࡷࡩࡽࡺࠬࠡࡲࡤ࡫ࡪࠦ࠽ࠡࡸࡲ࡭ࡩࠦ࠰ࠪࠩఒ") in line), None)
            if index is not None:
                lines.insert(index+2, bstack1l111llll_opy_)
            if bstack1l1111l_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨఓ") in CONFIG and str(CONFIG[bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩఔ")]).lower() != bstack1l1111l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬక"):
                bstack1l1111l1l_opy_ = bstack11111l111_opy_()
                bstack1l11ll1l11_opy_ = bstack1l1111l_opy_ (u"ࠧࠨࠩࠍ࠳࠯ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠣ࠮࠴ࠐࡣࡰࡰࡶࡸࠥࡨࡳࡵࡣࡦ࡯ࡤࡶࡡࡵࡪࠣࡁࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࡟ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡰࡪࡴࡧࡵࡪࠣ࠱ࠥ࠹࡝࠼ࠌࡦࡳࡳࡹࡴࠡࡤࡶࡸࡦࡩ࡫ࡠࡥࡤࡴࡸࠦ࠽ࠡࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࡛ࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠳ࡠ࠿ࠏࡩ࡯࡯ࡵࡷࠤࡵࡥࡩ࡯ࡦࡨࡼࠥࡃࠠࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻࡡࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺ࠳ࡲࡥ࡯ࡩࡷ࡬ࠥ࠳ࠠ࠳࡟࠾ࠎࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸࠣࡁࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡸࡲࡩࡤࡧࠫ࠴࠱ࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺ࠳ࡲࡥ࡯ࡩࡷ࡬ࠥ࠳ࠠ࠴ࠫ࠾ࠎࡨࡵ࡮ࡴࡶࠣ࡭ࡲࡶ࡯ࡳࡶࡢࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺ࠴ࡠࡤࡶࡸࡦࡩ࡫ࠡ࠿ࠣࡶࡪࡷࡵࡪࡴࡨࠬࠧࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠤࠬ࠿ࠏ࡯࡭ࡱࡱࡵࡸࡤࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵ࠶ࡢࡦࡸࡺࡡࡤ࡭࠱ࡧ࡭ࡸ࡯࡮࡫ࡸࡱ࠳ࡲࡡࡶࡰࡦ࡬ࠥࡃࠠࡢࡵࡼࡲࡨࠦࠨ࡭ࡣࡸࡲࡨ࡮ࡏࡱࡶ࡬ࡳࡳࡹࠩࠡ࠿ࡁࠤࢀࢁࠊࠡࠢ࡯ࡩࡹࠦࡣࡢࡲࡶ࠿ࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍࠤࠥࡺࡲࡺࠢࡾࡿࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠎࠥࠦࠠࠡࡥࡤࡴࡸࠦ࠽ࠡࡌࡖࡓࡓ࠴ࡰࡢࡴࡶࡩ࠭ࡨࡳࡵࡣࡦ࡯ࡤࡩࡡࡱࡵࠬ࠿ࠏࠦࠠࡾࡿࠣࡧࡦࡺࡣࡩࠢࠫࡩࡽ࠯ࠠࡼࡽࠍࠤࠥࠦࠠࡤࡱࡱࡷࡴࡲࡥ࠯ࡧࡵࡶࡴࡸࠨࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡵࡧࡲࡴࡧࠣࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴ࠼ࠥ࠰ࠥ࡫ࡸࠪ࠽ࠍࠤࠥࢃࡽࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠊࠡࠢࡵࡩࡹࡻࡲ࡯ࠢࡤࡻࡦ࡯ࡴࠡ࡫ࡰࡴࡴࡸࡴࡠࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸ࠹ࡥࡢࡴࡶࡤࡧࡰ࠴ࡣࡩࡴࡲࡱ࡮ࡻ࡭࠯ࡥࡲࡲࡳ࡫ࡣࡵࠪࡾࡿࠏࠦࠠࠡࠢࡺࡷࡊࡴࡤࡱࡱ࡬ࡲࡹࡀࠠࠨࡽࡦࡨࡵ࡛ࡲ࡭ࡿࠪࠤ࠰ࠦࡥ࡯ࡥࡲࡨࡪ࡛ࡒࡊࡅࡲࡱࡵࡵ࡮ࡦࡰࡷࠬࡏ࡙ࡏࡏ࠰ࡶࡸࡷ࡯࡮ࡨ࡫ࡩࡽ࠭ࡩࡡࡱࡵࠬ࠭࠱ࠐࠠࠡࠢࠣ࠲࠳࠴࡬ࡢࡷࡱࡧ࡭ࡕࡰࡵ࡫ࡲࡲࡸࠐࠠࠡࡿࢀ࠭ࡀࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍࢁࢂࡁࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍ࠳࠯ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠣ࠮࠴ࠐࠧࠨࠩఖ").format(bstack1l1111l1l_opy_=bstack1l1111l1l_opy_)
            lines.insert(1, bstack1l11ll1l11_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack1l1111l_opy_ (u"ࠣ࡫ࡱࡨࡪࡾ࡟ࡣࡵࡷࡥࡨࡱ࠮࡫ࡵࠥగ")), bstack1l1111l_opy_ (u"ࠩࡺࠫఘ")) as bstack1lllll1111_opy_:
              bstack1lllll1111_opy_.writelines(lines)
        CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡕࡇࡏࠬఙ")] = str(bstack11ll111ll1_opy_) + str(__version__)
        bstack11l1lll111_opy_ = os.environ[bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩచ")]
        bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1ll11l1l_opy_(CONFIG, bstack11ll111ll1_opy_)
        CONFIG[bstack1l1111l_opy_ (u"ࠬࡺࡥࡴࡶ࡫ࡹࡧࡈࡵࡪ࡮ࡧ࡙ࡺ࡯ࡤࠨఛ")] = bstack11l1lll111_opy_
        CONFIG[bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡕࡸ࡯ࡥࡷࡦࡸࡒࡧࡰࠨజ")] = bstack111lll1l11_opy_
        bstack1l1l1l111l_opy_ = 0 if bstack11ll1111l1_opy_ < 0 else bstack11ll1111l1_opy_
        try:
          if bstack1l1ll1ll1l_opy_ is True:
            bstack1l1l1l111l_opy_ = int(multiprocessing.current_process().name)
          elif bstack1llll1lll_opy_ is True:
            bstack1l1l1l111l_opy_ = int(threading.current_thread().name)
        except:
          bstack1l1l1l111l_opy_ = 0
        CONFIG[bstack1l1111l_opy_ (u"ࠢࡶࡵࡨ࡛࠸ࡉࠢఝ")] = False
        CONFIG[bstack1l1111l_opy_ (u"ࠣ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢఞ")] = True
        bstack1l11lllll_opy_ = bstack1l111ll111_opy_(CONFIG, bstack1l1l1l111l_opy_)
        logger.debug(bstack11l1l1ll11_opy_.format(str(bstack1l11lllll_opy_)))
        if CONFIG.get(bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ట")):
          bstack11ll1l11l1_opy_(bstack1l11lllll_opy_)
        if bstack1l1111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ఠ") in CONFIG and bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩడ") in CONFIG[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨఢ")][bstack1l1l1l111l_opy_]:
          bstack1l1l11l1l_opy_ = CONFIG[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩణ")][bstack1l1l1l111l_opy_][bstack1l1111l_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬత")]
        args.append(os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"ࠨࢀࠪథ")), bstack1l1111l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩద"), bstack1l1111l_opy_ (u"ࠪ࠲ࡸ࡫ࡳࡴ࡫ࡲࡲ࡮ࡪࡳ࠯ࡶࡻࡸࠬధ")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack1l11lllll_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack1l1111l_opy_ (u"ࠦ࡮ࡴࡤࡦࡺࡢࡦࡸࡺࡡࡤ࡭࠱࡮ࡸࠨన"))
      bstack1lllll1ll1_opy_ = True
      return bstack11lllllll_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack11ll111l1l_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack11ll1111l1_opy_
    global bstack1l1l11l1l_opy_
    global bstack1l1ll1ll1l_opy_
    global bstack1llll1lll_opy_
    global bstack11ll111ll1_opy_
    CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧ఩")] = str(bstack11ll111ll1_opy_) + str(__version__)
    bstack11l1lll111_opy_ = os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡕࡖࡋࡇࠫప")]
    bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1ll11l1l_opy_(CONFIG, bstack11ll111ll1_opy_)
    CONFIG[bstack1l1111l_opy_ (u"ࠧࡵࡧࡶࡸ࡭ࡻࡢࡃࡷ࡬ࡰࡩ࡛ࡵࡪࡦࠪఫ")] = bstack11l1lll111_opy_
    CONFIG[bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡐࡳࡱࡧࡹࡨࡺࡍࡢࡲࠪబ")] = bstack111lll1l11_opy_
    bstack1l1l1l111l_opy_ = 0 if bstack11ll1111l1_opy_ < 0 else bstack11ll1111l1_opy_
    try:
      if bstack1l1ll1ll1l_opy_ is True:
        bstack1l1l1l111l_opy_ = int(multiprocessing.current_process().name)
      elif bstack1llll1lll_opy_ is True:
        bstack1l1l1l111l_opy_ = int(threading.current_thread().name)
    except:
      bstack1l1l1l111l_opy_ = 0
    CONFIG[bstack1l1111l_opy_ (u"ࠤ࡬ࡷࡕࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠣభ")] = True
    bstack1l11lllll_opy_ = bstack1l111ll111_opy_(CONFIG, bstack1l1l1l111l_opy_)
    logger.debug(bstack11l1l1ll11_opy_.format(str(bstack1l11lllll_opy_)))
    if CONFIG.get(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧమ")):
      bstack11ll1l11l1_opy_(bstack1l11lllll_opy_)
    if bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧయ") in CONFIG and bstack1l1111l_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪర") in CONFIG[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩఱ")][bstack1l1l1l111l_opy_]:
      bstack1l1l11l1l_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪల")][bstack1l1l1l111l_opy_][bstack1l1111l_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ళ")]
    import urllib
    import json
    if bstack1l1111l_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭ఴ") in CONFIG and str(CONFIG[bstack1l1111l_opy_ (u"ࠪࡸࡺࡸࡢࡰࡕࡦࡥࡱ࡫ࠧవ")]).lower() != bstack1l1111l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪశ"):
        bstack1ll1llll1_opy_ = bstack11111l111_opy_()
        bstack1l1111l1l_opy_ = bstack1ll1llll1_opy_ + urllib.parse.quote(json.dumps(bstack1l11lllll_opy_))
    else:
        bstack1l1111l1l_opy_ = bstack1l1111l_opy_ (u"ࠬࡽࡳࡴ࠼࠲࠳ࡨࡪࡰ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࡀࡥࡤࡴࡸࡃࠧష") + urllib.parse.quote(json.dumps(bstack1l11lllll_opy_))
    browser = self.connect(bstack1l1111l1l_opy_)
    return browser
except Exception as e:
    pass
def bstack11lllll1ll_opy_():
    global bstack1lllll1ll1_opy_
    global bstack11ll111ll1_opy_
    global CONFIG
    try:
        from playwright._impl._browser_type import BrowserType
        from bstack_utils.helper import bstack1l11111ll_opy_
        global bstack11l11l11_opy_
        if not bstack1ll1111lll_opy_:
          global bstack11l1l11l1_opy_
          if not bstack11l1l11l1_opy_:
            from bstack_utils.helper import bstack111lll11l_opy_, bstack1l1l1l11l1_opy_, bstack1l11111lll_opy_
            bstack11l1l11l1_opy_ = bstack111lll11l_opy_()
            bstack1l1l1l11l1_opy_(bstack11ll111ll1_opy_)
            bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1ll11l1l_opy_(CONFIG, bstack11ll111ll1_opy_)
            bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠨࡐࡍࡃ࡜࡛ࡗࡏࡇࡉࡖࡢࡔࡗࡕࡄࡖࡅࡗࡣࡒࡇࡐࠣస"), bstack111lll1l11_opy_)
          BrowserType.connect = bstack1l11111ll_opy_
          return
        BrowserType.launch = bstack11ll111l1l_opy_
        bstack1lllll1ll1_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack1llll1111l_opy_
      bstack1lllll1ll1_opy_ = True
    except Exception as e:
      pass
def bstack1l11l1l1l1_opy_(context, bstack11lll1l11l_opy_):
  try:
    context.page.evaluate(bstack1l1111l_opy_ (u"ࠢࡠࠢࡀࡂࠥࢁࡽࠣహ"), bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡴࡡ࡮ࡧࠥ࠾ࠬ఺")+ json.dumps(bstack11lll1l11l_opy_) + bstack1l1111l_opy_ (u"ࠤࢀࢁࠧ఻"))
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠥࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡳࡦࡵࡶ࡭ࡴࡴࠠ࡯ࡣࡰࡩࠥࢁࡽ఼ࠣ"), e)
def bstack11ll1lll1_opy_(context, message, level):
  try:
    context.page.evaluate(bstack1l1111l_opy_ (u"ࠦࡤࠦ࠽࠿ࠢࡾࢁࠧఽ"), bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪా") + json.dumps(message) + bstack1l1111l_opy_ (u"࠭ࠬࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠩి") + json.dumps(level) + bstack1l1111l_opy_ (u"ࠧࡾࡿࠪీ"))
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠣࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡦࡴ࡮ࡰࡶࡤࡸ࡮ࡵ࡮ࠡࡽࢀࠦు"), e)
@measure(event_name=EVENTS.bstack11l11lllll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1ll1l1l_opy_(self, url):
  global bstack1ll11ll1ll_opy_
  try:
    bstack111l1lll1_opy_(url)
  except Exception as err:
    logger.debug(bstack1l11l1lll1_opy_.format(str(err)))
  try:
    bstack1ll11ll1ll_opy_(self, url)
  except Exception as e:
    try:
      parsed_error = str(e)
      if any(err_msg in parsed_error for err_msg in bstack11111lll1_opy_):
        bstack111l1lll1_opy_(url, True)
    except Exception as err:
      logger.debug(bstack1l11l1lll1_opy_.format(str(err)))
    raise e
def bstack1lll11lll_opy_(self):
  global bstack111llll1l1_opy_
  bstack111llll1l1_opy_ = self
  return
def bstack1l111l11ll_opy_(self):
  global bstack1l11111l11_opy_
  bstack1l11111l11_opy_ = self
  return
def bstack1111lll1l_opy_(test_name, bstack1l1111111_opy_):
  global CONFIG
  if percy.bstack1l1ll1l11l_opy_() == bstack1l1111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢూ"):
    bstack111ll1ll11_opy_ = os.path.relpath(bstack1l1111111_opy_, start=os.getcwd())
    suite_name, _ = os.path.splitext(bstack111ll1ll11_opy_)
    bstack1ll1l1ll1l_opy_ = suite_name + bstack1l1111l_opy_ (u"ࠥ࠱ࠧృ") + test_name
    threading.current_thread().percySessionName = bstack1ll1l1ll1l_opy_
def bstack1llll11111_opy_(self, test, *args, **kwargs):
  global bstack1ll1l1l1l1_opy_
  test_name = None
  bstack1l1111111_opy_ = None
  if test:
    test_name = str(test.name)
    bstack1l1111111_opy_ = str(test.source)
  bstack1111lll1l_opy_(test_name, bstack1l1111111_opy_)
  bstack1ll1l1l1l1_opy_(self, test, *args, **kwargs)
@measure(event_name=EVENTS.bstack1ll111l1ll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1l1l1ll1l1_opy_(driver, bstack1ll1l1ll1l_opy_):
  if not bstack11l1ll111_opy_ and bstack1ll1l1ll1l_opy_:
      bstack1l111l1l1_opy_ = {
          bstack1l1111l_opy_ (u"ࠫࡦࡩࡴࡪࡱࡱࠫౄ"): bstack1l1111l_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭౅"),
          bstack1l1111l_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩె"): {
              bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬే"): bstack1ll1l1ll1l_opy_
          }
      }
      bstack1l1l1l1111_opy_ = bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭ై").format(json.dumps(bstack1l111l1l1_opy_))
      driver.execute_script(bstack1l1l1l1111_opy_)
  if bstack11ll1l1l1_opy_:
      bstack1l1ll1111l_opy_ = {
          bstack1l1111l_opy_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ౉"): bstack1l1111l_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬొ"),
          bstack1l1111l_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧో"): {
              bstack1l1111l_opy_ (u"ࠬࡪࡡࡵࡣࠪౌ"): bstack1ll1l1ll1l_opy_ + bstack1l1111l_opy_ (u"࠭ࠠࡱࡣࡶࡷࡪࡪࠡࠨ్"),
              bstack1l1111l_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭౎"): bstack1l1111l_opy_ (u"ࠨ࡫ࡱࡪࡴ࠭౏")
          }
      }
      if bstack11ll1l1l1_opy_.status == bstack1l1111l_opy_ (u"ࠩࡓࡅࡘ࡙ࠧ౐"):
          bstack111lll1l1_opy_ = bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨ౑").format(json.dumps(bstack1l1ll1111l_opy_))
          driver.execute_script(bstack111lll1l1_opy_)
          bstack11ll1111ll_opy_(driver, bstack1l1111l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫ౒"))
      elif bstack11ll1l1l1_opy_.status == bstack1l1111l_opy_ (u"ࠬࡌࡁࡊࡎࠪ౓"):
          reason = bstack1l1111l_opy_ (u"ࠨࠢ౔")
          bstack1l11111ll1_opy_ = bstack1ll1l1ll1l_opy_ + bstack1l1111l_opy_ (u"ࠧࠡࡨࡤ࡭ࡱ࡫ࡤࠨౕ")
          if bstack11ll1l1l1_opy_.message:
              reason = str(bstack11ll1l1l1_opy_.message)
              bstack1l11111ll1_opy_ = bstack1l11111ll1_opy_ + bstack1l1111l_opy_ (u"ࠨࠢࡺ࡭ࡹ࡮ࠠࡦࡴࡵࡳࡷࡀࠠࠨౖ") + reason
          bstack1l1ll1111l_opy_[bstack1l1111l_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ౗")] = {
              bstack1l1111l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩౘ"): bstack1l1111l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪౙ"),
              bstack1l1111l_opy_ (u"ࠬࡪࡡࡵࡣࠪౚ"): bstack1l11111ll1_opy_
          }
          bstack111lll1l1_opy_ = bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠫ౛").format(json.dumps(bstack1l1ll1111l_opy_))
          driver.execute_script(bstack111lll1l1_opy_)
          bstack11ll1111ll_opy_(driver, bstack1l1111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ౜"), reason)
          bstack11l1l11ll_opy_(reason, str(bstack11ll1l1l1_opy_), str(bstack11ll1111l1_opy_), logger)
@measure(event_name=EVENTS.bstack11l11ll1l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1lll1l1ll_opy_(driver, test):
  if percy.bstack1l1ll1l11l_opy_() == bstack1l1111l_opy_ (u"ࠣࡶࡵࡹࡪࠨౝ") and percy.bstack111lll11ll_opy_() == bstack1l1111l_opy_ (u"ࠤࡷࡩࡸࡺࡣࡢࡵࡨࠦ౞"):
      bstack111l1ll1l_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠪࡴࡪࡸࡣࡺࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭౟"), None)
      bstack1ll1111l1l_opy_(driver, bstack111l1ll1l_opy_, test)
  if bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠫ࡮ࡹࡁ࠲࠳ࡼࡘࡪࡹࡴࠨౠ"), None) and bstack1l111ll1_opy_(
          threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫౡ"), None):
      logger.info(bstack1l1111l_opy_ (u"ࠨࡁࡶࡶࡲࡱࡦࡺࡥࠡࡶࡨࡷࡹࠦࡣࡢࡵࡨࠤࡪࡾࡥࡤࡷࡷ࡭ࡴࡴࠠࡩࡣࡶࠤࡪࡴࡤࡦࡦ࠱ࠤࡕࡸ࡯ࡤࡧࡶࡷ࡮ࡴࡧࠡࡨࡲࡶࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡺࡥࡴࡶ࡬ࡲ࡬ࠦࡩࡴࠢࡸࡲࡩ࡫ࡲࡸࡣࡼ࠲ࠥࠨౢ"))
      bstack1111ll11_opy_.bstack111llll1_opy_(driver, name=test.name, path=test.source)
def bstack1ll1111ll_opy_(test, bstack1ll1l1ll1l_opy_):
    try:
      data = {}
      if test:
        data[bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬౣ")] = bstack1ll1l1ll1l_opy_
      if bstack11ll1l1l1_opy_:
        if bstack11ll1l1l1_opy_.status == bstack1l1111l_opy_ (u"ࠨࡒࡄࡗࡘ࠭౤"):
          data[bstack1l1111l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ౥")] = bstack1l1111l_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪ౦")
        elif bstack11ll1l1l1_opy_.status == bstack1l1111l_opy_ (u"ࠫࡋࡇࡉࡍࠩ౧"):
          data[bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ౨")] = bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭౩")
          if bstack11ll1l1l1_opy_.message:
            data[bstack1l1111l_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ౪")] = str(bstack11ll1l1l1_opy_.message)
      user = CONFIG[bstack1l1111l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪ౫")]
      key = CONFIG[bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬ౬")]
      url = bstack1l1111l_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࢀࢃ࠺ࡼࡿࡃࡥࡵ࡯࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡥࡺࡺ࡯࡮ࡣࡷࡩ࠴ࡹࡥࡴࡵ࡬ࡳࡳࡹ࠯ࡼࡿ࠱࡮ࡸࡵ࡮ࠨ౭").format(user, key, bstack11lll1ll1l_opy_)
      headers = {
        bstack1l1111l_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪ౮"): bstack1l1111l_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ౯"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers)
    except Exception as e:
      logger.error(bstack1l11lll1ll_opy_.format(str(e)))
def bstack11l11ll11_opy_(test, bstack1ll1l1ll1l_opy_):
  global CONFIG
  global bstack1l11111l11_opy_
  global bstack111llll1l1_opy_
  global bstack11lll1ll1l_opy_
  global bstack11ll1l1l1_opy_
  global bstack1l1l11l1l_opy_
  global bstack1l11l11ll1_opy_
  global bstack1l1ll1111_opy_
  global bstack11ll1ll11_opy_
  global bstack1l11l1ll1_opy_
  global bstack11llll1ll_opy_
  global bstack1l1l11l11_opy_
  try:
    if not bstack11lll1ll1l_opy_:
      with open(os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"࠭ࡾࠨ౰")), bstack1l1111l_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ౱"), bstack1l1111l_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ౲"))) as f:
        bstack11l11111l_opy_ = json.loads(bstack1l1111l_opy_ (u"ࠤࡾࠦ౳") + f.read().strip() + bstack1l1111l_opy_ (u"ࠪࠦࡽࠨ࠺ࠡࠤࡼࠦࠬ౴") + bstack1l1111l_opy_ (u"ࠦࢂࠨ౵"))
        bstack11lll1ll1l_opy_ = bstack11l11111l_opy_[str(threading.get_ident())]
  except:
    pass
  if bstack11llll1ll_opy_:
    for driver in bstack11llll1ll_opy_:
      if bstack11lll1ll1l_opy_ == driver.session_id:
        if test:
          bstack1lll1l1ll_opy_(driver, test)
        bstack1l1l1ll1l1_opy_(driver, bstack1ll1l1ll1l_opy_)
  elif bstack11lll1ll1l_opy_:
    bstack1ll1111ll_opy_(test, bstack1ll1l1ll1l_opy_)
  if bstack1l11111l11_opy_:
    bstack1l1ll1111_opy_(bstack1l11111l11_opy_)
  if bstack111llll1l1_opy_:
    bstack11ll1ll11_opy_(bstack111llll1l1_opy_)
  if bstack111l11111_opy_:
    bstack1l11l1ll1_opy_()
def bstack11ll1lll11_opy_(self, test, *args, **kwargs):
  bstack1ll1l1ll1l_opy_ = None
  if test:
    bstack1ll1l1ll1l_opy_ = str(test.name)
  bstack11l11ll11_opy_(test, bstack1ll1l1ll1l_opy_)
  bstack1l11l11ll1_opy_(self, test, *args, **kwargs)
def bstack11ll1ll1ll_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack11l1l1l11l_opy_
  global CONFIG
  global bstack11llll1ll_opy_
  global bstack11lll1ll1l_opy_
  bstack11l1ll11l1_opy_ = None
  try:
    if bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫ౶"), None):
      try:
        if not bstack11lll1ll1l_opy_:
          with open(os.path.join(os.path.expanduser(bstack1l1111l_opy_ (u"࠭ࡾࠨ౷")), bstack1l1111l_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ౸"), bstack1l1111l_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ౹"))) as f:
            bstack11l11111l_opy_ = json.loads(bstack1l1111l_opy_ (u"ࠤࡾࠦ౺") + f.read().strip() + bstack1l1111l_opy_ (u"ࠪࠦࡽࠨ࠺ࠡࠤࡼࠦࠬ౻") + bstack1l1111l_opy_ (u"ࠦࢂࠨ౼"))
            bstack11lll1ll1l_opy_ = bstack11l11111l_opy_[str(threading.get_ident())]
      except:
        pass
      if bstack11llll1ll_opy_:
        for driver in bstack11llll1ll_opy_:
          if bstack11lll1ll1l_opy_ == driver.session_id:
            bstack11l1ll11l1_opy_ = driver
    bstack1lll111lll_opy_ = bstack1111ll11_opy_.bstack1llll1l1l1_opy_(test.tags)
    if bstack11l1ll11l1_opy_:
      threading.current_thread().isA11yTest = bstack1111ll11_opy_.bstack111lllll1_opy_(bstack11l1ll11l1_opy_, bstack1lll111lll_opy_)
    else:
      threading.current_thread().isA11yTest = bstack1lll111lll_opy_
  except:
    pass
  bstack11l1l1l11l_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack11ll1l1l1_opy_
  bstack11ll1l1l1_opy_ = self._test
def bstack11l1l11111_opy_():
  global bstack11ll11ll1l_opy_
  try:
    if os.path.exists(bstack11ll11ll1l_opy_):
      os.remove(bstack11ll11ll1l_opy_)
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡥࡧ࡯ࡩࡹ࡯࡮ࡨࠢࡵࡳࡧࡵࡴࠡࡴࡨࡴࡴࡸࡴࠡࡨ࡬ࡰࡪࡀࠠࠨ౽") + str(e))
def bstack11lll1ll1_opy_():
  global bstack11ll11ll1l_opy_
  bstack1l1l1l111_opy_ = {}
  try:
    if not os.path.isfile(bstack11ll11ll1l_opy_):
      with open(bstack11ll11ll1l_opy_, bstack1l1111l_opy_ (u"࠭ࡷࠨ౾")):
        pass
      with open(bstack11ll11ll1l_opy_, bstack1l1111l_opy_ (u"ࠢࡸ࠭ࠥ౿")) as outfile:
        json.dump({}, outfile)
    if os.path.exists(bstack11ll11ll1l_opy_):
      bstack1l1l1l111_opy_ = json.load(open(bstack11ll11ll1l_opy_, bstack1l1111l_opy_ (u"ࠨࡴࡥࠫಀ")))
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡷ࡫ࡡࡥ࡫ࡱ࡫ࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫࡯࡬ࡦ࠼ࠣࠫಁ") + str(e))
  finally:
    return bstack1l1l1l111_opy_
def bstack1l11lll1l_opy_(platform_index, item_index):
  global bstack11ll11ll1l_opy_
  try:
    bstack1l1l1l111_opy_ = bstack11lll1ll1_opy_()
    bstack1l1l1l111_opy_[item_index] = platform_index
    with open(bstack11ll11ll1l_opy_, bstack1l1111l_opy_ (u"ࠥࡻ࠰ࠨಂ")) as outfile:
      json.dump(bstack1l1l1l111_opy_, outfile)
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡷࡳ࡫ࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡶࡴࡨ࡯ࡵࠢࡵࡩࡵࡵࡲࡵࠢࡩ࡭ࡱ࡫࠺ࠡࠩಃ") + str(e))
def bstack11llll111l_opy_(bstack1ll111ll1l_opy_):
  global CONFIG
  bstack111llllll_opy_ = bstack1l1111l_opy_ (u"ࠬ࠭಄")
  if not bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩಅ") in CONFIG:
    logger.info(bstack1l1111l_opy_ (u"ࠧࡏࡱࠣࡴࡱࡧࡴࡧࡱࡵࡱࡸࠦࡰࡢࡵࡶࡩࡩࠦࡵ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫ࡵࡲࠡࡔࡲࡦࡴࡺࠠࡳࡷࡱࠫಆ"))
  try:
    platform = CONFIG[bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫಇ")][bstack1ll111ll1l_opy_]
    if bstack1l1111l_opy_ (u"ࠩࡲࡷࠬಈ") in platform:
      bstack111llllll_opy_ += str(platform[bstack1l1111l_opy_ (u"ࠪࡳࡸ࠭ಉ")]) + bstack1l1111l_opy_ (u"ࠫ࠱ࠦࠧಊ")
    if bstack1l1111l_opy_ (u"ࠬࡵࡳࡗࡧࡵࡷ࡮ࡵ࡮ࠨಋ") in platform:
      bstack111llllll_opy_ += str(platform[bstack1l1111l_opy_ (u"࠭࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠩಌ")]) + bstack1l1111l_opy_ (u"ࠧ࠭ࠢࠪ಍")
    if bstack1l1111l_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠬಎ") in platform:
      bstack111llllll_opy_ += str(platform[bstack1l1111l_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࡐࡤࡱࡪ࠭ಏ")]) + bstack1l1111l_opy_ (u"ࠪ࠰ࠥ࠭ಐ")
    if bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭಑") in platform:
      bstack111llllll_opy_ += str(platform[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧಒ")]) + bstack1l1111l_opy_ (u"࠭ࠬࠡࠩಓ")
    if bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬಔ") in platform:
      bstack111llllll_opy_ += str(platform[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭ಕ")]) + bstack1l1111l_opy_ (u"ࠩ࠯ࠤࠬಖ")
    if bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫಗ") in platform:
      bstack111llllll_opy_ += str(platform[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬಘ")]) + bstack1l1111l_opy_ (u"ࠬ࠲ࠠࠨಙ")
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"࠭ࡓࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡰࡨࡶࡦࡺࡩ࡯ࡩࠣࡴࡱࡧࡴࡧࡱࡵࡱࠥࡹࡴࡳ࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡵࡩࡵࡵࡲࡵࠢࡪࡩࡳ࡫ࡲࡢࡶ࡬ࡳࡳ࠭ಚ") + str(e))
  finally:
    if bstack111llllll_opy_[len(bstack111llllll_opy_) - 2:] == bstack1l1111l_opy_ (u"ࠧ࠭ࠢࠪಛ"):
      bstack111llllll_opy_ = bstack111llllll_opy_[:-2]
    return bstack111llllll_opy_
def bstack1l1l1l1l1l_opy_(path, bstack111llllll_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack11l1lll1ll_opy_ = ET.parse(path)
    bstack11l11111ll_opy_ = bstack11l1lll1ll_opy_.getroot()
    bstack11l1111l1_opy_ = None
    for suite in bstack11l11111ll_opy_.iter(bstack1l1111l_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧಜ")):
      if bstack1l1111l_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩಝ") in suite.attrib:
        suite.attrib[bstack1l1111l_opy_ (u"ࠪࡲࡦࡳࡥࠨಞ")] += bstack1l1111l_opy_ (u"ࠫࠥ࠭ಟ") + bstack111llllll_opy_
        bstack11l1111l1_opy_ = suite
    bstack1l111l1l1l_opy_ = None
    for robot in bstack11l11111ll_opy_.iter(bstack1l1111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫಠ")):
      bstack1l111l1l1l_opy_ = robot
    bstack11l1ll1l1l_opy_ = len(bstack1l111l1l1l_opy_.findall(bstack1l1111l_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬಡ")))
    if bstack11l1ll1l1l_opy_ == 1:
      bstack1l111l1l1l_opy_.remove(bstack1l111l1l1l_opy_.findall(bstack1l1111l_opy_ (u"ࠧࡴࡷ࡬ࡸࡪ࠭ಢ"))[0])
      bstack111lllll11_opy_ = ET.Element(bstack1l1111l_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧಣ"), attrib={bstack1l1111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧತ"): bstack1l1111l_opy_ (u"ࠪࡗࡺ࡯ࡴࡦࡵࠪಥ"), bstack1l1111l_opy_ (u"ࠫ࡮ࡪࠧದ"): bstack1l1111l_opy_ (u"ࠬࡹ࠰ࠨಧ")})
      bstack1l111l1l1l_opy_.insert(1, bstack111lllll11_opy_)
      bstack11llll11l1_opy_ = None
      for suite in bstack1l111l1l1l_opy_.iter(bstack1l1111l_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬನ")):
        bstack11llll11l1_opy_ = suite
      bstack11llll11l1_opy_.append(bstack11l1111l1_opy_)
      bstack1l11l1l11l_opy_ = None
      for status in bstack11l1111l1_opy_.iter(bstack1l1111l_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ಩")):
        bstack1l11l1l11l_opy_ = status
      bstack11llll11l1_opy_.append(bstack1l11l1l11l_opy_)
    bstack11l1lll1ll_opy_.write(path)
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡴࡦࡸࡳࡪࡰࡪࠤࡼ࡮ࡩ࡭ࡧࠣ࡫ࡪࡴࡥࡳࡣࡷ࡭ࡳ࡭ࠠࡳࡱࡥࡳࡹࠦࡲࡦࡲࡲࡶࡹ࠭ಪ") + str(e))
def bstack11111l1l1_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack11l1llll11_opy_
  global CONFIG
  if bstack1l1111l_opy_ (u"ࠤࡳࡽࡹ࡮࡯࡯ࡲࡤࡸ࡭ࠨಫ") in options:
    del options[bstack1l1111l_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࡳࡥࡹ࡮ࠢಬ")]
  json_data = bstack11lll1ll1_opy_()
  for bstack11l111l111_opy_ in json_data.keys():
    path = os.path.join(os.getcwd(), bstack1l1111l_opy_ (u"ࠫࡵࡧࡢࡰࡶࡢࡶࡪࡹࡵ࡭ࡶࡶࠫಭ"), str(bstack11l111l111_opy_), bstack1l1111l_opy_ (u"ࠬࡵࡵࡵࡲࡸࡸ࠳ࡾ࡭࡭ࠩಮ"))
    bstack1l1l1l1l1l_opy_(path, bstack11llll111l_opy_(json_data[bstack11l111l111_opy_]))
  bstack11l1l11111_opy_()
  return bstack11l1llll11_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack111ll1l1l_opy_(self, ff_profile_dir):
  global bstack1lll1ll1l_opy_
  if not ff_profile_dir:
    return None
  return bstack1lll1ll1l_opy_(self, ff_profile_dir)
def bstack11l11ll1l1_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack111111ll1_opy_
  bstack1l11l1l111_opy_ = []
  if bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩಯ") in CONFIG:
    bstack1l11l1l111_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪರ")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack1l1111l_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࠤಱ")],
      pabot_args[bstack1l1111l_opy_ (u"ࠤࡹࡩࡷࡨ࡯ࡴࡧࠥಲ")],
      argfile,
      pabot_args.get(bstack1l1111l_opy_ (u"ࠥ࡬࡮ࡼࡥࠣಳ")),
      pabot_args[bstack1l1111l_opy_ (u"ࠦࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠢ಴")],
      platform[0],
      bstack111111ll1_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack1l1111l_opy_ (u"ࠧࡧࡲࡨࡷࡰࡩࡳࡺࡦࡪ࡮ࡨࡷࠧವ")] or [(bstack1l1111l_opy_ (u"ࠨࠢಶ"), None)]
    for platform in enumerate(bstack1l11l1l111_opy_)
  ]
def bstack11l1lllll1_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1l1lll111_opy_=bstack1l1111l_opy_ (u"ࠧࠨಷ")):
  global bstack1111l1lll_opy_
  self.platform_index = platform_index
  self.bstack1l11l1l11_opy_ = bstack1l1lll111_opy_
  bstack1111l1lll_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack1llll1l11l_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack1lll11l11l_opy_
  global bstack11l1l1lll_opy_
  bstack1l11lll11l_opy_ = copy.deepcopy(item)
  if not bstack1l1111l_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪಸ") in item.options:
    bstack1l11lll11l_opy_.options[bstack1l1111l_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫಹ")] = []
  bstack1l1l1llll_opy_ = bstack1l11lll11l_opy_.options[bstack1l1111l_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬ಺")].copy()
  for v in bstack1l11lll11l_opy_.options[bstack1l1111l_opy_ (u"ࠫࡻࡧࡲࡪࡣࡥࡰࡪ࠭಻")]:
    if bstack1l1111l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡕࡒࡁࡕࡈࡒࡖࡒࡏࡎࡅࡇ಼࡛ࠫ") in v:
      bstack1l1l1llll_opy_.remove(v)
    if bstack1l1111l_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘ࠭ಽ") in v:
      bstack1l1l1llll_opy_.remove(v)
    if bstack1l1111l_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡄࡆࡈࡏࡓࡈࡇࡌࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕࠫಾ") in v:
      bstack1l1l1llll_opy_.remove(v)
  bstack1l1l1llll_opy_.insert(0, bstack1l1111l_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡑࡎࡄࡘࡋࡕࡒࡎࡋࡑࡈࡊ࡞࠺ࡼࡿࠪಿ").format(bstack1l11lll11l_opy_.platform_index))
  bstack1l1l1llll_opy_.insert(0, bstack1l1111l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡆࡈࡊࡑࡕࡃࡂࡎࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗࡀࡻࡾࠩೀ").format(bstack1l11lll11l_opy_.bstack1l11l1l11_opy_))
  bstack1l11lll11l_opy_.options[bstack1l1111l_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬು")] = bstack1l1l1llll_opy_
  if bstack11l1l1lll_opy_:
    bstack1l11lll11l_opy_.options[bstack1l1111l_opy_ (u"ࠫࡻࡧࡲࡪࡣࡥࡰࡪ࠭ೂ")].insert(0, bstack1l1111l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡈࡒࡉࡂࡔࡊࡗ࠿ࢁࡽࠨೃ").format(bstack11l1l1lll_opy_))
  return bstack1lll11l11l_opy_(caller_id, datasources, is_last, bstack1l11lll11l_opy_, outs_dir)
def bstack11l1l1l111_opy_(command, item_index):
  if bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡳࡦࡵࡶ࡭ࡴࡴࠧೄ")):
    os.environ[bstack1l1111l_opy_ (u"ࠧࡄࡗࡕࡖࡊࡔࡔࡠࡒࡏࡅ࡙ࡌࡏࡓࡏࡢࡈࡆ࡚ࡁࠨ೅")] = json.dumps(CONFIG[bstack1l1111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫೆ")][item_index % bstack1l1llllll1_opy_])
  global bstack11l1l1lll_opy_
  if bstack11l1l1lll_opy_:
    command[0] = command[0].replace(bstack1l1111l_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨೇ"), bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠯ࡶࡨࡰࠦࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠠ࠮࠯ࡥࡷࡹࡧࡣ࡬ࡡ࡬ࡸࡪࡳ࡟ࡪࡰࡧࡩࡽࠦࠧೈ") + str(
      item_index) + bstack1l1111l_opy_ (u"ࠫࠥ࠭೉") + bstack11l1l1lll_opy_, 1)
  else:
    command[0] = command[0].replace(bstack1l1111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫೊ"),
                                    bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠲ࡹࡤ࡬ࠢࡵࡳࡧࡵࡴ࠮࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠣ࠱࠲ࡨࡳࡵࡣࡦ࡯ࡤ࡯ࡴࡦ࡯ࡢ࡭ࡳࡪࡥࡹࠢࠪೋ") + str(item_index), 1)
def bstack1ll1l1l111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack1l1l1l1ll_opy_
  bstack11l1l1l111_opy_(command, item_index)
  return bstack1l1l1l1ll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
def bstack1111l111l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack1l1l1l1ll_opy_
  bstack11l1l1l111_opy_(command, item_index)
  return bstack1l1l1l1ll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
def bstack1111ll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack1l1l1l1ll_opy_
  bstack11l1l1l111_opy_(command, item_index)
  return bstack1l1l1l1ll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
def is_driver_active(driver):
  return True if driver and driver.session_id else False
def bstack1lll1l1l1_opy_(self, runner, quiet=False, capture=True):
  global bstack1ll1l1l1ll_opy_
  bstack11l11l11l1_opy_ = bstack1ll1l1l1ll_opy_(self, runner, quiet=quiet, capture=capture)
  if self.exception:
    if not hasattr(runner, bstack1l1111l_opy_ (u"ࠧࡦࡺࡦࡩࡵࡺࡩࡰࡰࡢࡥࡷࡸࠧೌ")):
      runner.exception_arr = []
    if not hasattr(runner, bstack1l1111l_opy_ (u"ࠨࡧࡻࡧࡤࡺࡲࡢࡥࡨࡦࡦࡩ࡫ࡠࡣࡵࡶ್ࠬ")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack11l11l11l1_opy_
def bstack1ll1lll1l_opy_(runner, hook_name, context, element, bstack1l11ll11l_opy_, *args):
  try:
    if runner.hooks.get(hook_name):
      bstack1l1l11l1ll_opy_.bstack11l1lll1_opy_(hook_name, element)
    bstack1l11ll11l_opy_(runner, hook_name, context, *args)
    if runner.hooks.get(hook_name):
      bstack1l1l11l1ll_opy_.bstack11l1l1l1_opy_(element)
      if hook_name not in [bstack1l1111l_opy_ (u"ࠩࡥࡩ࡫ࡵࡲࡦࡡࡤࡰࡱ࠭೎"), bstack1l1111l_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡤࡰࡱ࠭೏")] and args and hasattr(args[0], bstack1l1111l_opy_ (u"ࠫࡪࡸࡲࡰࡴࡢࡱࡪࡹࡳࡢࡩࡨࠫ೐")):
        args[0].error_message = bstack1l1111l_opy_ (u"ࠬ࠭೑")
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡫ࡥࡳࡪ࡬ࡦࠢ࡫ࡳࡴࡱࡳࠡ࡫ࡱࠤࡧ࡫ࡨࡢࡸࡨ࠾ࠥࢁࡽࠨ೒").format(str(e)))
@measure(event_name=EVENTS.bstack11ll11llll_opy_, stage=STAGE.SINGLE, hook_type=bstack1l1111l_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫ࡁ࡭࡮ࠥ೓"), bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11ll1ll11l_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    if runner.hooks.get(bstack1l1111l_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࡠࡣ࡯ࡰࠧ೔")).__name__ != bstack1l1111l_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡤࡰࡱࡥࡤࡦࡨࡤࡹࡱࡺ࡟ࡩࡱࡲ࡯ࠧೕ"):
      bstack1ll1lll1l_opy_(runner, name, context, runner, bstack1l11ll11l_opy_, *args)
    try:
      threading.current_thread().bstackSessionDriver if bstack1l11111l1_opy_(bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡖࡩࡸࡹࡩࡰࡰࡇࡶ࡮ࡼࡥࡳࠩೖ")) else context.browser
      runner.driver_initialised = bstack1l1111l_opy_ (u"ࠦࡧ࡫ࡦࡰࡴࡨࡣࡦࡲ࡬ࠣ೗")
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡸࠥࡪࡲࡪࡸࡨࡶࠥ࡯࡮ࡪࡶ࡬ࡥࡱ࡯ࡳࡦࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩ࠿ࠦࡻࡾࠩ೘").format(str(e)))
def bstack11l111111_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    bstack1ll1lll1l_opy_(runner, name, context, context.feature, bstack1l11ll11l_opy_, *args)
    try:
      if not bstack11l1ll111_opy_:
        bstack11l1ll11l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11111l1_opy_(bstack1l1111l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ೙")) else context.browser
        if is_driver_active(bstack11l1ll11l1_opy_):
          if runner.driver_initialised is None: runner.driver_initialised = bstack1l1111l_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡧࡧࡤࡸࡺࡸࡥࠣ೚")
          bstack11lll1l11l_opy_ = str(runner.feature.name)
          bstack1l11l1l1l1_opy_(context, bstack11lll1l11l_opy_)
          bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡴࡡ࡮ࡧࠥ࠾ࠥ࠭೛") + json.dumps(bstack11lll1l11l_opy_) + bstack1l1111l_opy_ (u"ࠩࢀࢁࠬ೜"))
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡦࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦࠢ࡬ࡲࠥࡨࡥࡧࡱࡵࡩࠥ࡬ࡥࡢࡶࡸࡶࡪࡀࠠࡼࡿࠪೝ").format(str(e)))
def bstack11l1111111_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    if hasattr(context, bstack1l1111l_opy_ (u"ࠫࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭ೞ")):
        bstack1l1l11l1ll_opy_.start_test(context)
    target = context.scenario if hasattr(context, bstack1l1111l_opy_ (u"ࠬࡹࡣࡦࡰࡤࡶ࡮ࡵࠧ೟")) else context.feature
    bstack1ll1lll1l_opy_(runner, name, context, target, bstack1l11ll11l_opy_, *args)
@measure(event_name=EVENTS.bstack1l111lllll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1l1l11lll_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    if len(context.scenario.tags) == 0: bstack1l1l11l1ll_opy_.start_test(context)
    bstack1ll1lll1l_opy_(runner, name, context, context.scenario, bstack1l11ll11l_opy_, *args)
    threading.current_thread().a11y_stop = False
    bstack1ll1l1lll1_opy_.bstack1lll111l1_opy_(context, *args)
    try:
      bstack11l1ll11l1_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬೠ"), context.browser)
      if is_driver_active(bstack11l1ll11l1_opy_):
        bstack1l11l1l1_opy_.bstack1ll1lll111_opy_(bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡓࡦࡵࡶ࡭ࡴࡴࡄࡳ࡫ࡹࡩࡷ࠭ೡ"), {}))
        if runner.driver_initialised is None: runner.driver_initialised = bstack1l1111l_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࡠࡵࡦࡩࡳࡧࡲࡪࡱࠥೢ")
        if (not bstack11l1ll111_opy_):
          scenario_name = args[0].name
          feature_name = bstack11lll1l11l_opy_ = str(runner.feature.name)
          bstack11lll1l11l_opy_ = feature_name + bstack1l1111l_opy_ (u"ࠩࠣ࠱ࠥ࠭ೣ") + scenario_name
          if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࡢࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠧ೤"):
            bstack1l11l1l1l1_opy_(context, bstack11lll1l11l_opy_)
            bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡰࡤࡱࡪࠨ࠺ࠡࠩ೥") + json.dumps(bstack11lll1l11l_opy_) + bstack1l1111l_opy_ (u"ࠬࢃࡽࠨ೦"))
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡩࡹࠦࡳࡦࡵࡶ࡭ࡴࡴࠠ࡯ࡣࡰࡩࠥ࡯࡮ࠡࡤࡨࡪࡴࡸࡥࠡࡵࡦࡩࡳࡧࡲࡪࡱ࠽ࠤࢀࢃࠧ೧").format(str(e)))
@measure(event_name=EVENTS.bstack11ll11llll_opy_, stage=STAGE.SINGLE, hook_type=bstack1l1111l_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫ࡓࡵࡧࡳࠦ೨"), bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack111llll11_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    bstack1ll1lll1l_opy_(runner, name, context, args[0], bstack1l11ll11l_opy_, *args)
    try:
      bstack11l1ll11l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11111l1_opy_(bstack1l1111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧ೩")) else context.browser
      if is_driver_active(bstack11l1ll11l1_opy_):
        if runner.driver_initialised is None: runner.driver_initialised = bstack1l1111l_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡶࡸࡪࡶࠢ೪")
        bstack1l1l11l1ll_opy_.bstack11l1ll1l_opy_(args[0])
        if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࡢࡷࡹ࡫ࡰࠣ೫"):
          feature_name = bstack11lll1l11l_opy_ = str(runner.feature.name)
          bstack11lll1l11l_opy_ = feature_name + bstack1l1111l_opy_ (u"ࠫࠥ࠳ࠠࠨ೬") + context.scenario.name
          bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠢࠪ೭") + json.dumps(bstack11lll1l11l_opy_) + bstack1l1111l_opy_ (u"࠭ࡽࡾࠩ೮"))
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡺࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡰࡤࡱࡪࠦࡩ࡯ࠢࡥࡩ࡫ࡵࡲࡦࠢࡶࡸࡪࡶ࠺ࠡࡽࢀࠫ೯").format(str(e)))
@measure(event_name=EVENTS.bstack11ll11llll_opy_, stage=STAGE.SINGLE, hook_type=bstack1l1111l_opy_ (u"ࠣࡣࡩࡸࡪࡸࡓࡵࡧࡳࠦ೰"), bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11l111ll1_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
  bstack1l1l11l1ll_opy_.bstack11ll1l11_opy_(args[0])
  try:
    bstack1l1lllll11_opy_ = args[0].status.name
    bstack11l1ll11l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨೱ") in threading.current_thread().__dict__.keys() else context.browser
    if is_driver_active(bstack11l1ll11l1_opy_):
      if runner.driver_initialised is None:
        runner.driver_initialised  = bstack1l1111l_opy_ (u"ࠪ࡭ࡳࡹࡴࡦࡲࠪೲ")
        feature_name = bstack11lll1l11l_opy_ = str(runner.feature.name)
        bstack11lll1l11l_opy_ = feature_name + bstack1l1111l_opy_ (u"ࠫࠥ࠳ࠠࠨೳ") + context.scenario.name
        bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠢࠪ೴") + json.dumps(bstack11lll1l11l_opy_) + bstack1l1111l_opy_ (u"࠭ࡽࡾࠩ೵"))
    if str(bstack1l1lllll11_opy_).lower() == bstack1l1111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ೶"):
      bstack1lllll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠨࠩ೷")
      bstack1ll1lll1l1_opy_ = bstack1l1111l_opy_ (u"ࠩࠪ೸")
      bstack1llll11l11_opy_ = bstack1l1111l_opy_ (u"ࠪࠫ೹")
      try:
        import traceback
        bstack1lllll1l1l_opy_ = runner.exception.__class__.__name__
        bstack11ll111l_opy_ = traceback.format_tb(runner.exc_traceback)
        bstack1ll1lll1l1_opy_ = bstack1l1111l_opy_ (u"ࠫࠥ࠭೺").join(bstack11ll111l_opy_)
        bstack1llll11l11_opy_ = bstack11ll111l_opy_[-1]
      except Exception as e:
        logger.debug(bstack1ll1lll1ll_opy_.format(str(e)))
      bstack1lllll1l1l_opy_ += bstack1llll11l11_opy_
      bstack11ll1lll1_opy_(context, json.dumps(str(args[0].name) + bstack1l1111l_opy_ (u"ࠧࠦ࠭ࠡࡈࡤ࡭ࡱ࡫ࡤࠢ࡞ࡱࠦ೻") + str(bstack1ll1lll1l1_opy_)),
                          bstack1l1111l_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ೼"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡴࡶࡨࡴࠧ೽"):
        bstack11l1l1l1ll_opy_(getattr(context, bstack1l1111l_opy_ (u"ࠨࡲࡤ࡫ࡪ࠭೾"), None), bstack1l1111l_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤ೿"), bstack1lllll1l1l_opy_)
        bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨഀ") + json.dumps(str(args[0].name) + bstack1l1111l_opy_ (u"ࠦࠥ࠳ࠠࡇࡣ࡬ࡰࡪࡪࠡ࡝ࡰࠥഁ") + str(bstack1ll1lll1l1_opy_)) + bstack1l1111l_opy_ (u"ࠬ࠲ࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥࡩࡷࡸ࡯ࡳࠤࢀࢁࠬം"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡳࡵࡧࡳࠦഃ"):
        bstack11ll1111ll_opy_(bstack11l1ll11l1_opy_, bstack1l1111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧഄ"), bstack1l1111l_opy_ (u"ࠣࡕࡦࡩࡳࡧࡲࡪࡱࠣࡪࡦ࡯࡬ࡦࡦࠣࡻ࡮ࡺࡨ࠻ࠢ࡟ࡲࠧഅ") + str(bstack1lllll1l1l_opy_))
    else:
      bstack11ll1lll1_opy_(context, bstack1l1111l_opy_ (u"ࠤࡓࡥࡸࡹࡥࡥࠣࠥആ"), bstack1l1111l_opy_ (u"ࠥ࡭ࡳ࡬࡯ࠣഇ"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠦࡧ࡫ࡦࡰࡴࡨࡣࡸࡺࡥࡱࠤഈ"):
        bstack11l1l1l1ll_opy_(getattr(context, bstack1l1111l_opy_ (u"ࠬࡶࡡࡨࡧࠪഉ"), None), bstack1l1111l_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠨഊ"))
      bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡢࡰࡱࡳࡹࡧࡴࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡪࡡࡵࡣࠥ࠾ࠬഋ") + json.dumps(str(args[0].name) + bstack1l1111l_opy_ (u"ࠣࠢ࠰ࠤࡕࡧࡳࡴࡧࡧࠥࠧഌ")) + bstack1l1111l_opy_ (u"ࠩ࠯ࠤࠧࡲࡥࡷࡧ࡯ࠦ࠿ࠦࠢࡪࡰࡩࡳࠧࢃࡽࠨ഍"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࡢࡷࡹ࡫ࡰࠣഎ"):
        bstack11ll1111ll_opy_(bstack11l1ll11l1_opy_, bstack1l1111l_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦഏ"))
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡ࡯ࡤࡶࡰࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡴࡶࡤࡸࡺࡹࠠࡪࡰࠣࡥ࡫ࡺࡥࡳࠢࡶࡸࡪࡶ࠺ࠡࡽࢀࠫഐ").format(str(e)))
  bstack1ll1lll1l_opy_(runner, name, context, args[0], bstack1l11ll11l_opy_, *args)
@measure(event_name=EVENTS.bstack1lll1ll11_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1ll1ll1l1_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
  bstack1l1l11l1ll_opy_.end_test(args[0])
  try:
    bstack11l111ll11_opy_ = args[0].status.name
    bstack11l1ll11l1_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ഑"), context.browser)
    bstack1ll1l1lll1_opy_.bstack1l1111lll_opy_(bstack11l1ll11l1_opy_)
    if str(bstack11l111ll11_opy_).lower() == bstack1l1111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧഒ"):
      bstack1lllll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠨࠩഓ")
      bstack1ll1lll1l1_opy_ = bstack1l1111l_opy_ (u"ࠩࠪഔ")
      bstack1llll11l11_opy_ = bstack1l1111l_opy_ (u"ࠪࠫക")
      try:
        import traceback
        bstack1lllll1l1l_opy_ = runner.exception.__class__.__name__
        bstack11ll111l_opy_ = traceback.format_tb(runner.exc_traceback)
        bstack1ll1lll1l1_opy_ = bstack1l1111l_opy_ (u"ࠫࠥ࠭ഖ").join(bstack11ll111l_opy_)
        bstack1llll11l11_opy_ = bstack11ll111l_opy_[-1]
      except Exception as e:
        logger.debug(bstack1ll1lll1ll_opy_.format(str(e)))
      bstack1lllll1l1l_opy_ += bstack1llll11l11_opy_
      bstack11ll1lll1_opy_(context, json.dumps(str(args[0].name) + bstack1l1111l_opy_ (u"ࠧࠦ࠭ࠡࡈࡤ࡭ࡱ࡫ࡤࠢ࡞ࡱࠦഗ") + str(bstack1ll1lll1l1_opy_)),
                          bstack1l1111l_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧഘ"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠤങ") or runner.driver_initialised == bstack1l1111l_opy_ (u"ࠨ࡫ࡱࡷࡹ࡫ࡰࠨച"):
        bstack11l1l1l1ll_opy_(getattr(context, bstack1l1111l_opy_ (u"ࠩࡳࡥ࡬࡫ࠧഛ"), None), bstack1l1111l_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥജ"), bstack1lllll1l1l_opy_)
        bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩഝ") + json.dumps(str(args[0].name) + bstack1l1111l_opy_ (u"ࠧࠦ࠭ࠡࡈࡤ࡭ࡱ࡫ࡤࠢ࡞ࡱࠦഞ") + str(bstack1ll1lll1l1_opy_)) + bstack1l1111l_opy_ (u"࠭ࠬࠡࠤ࡯ࡩࡻ࡫࡬ࠣ࠼ࠣࠦࡪࡸࡲࡰࡴࠥࢁࢂ࠭ട"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠤഠ") or runner.driver_initialised == bstack1l1111l_opy_ (u"ࠨ࡫ࡱࡷࡹ࡫ࡰࠨഡ"):
        bstack11ll1111ll_opy_(bstack11l1ll11l1_opy_, bstack1l1111l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩഢ"), bstack1l1111l_opy_ (u"ࠥࡗࡨ࡫࡮ࡢࡴ࡬ࡳࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡽࡩࡵࡪ࠽ࠤࡡࡴࠢണ") + str(bstack1lllll1l1l_opy_))
    else:
      bstack11ll1lll1_opy_(context, bstack1l1111l_opy_ (u"ࠦࡕࡧࡳࡴࡧࡧࠥࠧത"), bstack1l1111l_opy_ (u"ࠧ࡯࡮ࡧࡱࠥഥ"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠣദ") or runner.driver_initialised == bstack1l1111l_opy_ (u"ࠧࡪࡰࡶࡸࡪࡶࠧധ"):
        bstack11l1l1l1ll_opy_(getattr(context, bstack1l1111l_opy_ (u"ࠨࡲࡤ࡫ࡪ࠭ന"), None), bstack1l1111l_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤഩ"))
      bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨപ") + json.dumps(str(args[0].name) + bstack1l1111l_opy_ (u"ࠦࠥ࠳ࠠࡑࡣࡶࡷࡪࡪࠡࠣഫ")) + bstack1l1111l_opy_ (u"ࠬ࠲ࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥ࡭ࡳ࡬࡯ࠣࡿࢀࠫബ"))
      if runner.driver_initialised == bstack1l1111l_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠣഭ") or runner.driver_initialised == bstack1l1111l_opy_ (u"ࠧࡪࡰࡶࡸࡪࡶࠧമ"):
        bstack11ll1111ll_opy_(bstack11l1ll11l1_opy_, bstack1l1111l_opy_ (u"ࠣࡲࡤࡷࡸ࡫ࡤࠣയ"))
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡳࡡࡳ࡭ࠣࡷࡪࡹࡳࡪࡱࡱࠤࡸࡺࡡࡵࡷࡶࠤ࡮ࡴࠠࡢࡨࡷࡩࡷࠦࡦࡦࡣࡷࡹࡷ࡫࠺ࠡࡽࢀࠫര").format(str(e)))
  bstack1ll1lll1l_opy_(runner, name, context, context.scenario, bstack1l11ll11l_opy_, *args)
  if len(context.scenario.tags) == 0: threading.current_thread().current_test_uuid = None
def bstack1ll1111l1_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    target = context.scenario if hasattr(context, bstack1l1111l_opy_ (u"ࠪࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠬറ")) else context.feature
    bstack1ll1lll1l_opy_(runner, name, context, target, bstack1l11ll11l_opy_, *args)
    threading.current_thread().current_test_uuid = None
def bstack1llll1lll1_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    try:
      bstack11l1ll11l1_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪല"), context.browser)
      bstack1l11ll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠬ࠭ള")
      if context.failed is True:
        bstack1lll1l11l_opy_ = []
        bstack11llllll1_opy_ = []
        bstack11l1l11ll1_opy_ = []
        try:
          import traceback
          for exc in runner.exception_arr:
            bstack1lll1l11l_opy_.append(exc.__class__.__name__)
          for exc_tb in runner.exc_traceback_arr:
            bstack11ll111l_opy_ = traceback.format_tb(exc_tb)
            bstack11l111l1l1_opy_ = bstack1l1111l_opy_ (u"࠭ࠠࠨഴ").join(bstack11ll111l_opy_)
            bstack11llllll1_opy_.append(bstack11l111l1l1_opy_)
            bstack11l1l11ll1_opy_.append(bstack11ll111l_opy_[-1])
        except Exception as e:
          logger.debug(bstack1ll1lll1ll_opy_.format(str(e)))
        bstack1lllll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠧࠨവ")
        for i in range(len(bstack1lll1l11l_opy_)):
          bstack1lllll1l1l_opy_ += bstack1lll1l11l_opy_[i] + bstack11l1l11ll1_opy_[i] + bstack1l1111l_opy_ (u"ࠨ࡞ࡱࠫശ")
        bstack1l11ll1l1l_opy_ = bstack1l1111l_opy_ (u"ࠩࠣࠫഷ").join(bstack11llllll1_opy_)
        if runner.driver_initialised in [bstack1l1111l_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࡢࡪࡪࡧࡴࡶࡴࡨࠦസ"), bstack1l1111l_opy_ (u"ࠦࡧ࡫ࡦࡰࡴࡨࡣࡦࡲ࡬ࠣഹ")]:
          bstack11ll1lll1_opy_(context, bstack1l11ll1l1l_opy_, bstack1l1111l_opy_ (u"ࠧ࡫ࡲࡳࡱࡵࠦഺ"))
          bstack11l1l1l1ll_opy_(getattr(context, bstack1l1111l_opy_ (u"࠭ࡰࡢࡩࡨ഻ࠫ"), None), bstack1l1111l_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪ഼ࠢ"), bstack1lllll1l1l_opy_)
          bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡤࡢࡶࡤࠦ࠿࠭ഽ") + json.dumps(bstack1l11ll1l1l_opy_) + bstack1l1111l_opy_ (u"ࠩ࠯ࠤࠧࡲࡥࡷࡧ࡯ࠦ࠿ࠦࠢࡦࡴࡵࡳࡷࠨࡽࡾࠩാ"))
          bstack11ll1111ll_opy_(bstack11l1ll11l1_opy_, bstack1l1111l_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥി"), bstack1l1111l_opy_ (u"ࠦࡘࡵ࡭ࡦࠢࡶࡧࡪࡴࡡࡳ࡫ࡲࡷࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦ࡜࡯ࠤീ") + str(bstack1lllll1l1l_opy_))
          bstack11ll1l1l1l_opy_ = bstack1l11l1l1ll_opy_(bstack1l11ll1l1l_opy_, runner.feature.name, logger)
          if (bstack11ll1l1l1l_opy_ != None):
            bstack11lll11ll_opy_.append(bstack11ll1l1l1l_opy_)
      else:
        if runner.driver_initialised in [bstack1l1111l_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤ࡬ࡥࡢࡶࡸࡶࡪࠨു"), bstack1l1111l_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡡ࡭࡮ࠥൂ")]:
          bstack11ll1lll1_opy_(context, bstack1l1111l_opy_ (u"ࠢࡇࡧࡤࡸࡺࡸࡥ࠻ࠢࠥൃ") + str(runner.feature.name) + bstack1l1111l_opy_ (u"ࠣࠢࡳࡥࡸࡹࡥࡥࠣࠥൄ"), bstack1l1111l_opy_ (u"ࠤ࡬ࡲ࡫ࡵࠢ൅"))
          bstack11l1l1l1ll_opy_(getattr(context, bstack1l1111l_opy_ (u"ࠪࡴࡦ࡭ࡥࠨെ"), None), bstack1l1111l_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦേ"))
          bstack11l1ll11l1_opy_.execute_script(bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪൈ") + json.dumps(bstack1l1111l_opy_ (u"ࠨࡆࡦࡣࡷࡹࡷ࡫࠺ࠡࠤ൉") + str(runner.feature.name) + bstack1l1111l_opy_ (u"ࠢࠡࡲࡤࡷࡸ࡫ࡤࠢࠤൊ")) + bstack1l1111l_opy_ (u"ࠨ࠮ࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡩ࡯ࡨࡲࠦࢂࢃࠧോ"))
          bstack11ll1111ll_opy_(bstack11l1ll11l1_opy_, bstack1l1111l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩൌ"))
          bstack11ll1l1l1l_opy_ = bstack1l11l1l1ll_opy_(bstack1l11ll1l1l_opy_, runner.feature.name, logger)
          if (bstack11ll1l1l1l_opy_ != None):
            bstack11lll11ll_opy_.append(bstack11ll1l1l1l_opy_)
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦ࡭ࡢࡴ࡮ࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥ࡯࡮ࠡࡣࡩࡸࡪࡸࠠࡧࡧࡤࡸࡺࡸࡥ࠻ࠢࡾࢁ്ࠬ").format(str(e)))
    bstack1ll1lll1l_opy_(runner, name, context, context.feature, bstack1l11ll11l_opy_, *args)
@measure(event_name=EVENTS.bstack11ll11llll_opy_, stage=STAGE.SINGLE, hook_type=bstack1l1111l_opy_ (u"ࠦࡦ࡬ࡴࡦࡴࡄࡰࡱࠨൎ"), bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11lllllll1_opy_(runner, name, context, bstack1l11ll11l_opy_, *args):
    bstack1ll1lll1l_opy_(runner, name, context, runner, bstack1l11ll11l_opy_, *args)
def bstack1ll11lllll_opy_(self, name, context, *args):
  if bstack1ll1111lll_opy_:
    platform_index = int(threading.current_thread()._name) % bstack1l1llllll1_opy_
    bstack11l11l1111_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ൏")][platform_index]
    os.environ[bstack1l1111l_opy_ (u"࠭ࡃࡖࡔࡕࡉࡓ࡚࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡇࡅ࡙ࡇࠧ൐")] = json.dumps(bstack11l11l1111_opy_)
  global bstack1l11ll11l_opy_
  if not hasattr(self, bstack1l1111l_opy_ (u"ࠧࡥࡴ࡬ࡺࡪࡸ࡟ࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡵࡨࡨࠬ൑")):
    self.driver_initialised = None
  bstack1l1l1l1ll1_opy_ = {
      bstack1l1111l_opy_ (u"ࠨࡤࡨࡪࡴࡸࡥࡠࡣ࡯ࡰࠬ൒"): bstack11ll1ll11l_opy_,
      bstack1l1111l_opy_ (u"ࠩࡥࡩ࡫ࡵࡲࡦࡡࡩࡩࡦࡺࡵࡳࡧࠪ൓"): bstack11l111111_opy_,
      bstack1l1111l_opy_ (u"ࠪࡦࡪ࡬࡯ࡳࡧࡢࡸࡦ࡭ࠧൔ"): bstack11l1111111_opy_,
      bstack1l1111l_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭ൕ"): bstack1l1l11lll_opy_,
      bstack1l1111l_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࡤࡹࡴࡦࡲࠪൖ"): bstack111llll11_opy_,
      bstack1l1111l_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤࡹࡴࡦࡲࠪൗ"): bstack11l111ll1_opy_,
      bstack1l1111l_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠨ൘"): bstack1ll1ll1l1_opy_,
      bstack1l1111l_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡵࡣࡪࠫ൙"): bstack1ll1111l1_opy_,
      bstack1l1111l_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࡠࡨࡨࡥࡹࡻࡲࡦࠩ൚"): bstack1llll1lll1_opy_,
      bstack1l1111l_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡤࡰࡱ࠭൛"): bstack11lllllll1_opy_
  }
  handler = bstack1l1l1l1ll1_opy_.get(name, bstack1l11ll11l_opy_)
  handler(self, name, context, bstack1l11ll11l_opy_, *args)
  if name in [bstack1l1111l_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡪࡪࡧࡴࡶࡴࡨࠫ൜"), bstack1l1111l_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭൝"), bstack1l1111l_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤࡧ࡬࡭ࠩ൞")]:
    try:
      bstack11l1ll11l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11111l1_opy_(bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡓࡦࡵࡶ࡭ࡴࡴࡄࡳ࡫ࡹࡩࡷ࠭ൟ")) else context.browser
      bstack11l1l1llll_opy_ = (
        (name == bstack1l1111l_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡢ࡮࡯ࠫൠ") and self.driver_initialised == bstack1l1111l_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡤࡰࡱࠨൡ")) or
        (name == bstack1l1111l_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡩࡩࡦࡺࡵࡳࡧࠪൢ") and self.driver_initialised == bstack1l1111l_opy_ (u"ࠦࡧ࡫ࡦࡰࡴࡨࡣ࡫࡫ࡡࡵࡷࡵࡩࠧൣ")) or
        (name == bstack1l1111l_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭൤") and self.driver_initialised in [bstack1l1111l_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠣ൥"), bstack1l1111l_opy_ (u"ࠢࡪࡰࡶࡸࡪࡶࠢ൦")]) or
        (name == bstack1l1111l_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡴࡶࡨࡴࠬ൧") and self.driver_initialised == bstack1l1111l_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡶࡸࡪࡶࠢ൨"))
      )
      if bstack11l1l1llll_opy_:
        self.driver_initialised = None
        bstack11l1ll11l1_opy_.quit()
    except Exception:
      pass
def bstack1ll1l11ll_opy_(config, startdir):
  return bstack1l1111l_opy_ (u"ࠥࡨࡷ࡯ࡶࡦࡴ࠽ࠤࢀ࠶ࡽࠣ൩").format(bstack1l1111l_opy_ (u"ࠦࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠥ൪"))
notset = Notset()
def bstack1l1lllll1_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack11lll11l1l_opy_
  if str(name).lower() == bstack1l1111l_opy_ (u"ࠬࡪࡲࡪࡸࡨࡶࠬ൫"):
    return bstack1l1111l_opy_ (u"ࠨࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠧ൬")
  else:
    return bstack11lll11l1l_opy_(self, name, default, skip)
def bstack11llllll1l_opy_(item, when):
  global bstack11lll1llll_opy_
  try:
    bstack11lll1llll_opy_(item, when)
  except Exception as e:
    pass
def bstack1l11ll11ll_opy_():
  return
def bstack1l11l1lll_opy_(type, name, status, reason, bstack1l1l1l1l1_opy_, bstack11l1l1ll1_opy_):
  bstack1l111l1l1_opy_ = {
    bstack1l1111l_opy_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࠧ൭"): type,
    bstack1l1111l_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ൮"): {}
  }
  if type == bstack1l1111l_opy_ (u"ࠩࡤࡲࡳࡵࡴࡢࡶࡨࠫ൯"):
    bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭൰")][bstack1l1111l_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪ൱")] = bstack1l1l1l1l1_opy_
    bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ൲")][bstack1l1111l_opy_ (u"࠭ࡤࡢࡶࡤࠫ൳")] = json.dumps(str(bstack11l1l1ll1_opy_))
  if type == bstack1l1111l_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ൴"):
    bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ൵")][bstack1l1111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ൶")] = name
  if type == bstack1l1111l_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸ࠭൷"):
    bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧ൸")][bstack1l1111l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ൹")] = status
    if status == bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ൺ"):
      bstack1l111l1l1_opy_[bstack1l1111l_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪൻ")][bstack1l1111l_opy_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨർ")] = json.dumps(str(reason))
  bstack1l1l1l1111_opy_ = bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠧൽ").format(json.dumps(bstack1l111l1l1_opy_))
  return bstack1l1l1l1111_opy_
def bstack1l1ll111l1_opy_(driver_command, response):
    if driver_command == bstack1l1111l_opy_ (u"ࠪࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࠧൾ"):
        bstack1l11l1l1_opy_.bstack1l1l1l1l11_opy_({
            bstack1l1111l_opy_ (u"ࠫ࡮ࡳࡡࡨࡧࠪൿ"): response[bstack1l1111l_opy_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ඀")],
            bstack1l1111l_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ඁ"): bstack1l11l1l1_opy_.current_test_uuid()
        })
def bstack11ll1llll1_opy_(item, call, rep):
  global bstack11llll1ll1_opy_
  global bstack11llll1ll_opy_
  global bstack11l1ll111_opy_
  name = bstack1l1111l_opy_ (u"ࠧࠨං")
  try:
    if rep.when == bstack1l1111l_opy_ (u"ࠨࡥࡤࡰࡱ࠭ඃ"):
      bstack11lll1ll1l_opy_ = threading.current_thread().bstackSessionId
      try:
        if not bstack11l1ll111_opy_:
          name = str(rep.nodeid)
          bstack1l11l1l1l_opy_ = bstack1l11l1lll_opy_(bstack1l1111l_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ඄"), name, bstack1l1111l_opy_ (u"ࠪࠫඅ"), bstack1l1111l_opy_ (u"ࠫࠬආ"), bstack1l1111l_opy_ (u"ࠬ࠭ඇ"), bstack1l1111l_opy_ (u"࠭ࠧඈ"))
          threading.current_thread().bstack11l11ll111_opy_ = name
          for driver in bstack11llll1ll_opy_:
            if bstack11lll1ll1l_opy_ == driver.session_id:
              driver.execute_script(bstack1l11l1l1l_opy_)
      except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧඉ").format(str(e)))
      try:
        bstack1l111l11l_opy_(rep.outcome.lower())
        if rep.outcome.lower() != bstack1l1111l_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩඊ"):
          status = bstack1l1111l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩඋ") if rep.outcome.lower() == bstack1l1111l_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪඌ") else bstack1l1111l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫඍ")
          reason = bstack1l1111l_opy_ (u"ࠬ࠭ඎ")
          if status == bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ඏ"):
            reason = rep.longrepr.reprcrash.message
            if (not threading.current_thread().bstackTestErrorMessages):
              threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(reason)
          level = bstack1l1111l_opy_ (u"ࠧࡪࡰࡩࡳࠬඐ") if status == bstack1l1111l_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨඑ") else bstack1l1111l_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨඒ")
          data = name + bstack1l1111l_opy_ (u"ࠪࠤࡵࡧࡳࡴࡧࡧࠥࠬඓ") if status == bstack1l1111l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫඔ") else name + bstack1l1111l_opy_ (u"ࠬࠦࡦࡢ࡫࡯ࡩࡩࠧࠠࠨඕ") + reason
          bstack1111l1111_opy_ = bstack1l11l1lll_opy_(bstack1l1111l_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨඖ"), bstack1l1111l_opy_ (u"ࠧࠨ඗"), bstack1l1111l_opy_ (u"ࠨࠩ඘"), bstack1l1111l_opy_ (u"ࠩࠪ඙"), level, data)
          for driver in bstack11llll1ll_opy_:
            if bstack11lll1ll1l_opy_ == driver.session_id:
              driver.execute_script(bstack1111l1111_opy_)
      except Exception as e:
        logger.debug(bstack1l1111l_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡤࡱࡱࡸࡪࡾࡴࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧක").format(str(e)))
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡶࡤࡸࡪࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡦࡵࡷࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࢁࡽࠨඛ").format(str(e)))
  bstack11llll1ll1_opy_(item, call, rep)
def bstack1ll1111l1l_opy_(driver, bstack11lll1l11_opy_, test=None):
  global bstack11ll1111l1_opy_
  if test != None:
    bstack1l1l11ll1l_opy_ = getattr(test, bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪග"), None)
    bstack1l1lllllll_opy_ = getattr(test, bstack1l1111l_opy_ (u"࠭ࡵࡶ࡫ࡧࠫඝ"), None)
    PercySDK.screenshot(driver, bstack11lll1l11_opy_, bstack1l1l11ll1l_opy_=bstack1l1l11ll1l_opy_, bstack1l1lllllll_opy_=bstack1l1lllllll_opy_, bstack1l1111l11_opy_=bstack11ll1111l1_opy_)
  else:
    PercySDK.screenshot(driver, bstack11lll1l11_opy_)
@measure(event_name=EVENTS.bstack1l1l111111_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11l1ll11ll_opy_(driver):
  if bstack1111lll11_opy_.bstack11l1l11lll_opy_() is True or bstack1111lll11_opy_.capturing() is True:
    return
  bstack1111lll11_opy_.bstack11ll111111_opy_()
  while not bstack1111lll11_opy_.bstack11l1l11lll_opy_():
    bstack1llllllll1_opy_ = bstack1111lll11_opy_.bstack1l1l1ll1ll_opy_()
    bstack1ll1111l1l_opy_(driver, bstack1llllllll1_opy_)
  bstack1111lll11_opy_.bstack1l11lll111_opy_()
def bstack11l1l11l1l_opy_(sequence, driver_command, response = None, bstack11ll11l1l1_opy_ = None, args = None):
    try:
      if sequence != bstack1l1111l_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫ࠧඞ"):
        return
      if percy.bstack1l1ll1l11l_opy_() == bstack1l1111l_opy_ (u"ࠣࡨࡤࡰࡸ࡫ࠢඟ"):
        return
      bstack1llllllll1_opy_ = bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠩࡳࡩࡷࡩࡹࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬච"), None)
      for command in bstack1lllll11l_opy_:
        if command == driver_command:
          for driver in bstack11llll1ll_opy_:
            bstack11l1ll11ll_opy_(driver)
      bstack11llll1111_opy_ = percy.bstack111lll11ll_opy_()
      if driver_command in bstack1111lllll_opy_[bstack11llll1111_opy_]:
        bstack1111lll11_opy_.bstack1ll1l1ll11_opy_(bstack1llllllll1_opy_, driver_command)
    except Exception as e:
      pass
@measure(event_name=EVENTS.bstack11llll1l1l_opy_, stage=STAGE.bstack111111lll_opy_)
def bstack11lll11l1_opy_(framework_name):
  if bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡢࡱࡴࡪ࡟ࡤࡣ࡯ࡰࡪࡪࠧඡ")):
      return
  bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡲࡵࡤࡠࡥࡤࡰࡱ࡫ࡤࠨජ"), True)
  global bstack11ll111ll1_opy_
  global bstack1lllll1ll1_opy_
  global bstack1lll11lll1_opy_
  bstack11ll111ll1_opy_ = framework_name
  logger.info(bstack1lll11111l_opy_.format(bstack11ll111ll1_opy_.split(bstack1l1111l_opy_ (u"ࠬ࠳ࠧඣ"))[0]))
  bstack1l1lll1111_opy_()
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack1ll1111lll_opy_:
      Service.start = bstack111ll1l11_opy_
      Service.stop = bstack1l1l11ll11_opy_
      webdriver.Remote.get = bstack1ll1ll1l1l_opy_
      WebDriver.close = bstack1llll111l1_opy_
      WebDriver.quit = bstack1ll1l11l11_opy_
      webdriver.Remote.__init__ = bstack1lll1l1111_opy_
      WebDriver.getAccessibilityResults = getAccessibilityResults
      WebDriver.get_accessibility_results = getAccessibilityResults
      WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
      WebDriver.get_accessibility_results_summary = getAccessibilityResultsSummary
      WebDriver.performScan = perform_scan
      WebDriver.perform_scan = perform_scan
    if not bstack1ll1111lll_opy_:
        webdriver.Remote.__init__ = bstack1ll1ll1lll_opy_
    WebDriver.execute = bstack1ll11ll1l_opy_
    bstack1lllll1ll1_opy_ = True
  except Exception as e:
    pass
  try:
    if bstack1ll1111lll_opy_:
      from QWeb.keywords import browser
      browser.close_browser = bstack11l1l1l11_opy_
  except Exception as e:
    pass
  bstack11lllll1ll_opy_()
  if not bstack1lllll1ll1_opy_:
    bstack11ll1ll1l1_opy_(bstack1l1111l_opy_ (u"ࠨࡐࡢࡥ࡮ࡥ࡬࡫ࡳࠡࡰࡲࡸࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠣඤ"), bstack1l1llll1l_opy_)
  if bstack11ll11lll1_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      RemoteConnection._11l11l1lll_opy_ = bstack111l111ll_opy_
    except Exception as e:
      logger.error(bstack11l1l11l11_opy_.format(str(e)))
  if bstack1l11l11l1l_opy_():
    bstack1ll11l1l1l_opy_(CONFIG, logger)
  if (bstack1l1111l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ඥ") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        if percy.bstack1l1ll1l11l_opy_() == bstack1l1111l_opy_ (u"ࠣࡶࡵࡹࡪࠨඦ"):
          bstack1ll1l1l11l_opy_(bstack11l1l11l1l_opy_)
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack111ll1l1l_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1l111l11ll_opy_
      except Exception as e:
        logger.warn(bstack1ll1lll11_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack1lll11lll_opy_
      except Exception as e:
        logger.debug(bstack1lll11l11_opy_ + str(e))
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1ll1lll11_opy_)
    Output.start_test = bstack1llll11111_opy_
    Output.end_test = bstack11ll1lll11_opy_
    TestStatus.__init__ = bstack11ll1ll1ll_opy_
    QueueItem.__init__ = bstack11l1lllll1_opy_
    pabot._create_items = bstack11l11ll1l1_opy_
    try:
      from pabot import __version__ as bstack1l11l1111l_opy_
      if version.parse(bstack1l11l1111l_opy_) >= version.parse(bstack1l1111l_opy_ (u"ࠩ࠵࠲࠶࠻࠮࠱ࠩට")):
        pabot._run = bstack1111ll11l_opy_
      elif version.parse(bstack1l11l1111l_opy_) >= version.parse(bstack1l1111l_opy_ (u"ࠪ࠶࠳࠷࠳࠯࠲ࠪඨ")):
        pabot._run = bstack1111l111l_opy_
      else:
        pabot._run = bstack1ll1l1l111_opy_
    except Exception as e:
      pabot._run = bstack1ll1l1l111_opy_
    pabot._create_command_for_execution = bstack1llll1l11l_opy_
    pabot._report_results = bstack11111l1l1_opy_
  if bstack1l1111l_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨࠫඩ") in str(framework_name).lower():
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1l1l11lll1_opy_)
    Runner.run_hook = bstack1ll11lllll_opy_
    Step.run = bstack1lll1l1l1_opy_
  if bstack1l1111l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬඪ") in str(framework_name).lower():
    if not bstack1ll1111lll_opy_:
      return
    try:
      if percy.bstack1l1ll1l11l_opy_() == bstack1l1111l_opy_ (u"ࠨࡴࡳࡷࡨࠦණ"):
          bstack1ll1l1l11l_opy_(bstack11l1l11l1l_opy_)
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack1ll1l11ll_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack1l11ll11ll_opy_
      Config.getoption = bstack1l1lllll1_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack11ll1llll1_opy_
    except Exception as e:
      pass
def bstack11l1l111l1_opy_():
  global CONFIG
  if bstack1l1111l_opy_ (u"ࠧࡱࡣࡵࡥࡱࡲࡥ࡭ࡵࡓࡩࡷࡖ࡬ࡢࡶࡩࡳࡷࡳࠧඬ") in CONFIG and int(CONFIG[bstack1l1111l_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨත")]) > 1:
    logger.warn(bstack1l11l11lll_opy_)
def bstack1lll1l1l11_opy_(arg, bstack11111lll_opy_, bstack1ll111l111_opy_=None):
  global CONFIG
  global bstack11l11l111l_opy_
  global bstack11l1lll1l_opy_
  global bstack1ll1111lll_opy_
  global bstack11l11l11_opy_
  bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩථ")
  if bstack11111lll_opy_ and isinstance(bstack11111lll_opy_, str):
    bstack11111lll_opy_ = eval(bstack11111lll_opy_)
  CONFIG = bstack11111lll_opy_[bstack1l1111l_opy_ (u"ࠪࡇࡔࡔࡆࡊࡉࠪද")]
  bstack11l11l111l_opy_ = bstack11111lll_opy_[bstack1l1111l_opy_ (u"ࠫࡍ࡛ࡂࡠࡗࡕࡐࠬධ")]
  bstack11l1lll1l_opy_ = bstack11111lll_opy_[bstack1l1111l_opy_ (u"ࠬࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧන")]
  bstack1ll1111lll_opy_ = bstack11111lll_opy_[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩ඲")]
  bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨඳ"), bstack1ll1111lll_opy_)
  os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠪප")] = bstack11ll11l1l_opy_
  os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࠨඵ")] = json.dumps(CONFIG)
  os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡋ࡙ࡇࡥࡕࡓࡎࠪබ")] = bstack11l11l111l_opy_
  os.environ[bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬභ")] = str(bstack11l1lll1l_opy_)
  os.environ[bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕ࡟ࡔࡆࡕࡗࡣࡕࡒࡕࡈࡋࡑࠫම")] = str(True)
  if bstack1lll111l11_opy_(arg, [bstack1l1111l_opy_ (u"࠭࠭࡯ࠩඹ"), bstack1l1111l_opy_ (u"ࠧ࠮࠯ࡱࡹࡲࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠨය")]) != -1:
    os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑ࡛ࡗࡉࡘ࡚࡟ࡑࡃࡕࡅࡑࡒࡅࡍࠩර")] = str(True)
  if len(sys.argv) <= 1:
    logger.critical(bstack1l111ll1ll_opy_)
    return
  bstack1ll111l11_opy_()
  global bstack111lll111_opy_
  global bstack11ll1111l1_opy_
  global bstack111111ll1_opy_
  global bstack11l1l1lll_opy_
  global bstack11lllll11l_opy_
  global bstack1lll11lll1_opy_
  global bstack1l1ll1ll1l_opy_
  arg.append(bstack1l1111l_opy_ (u"ࠤ࠰࡛ࠧ඼"))
  arg.append(bstack1l1111l_opy_ (u"ࠥ࡭࡬ࡴ࡯ࡳࡧ࠽ࡑࡴࡪࡵ࡭ࡧࠣࡥࡱࡸࡥࡢࡦࡼࠤ࡮ࡳࡰࡰࡴࡷࡩࡩࡀࡰࡺࡶࡨࡷࡹ࠴ࡐࡺࡶࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬ࠨල"))
  arg.append(bstack1l1111l_opy_ (u"ࠦ࠲࡝ࠢ඾"))
  arg.append(bstack1l1111l_opy_ (u"ࠧ࡯ࡧ࡯ࡱࡵࡩ࠿࡚ࡨࡦࠢ࡫ࡳࡴࡱࡩ࡮ࡲ࡯ࠦ඿"))
  global bstack1ll1ll111_opy_
  global bstack1l111l1lll_opy_
  global bstack1ll1l1lll_opy_
  global bstack11l1l1l11l_opy_
  global bstack1lll1ll1l_opy_
  global bstack1111l1lll_opy_
  global bstack1lll11l11l_opy_
  global bstack1ll1111111_opy_
  global bstack1ll11ll1ll_opy_
  global bstack111ll11l1_opy_
  global bstack11lll11l1l_opy_
  global bstack11lll1llll_opy_
  global bstack11llll1ll1_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1ll1ll111_opy_ = webdriver.Remote.__init__
    bstack1l111l1lll_opy_ = WebDriver.quit
    bstack1ll1111111_opy_ = WebDriver.close
    bstack1ll11ll1ll_opy_ = WebDriver.get
    bstack1ll1l1lll_opy_ = WebDriver.execute
  except Exception as e:
    pass
  if bstack1l1llll111_opy_(CONFIG) and bstack11ll1llll_opy_():
    if bstack1ll11llll1_opy_() < version.parse(bstack1lll111ll_opy_):
      logger.error(bstack1ll11111ll_opy_.format(bstack1ll11llll1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack111ll11l1_opy_ = RemoteConnection._11l11l1lll_opy_
      except Exception as e:
        logger.error(bstack11l1l11l11_opy_.format(str(e)))
  try:
    from _pytest.config import Config
    bstack11lll11l1l_opy_ = Config.getoption
    from _pytest import runner
    bstack11lll1llll_opy_ = runner._update_current_test_var
  except Exception as e:
    logger.warn(e, bstack111lllll_opy_)
  try:
    from pytest_bdd import reporting
    bstack11llll1ll1_opy_ = reporting.runtest_makereport
  except Exception as e:
    logger.debug(bstack1l1111l_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡩ࡯ࡵࡷࡥࡱࡲࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹࡵࠠࡳࡷࡱࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡶࡨࡷࡹࡹࠧව"))
  bstack111111ll1_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫශ"), {}).get(bstack1l1111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪෂ"))
  bstack1l1ll1ll1l_opy_ = True
  bstack11lll11l1_opy_(bstack1lll11ll11_opy_)
  os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡗࡖࡉࡗࡔࡁࡎࡇࠪස")] = CONFIG[bstack1l1111l_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬහ")]
  os.environ[bstack1l1111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅࡈࡉࡅࡔࡕࡢࡏࡊ࡟ࠧළ")] = CONFIG[bstack1l1111l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨෆ")]
  os.environ[bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩ෇")] = bstack1ll1111lll_opy_.__str__()
  from _pytest.config import main as bstack1ll1lllll_opy_
  bstack1l1111ll1l_opy_ = []
  try:
    bstack11ll111l1_opy_ = bstack1ll1lllll_opy_(arg)
    if bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡦࡴࡵࡳࡷࡥ࡬ࡪࡵࡷࠫ෈") in multiprocessing.current_process().__dict__.keys():
      for bstack11l111111l_opy_ in multiprocessing.current_process().bstack_error_list:
        bstack1l1111ll1l_opy_.append(bstack11l111111l_opy_)
    try:
      bstack11ll1111l_opy_ = (bstack1l1111ll1l_opy_, int(bstack11ll111l1_opy_))
      bstack1ll111l111_opy_.append(bstack11ll1111l_opy_)
    except:
      bstack1ll111l111_opy_.append((bstack1l1111ll1l_opy_, bstack11ll111l1_opy_))
  except Exception as e:
    logger.error(traceback.format_exc())
    bstack1l1111ll1l_opy_.append({bstack1l1111l_opy_ (u"ࠨࡰࡤࡱࡪ࠭෉"): bstack1l1111l_opy_ (u"ࠩࡓࡶࡴࡩࡥࡴࡵ්ࠣࠫ") + os.environ.get(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡎࡔࡄࡆ࡚ࠪ෋")), bstack1l1111l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪ෌"): traceback.format_exc(), bstack1l1111l_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ෍"): int(os.environ.get(bstack1l1111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖࡌࡂࡖࡉࡓࡗࡓ࡟ࡊࡐࡇࡉ࡝࠭෎")))})
    bstack1ll111l111_opy_.append((bstack1l1111ll1l_opy_, 1))
def bstack11l1ll11l_opy_(arg):
  global bstack111llll1ll_opy_
  bstack11lll11l1_opy_(bstack1l1l11l11l_opy_)
  os.environ[bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨා")] = str(bstack11l1lll1l_opy_)
  from behave.__main__ import main as bstack1ll11l1ll1_opy_
  status_code = bstack1ll11l1ll1_opy_(arg)
  if status_code != 0:
    bstack111llll1ll_opy_ = status_code
def bstack1lll1111ll_opy_():
  logger.info(bstack111lll1lll_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack1l1111l_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧැ"), help=bstack1l1111l_opy_ (u"ࠩࡊࡩࡳ࡫ࡲࡢࡶࡨࠤࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠣࡧࡴࡴࡦࡪࡩࠪෑ"))
  parser.add_argument(bstack1l1111l_opy_ (u"ࠪ࠱ࡺ࠭ි"), bstack1l1111l_opy_ (u"ࠫ࠲࠳ࡵࡴࡧࡵࡲࡦࡳࡥࠨී"), help=bstack1l1111l_opy_ (u"ࠬ࡟࡯ࡶࡴࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠢࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫු"))
  parser.add_argument(bstack1l1111l_opy_ (u"࠭࠭࡬ࠩ෕"), bstack1l1111l_opy_ (u"ࠧ࠮࠯࡮ࡩࡾ࠭ූ"), help=bstack1l1111l_opy_ (u"ࠨ࡛ࡲࡹࡷࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡧࡣࡤࡧࡶࡷࠥࡱࡥࡺࠩ෗"))
  parser.add_argument(bstack1l1111l_opy_ (u"ࠩ࠰ࡪࠬෘ"), bstack1l1111l_opy_ (u"ࠪ࠱࠲࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨෙ"), help=bstack1l1111l_opy_ (u"ࠫ࡞ࡵࡵࡳࠢࡷࡩࡸࡺࠠࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪේ"))
  bstack111llll1l_opy_ = parser.parse_args()
  try:
    bstack11l1l111l_opy_ = bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲࡬࡫࡮ࡦࡴ࡬ࡧ࠳ࡿ࡭࡭࠰ࡶࡥࡲࡶ࡬ࡦࠩෛ")
    if bstack111llll1l_opy_.framework and bstack111llll1l_opy_.framework not in (bstack1l1111l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭ො"), bstack1l1111l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴ࠳ࠨෝ")):
      bstack11l1l111l_opy_ = bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭࠱ࡽࡲࡲ࠮ࡴࡣࡰࡴࡱ࡫ࠧෞ")
    bstack111l1l1l1_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack11l1l111l_opy_)
    bstack11l1l1111_opy_ = open(bstack111l1l1l1_opy_, bstack1l1111l_opy_ (u"ࠩࡵࠫෟ"))
    bstack1lll11l1ll_opy_ = bstack11l1l1111_opy_.read()
    bstack11l1l1111_opy_.close()
    if bstack111llll1l_opy_.username:
      bstack1lll11l1ll_opy_ = bstack1lll11l1ll_opy_.replace(bstack1l1111l_opy_ (u"ࠪ࡝ࡔ࡛ࡒࡠࡗࡖࡉࡗࡔࡁࡎࡇࠪ෠"), bstack111llll1l_opy_.username)
    if bstack111llll1l_opy_.key:
      bstack1lll11l1ll_opy_ = bstack1lll11l1ll_opy_.replace(bstack1l1111l_opy_ (u"ࠫ࡞ࡕࡕࡓࡡࡄࡇࡈࡋࡓࡔࡡࡎࡉ࡞࠭෡"), bstack111llll1l_opy_.key)
    if bstack111llll1l_opy_.framework:
      bstack1lll11l1ll_opy_ = bstack1lll11l1ll_opy_.replace(bstack1l1111l_opy_ (u"ࠬ࡟ࡏࡖࡔࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐ࠭෢"), bstack111llll1l_opy_.framework)
    file_name = bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡿ࡭࡭ࠩ෣")
    file_path = os.path.abspath(file_name)
    bstack1lll111111_opy_ = open(file_path, bstack1l1111l_opy_ (u"ࠧࡸࠩ෤"))
    bstack1lll111111_opy_.write(bstack1lll11l1ll_opy_)
    bstack1lll111111_opy_.close()
    logger.info(bstack1l11llllll_opy_)
    try:
      os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠪ෥")] = bstack111llll1l_opy_.framework if bstack111llll1l_opy_.framework != None else bstack1l1111l_opy_ (u"ࠤࠥ෦")
      config = yaml.safe_load(bstack1lll11l1ll_opy_)
      config[bstack1l1111l_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪ෧")] = bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱ࠱ࡸ࡫ࡴࡶࡲࠪ෨")
      bstack1l1l11l1l1_opy_(bstack11lll1l1l_opy_, config)
    except Exception as e:
      logger.debug(bstack1111l11l1_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack11lll1l1l1_opy_.format(str(e)))
def bstack1l1l11l1l1_opy_(bstack11llllll11_opy_, config, bstack11l1ll1lll_opy_={}):
  global bstack1ll1111lll_opy_
  global bstack11l1llllll_opy_
  global bstack11l11l11_opy_
  if not config:
    return
  bstack1llll1l1l_opy_ = bstack1l1l11111l_opy_ if not bstack1ll1111lll_opy_ else (
    bstack1lll11l1l1_opy_ if bstack1l1111l_opy_ (u"ࠬࡧࡰࡱࠩ෩") in config else (
        bstack11l11lll11_opy_ if config.get(bstack1l1111l_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠪ෪")) else bstack1lll1l1ll1_opy_
    )
)
  bstack1l1l111l1_opy_ = False
  bstack1l11l1ll11_opy_ = False
  if bstack1ll1111lll_opy_ is True:
      if bstack1l1111l_opy_ (u"ࠧࡢࡲࡳࠫ෫") in config:
          bstack1l1l111l1_opy_ = True
      else:
          bstack1l11l1ll11_opy_ = True
  bstack111lll1l11_opy_ = bstack1lllllll1l_opy_.bstack1l1ll11l1l_opy_(config, bstack11l1llllll_opy_)
  data = {
    bstack1l1111l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪ෬"): config[bstack1l1111l_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ෭")],
    bstack1l1111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭෮"): config[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧ෯")],
    bstack1l1111l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ෰"): bstack11llllll11_opy_,
    bstack1l1111l_opy_ (u"࠭ࡤࡦࡶࡨࡧࡹ࡫ࡤࡇࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪ෱"): os.environ.get(bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩෲ"), bstack11l1llllll_opy_),
    bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠪෳ"): bstack1l1ll11ll_opy_,
    bstack1l1111l_opy_ (u"ࠩࡲࡴࡹ࡯࡭ࡢ࡮ࡢ࡬ࡺࡨ࡟ࡶࡴ࡯ࠫ෴"): bstack1ll11l1l11_opy_(),
    bstack1l1111l_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭෵"): {
      bstack1l1111l_opy_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ෶"): str(config[bstack1l1111l_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬ෷")]) if bstack1l1111l_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭෸") in config else bstack1l1111l_opy_ (u"ࠢࡶࡰ࡮ࡲࡴࡽ࡮ࠣ෹"),
      bstack1l1111l_opy_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧ࡙ࡩࡷࡹࡩࡰࡰࠪ෺"): sys.version,
      bstack1l1111l_opy_ (u"ࠩࡵࡩ࡫࡫ࡲࡳࡧࡵࠫ෻"): bstack1l1l11111_opy_(os.getenv(bstack1l1111l_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡉࡖࡆࡓࡅࡘࡑࡕࡏࠧ෼"), bstack1l1111l_opy_ (u"ࠦࠧ෽"))),
      bstack1l1111l_opy_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ෾"): bstack1l1111l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭෿"),
      bstack1l1111l_opy_ (u"ࠧࡱࡴࡲࡨࡺࡩࡴࠨ฀"): bstack1llll1l1l_opy_,
      bstack1l1111l_opy_ (u"ࠨࡲࡵࡳࡩࡻࡣࡵࡡࡰࡥࡵ࠭ก"): bstack111lll1l11_opy_,
      bstack1l1111l_opy_ (u"ࠩࡷࡩࡸࡺࡨࡶࡤࡢࡹࡺ࡯ࡤࠨข"): os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨฃ")],
      bstack1l1111l_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡖࡦࡴࡶ࡭ࡴࡴࠧค"): bstack1ll11l111_opy_(os.environ.get(bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧฅ"), bstack11l1llllll_opy_)),
      bstack1l1111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩฆ"): config[bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪง")] if config[bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫจ")] else bstack1l1111l_opy_ (u"ࠤࡸࡲࡰࡴ࡯ࡸࡰࠥฉ"),
      bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬช"): str(config[bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ซ")]) if bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧฌ") in config else bstack1l1111l_opy_ (u"ࠨࡵ࡯࡭ࡱࡳࡼࡴࠢญ"),
      bstack1l1111l_opy_ (u"ࠧࡰࡵࠪฎ"): sys.platform,
      bstack1l1111l_opy_ (u"ࠨࡪࡲࡷࡹࡴࡡ࡮ࡧࠪฏ"): socket.gethostname(),
      bstack1l1111l_opy_ (u"ࠩࡶࡨࡰࡘࡵ࡯ࡋࡧࠫฐ"): bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠪࡷࡩࡱࡒࡶࡰࡌࡨࠬฑ"))
    }
  }
  if not bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠫࡸࡪ࡫ࡌ࡫࡯ࡰࡘ࡯ࡧ࡯ࡣ࡯ࠫฒ")) is None:
    data[bstack1l1111l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨณ")][bstack1l1111l_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩด")] = {
      bstack1l1111l_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧต"): bstack1l1111l_opy_ (u"ࠨࡷࡶࡩࡷࡥ࡫ࡪ࡮࡯ࡩࡩ࠭ถ"),
      bstack1l1111l_opy_ (u"ࠩࡶ࡭࡬ࡴࡡ࡭ࠩท"): bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠪࡷࡩࡱࡋࡪ࡮࡯ࡗ࡮࡭࡮ࡢ࡮ࠪธ")),
      bstack1l1111l_opy_ (u"ࠫࡸ࡯ࡧ࡯ࡣ࡯ࡒࡺࡳࡢࡦࡴࠪน"): bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠬࡹࡤ࡬ࡍ࡬ࡰࡱࡔ࡯ࠨบ"))
    }
  if bstack11llllll11_opy_ == bstack1l11ll1111_opy_:
    data[bstack1l1111l_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩป")][bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡉ࡯࡯ࡨ࡬࡫ࠬผ")] = bstack1l1l1ll1l_opy_(config)
    data[bstack1l1111l_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫฝ")][bstack1l1111l_opy_ (u"ࠩ࡬ࡷࡕ࡫ࡲࡤࡻࡄࡹࡹࡵࡅ࡯ࡣࡥࡰࡪࡪࠧพ")] = percy.bstack1l11ll11l1_opy_
    data[bstack1l1111l_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ฟ")][bstack1l1111l_opy_ (u"ࠫࡵ࡫ࡲࡤࡻࡅࡹ࡮ࡲࡤࡊࡦࠪภ")] = percy.bstack1ll1l1ll1_opy_
  update(data[bstack1l1111l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨม")], bstack11l1ll1lll_opy_)
  try:
    response = bstack1ll1l11111_opy_(bstack1l1111l_opy_ (u"࠭ࡐࡐࡕࡗࠫย"), bstack111l1l1ll_opy_(bstack1l1lll1l1l_opy_), data, {
      bstack1l1111l_opy_ (u"ࠧࡢࡷࡷ࡬ࠬร"): (config[bstack1l1111l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪฤ")], config[bstack1l1111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬล")])
    })
    if response:
      logger.debug(bstack1ll11l1l1_opy_.format(bstack11llllll11_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack111ll1llll_opy_.format(str(e)))
def bstack1l1l11111_opy_(framework):
  return bstack1l1111l_opy_ (u"ࠥࡿࢂ࠳ࡰࡺࡶ࡫ࡳࡳࡧࡧࡦࡰࡷ࠳ࢀࢃࠢฦ").format(str(framework), __version__) if framework else bstack1l1111l_opy_ (u"ࠦࡵࡿࡴࡩࡱࡱࡥ࡬࡫࡮ࡵ࠱ࡾࢁࠧว").format(
    __version__)
def bstack1ll111l11_opy_():
  global CONFIG
  global bstack1l1l1lllll_opy_
  if bool(CONFIG):
    return
  try:
    bstack1ll11111l_opy_()
    logger.debug(bstack111l111l1_opy_.format(str(CONFIG)))
    bstack1l1l1lllll_opy_ = bstack11lll111ll_opy_.bstack1lllll1lll_opy_(CONFIG, bstack1l1l1lllll_opy_)
    bstack1l1lll1111_opy_()
  except Exception as e:
    logger.error(bstack1l1111l_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡸࡺࡶࠬࠡࡧࡵࡶࡴࡸ࠺ࠡࠤศ") + str(e))
    sys.exit(1)
  sys.excepthook = bstack11l1l1l1l1_opy_
  atexit.register(bstack11lll1lll_opy_)
  signal.signal(signal.SIGINT, bstack1l1111l11l_opy_)
  signal.signal(signal.SIGTERM, bstack1l1111l11l_opy_)
def bstack11l1l1l1l1_opy_(exctype, value, traceback):
  global bstack11llll1ll_opy_
  try:
    for driver in bstack11llll1ll_opy_:
      bstack11ll1111ll_opy_(driver, bstack1l1111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ษ"), bstack1l1111l_opy_ (u"ࠢࡔࡧࡶࡷ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡹ࡬ࡸ࡭ࡀࠠ࡝ࡰࠥส") + str(value))
  except Exception:
    pass
  bstack1ll111lll_opy_(value, True)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack1ll111lll_opy_(message=bstack1l1111l_opy_ (u"ࠨࠩห"), bstack1ll11l111l_opy_ = False):
  global CONFIG
  bstack1ll1ll11l1_opy_ = bstack1l1111l_opy_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࡇࡻࡧࡪࡶࡴࡪࡱࡱࠫฬ") if bstack1ll11l111l_opy_ else bstack1l1111l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩอ")
  try:
    if message:
      bstack11l1ll1lll_opy_ = {
        bstack1ll1ll11l1_opy_ : str(message)
      }
      bstack1l1l11l1l1_opy_(bstack1l11ll1111_opy_, CONFIG, bstack11l1ll1lll_opy_)
    else:
      bstack1l1l11l1l1_opy_(bstack1l11ll1111_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack1l111lll11_opy_.format(str(e)))
def bstack11l11ll11l_opy_(bstack1111l11ll_opy_, size):
  bstack1l11ll1l1_opy_ = []
  while len(bstack1111l11ll_opy_) > size:
    bstack11l11l11l_opy_ = bstack1111l11ll_opy_[:size]
    bstack1l11ll1l1_opy_.append(bstack11l11l11l_opy_)
    bstack1111l11ll_opy_ = bstack1111l11ll_opy_[size:]
  bstack1l11ll1l1_opy_.append(bstack1111l11ll_opy_)
  return bstack1l11ll1l1_opy_
def bstack11l11ll1ll_opy_(args):
  if bstack1l1111l_opy_ (u"ࠫ࠲ࡳࠧฮ") in args and bstack1l1111l_opy_ (u"ࠬࡶࡤࡣࠩฯ") in args:
    return True
  return False
def run_on_browserstack(bstack11l111l1l_opy_=None, bstack1ll111l111_opy_=None, bstack1ll11llll_opy_=False):
  global CONFIG
  global bstack11l11l111l_opy_
  global bstack11l1lll1l_opy_
  global bstack11l1llllll_opy_
  global bstack11l11l11_opy_
  bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"࠭ࠧะ")
  bstack11l1lll11_opy_(bstack11lll1lll1_opy_, logger)
  if bstack11l111l1l_opy_ and isinstance(bstack11l111l1l_opy_, str):
    bstack11l111l1l_opy_ = eval(bstack11l111l1l_opy_)
  if bstack11l111l1l_opy_:
    CONFIG = bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠧࡄࡑࡑࡊࡎࡍࠧั")]
    bstack11l11l111l_opy_ = bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠨࡊࡘࡆࡤ࡛ࡒࡍࠩา")]
    bstack11l1lll1l_opy_ = bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠩࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫำ")]
    bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠪࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬิ"), bstack11l1lll1l_opy_)
    bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫี")
  bstack11l11l11_opy_.set_property(bstack1l1111l_opy_ (u"ࠬࡹࡤ࡬ࡔࡸࡲࡎࡪࠧึ"), uuid4().__str__())
  logger.debug(bstack1l1111l_opy_ (u"࠭ࡳࡥ࡭ࡕࡹࡳࡏࡤ࠾ࠩื") + bstack11l11l11_opy_.get_property(bstack1l1111l_opy_ (u"ࠧࡴࡦ࡮ࡖࡺࡴࡉࡥุࠩ")))
  if not bstack1ll11llll_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack1l111ll1ll_opy_)
      return
    if sys.argv[1] == bstack1l1111l_opy_ (u"ࠨ࠯࠰ࡺࡪࡸࡳࡪࡱࡱูࠫ") or sys.argv[1] == bstack1l1111l_opy_ (u"ࠩ࠰ࡺฺࠬ"):
      logger.info(bstack1l1111l_opy_ (u"ࠪࡆࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠢࡓࡽࡹ࡮࡯࡯ࠢࡖࡈࡐࠦࡶࡼࡿࠪ฻").format(__version__))
      return
    if sys.argv[1] == bstack1l1111l_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪ฼"):
      bstack1lll1111ll_opy_()
      return
  args = sys.argv
  bstack1ll111l11_opy_()
  global bstack111lll111_opy_
  global bstack1l1llllll1_opy_
  global bstack1l1ll1ll1l_opy_
  global bstack1llll1lll_opy_
  global bstack11ll1111l1_opy_
  global bstack111111ll1_opy_
  global bstack11l1l1lll_opy_
  global bstack11ll1lll1l_opy_
  global bstack11lllll11l_opy_
  global bstack1lll11lll1_opy_
  global bstack1l11lllll1_opy_
  bstack1l1llllll1_opy_ = len(CONFIG.get(bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ฽"), []))
  if not bstack11ll11l1l_opy_:
    if args[1] == bstack1l1111l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭฾") or args[1] == bstack1l1111l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴ࠳ࠨ฿"):
      bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨเ")
      args = args[2:]
    elif args[1] == bstack1l1111l_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨแ"):
      bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩโ")
      args = args[2:]
    elif args[1] == bstack1l1111l_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪใ"):
      bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫไ")
      args = args[2:]
    elif args[1] == bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧๅ"):
      bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠨๆ")
      args = args[2:]
    elif args[1] == bstack1l1111l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ็"):
      bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵ่ࠩ")
      args = args[2:]
    elif args[1] == bstack1l1111l_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧ้ࠪ"):
      bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨ๊ࠫ")
      args = args[2:]
    else:
      if not bstack1l1111l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨ๋") in CONFIG or str(CONFIG[bstack1l1111l_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ์")]).lower() in [bstack1l1111l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧํ"), bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮࠴ࠩ๎")]:
        bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ๏")
        args = args[1:]
      elif str(CONFIG[bstack1l1111l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭๐")]).lower() == bstack1l1111l_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪ๑"):
        bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ๒")
        args = args[1:]
      elif str(CONFIG[bstack1l1111l_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ๓")]).lower() == bstack1l1111l_opy_ (u"ࠧࡱࡣࡥࡳࡹ࠭๔"):
        bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠨࡲࡤࡦࡴࡺࠧ๕")
        args = args[1:]
      elif str(CONFIG[bstack1l1111l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ๖")]).lower() == bstack1l1111l_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪ๗"):
        bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫ๘")
        args = args[1:]
      elif str(CONFIG[bstack1l1111l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨ๙")]).lower() == bstack1l1111l_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭๚"):
        bstack11ll11l1l_opy_ = bstack1l1111l_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ๛")
        args = args[1:]
      else:
        os.environ[bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠪ๜")] = bstack11ll11l1l_opy_
        bstack11ll1l1ll1_opy_(bstack11l111l11_opy_)
  os.environ[bstack1l1111l_opy_ (u"ࠩࡉࡖࡆࡓࡅࡘࡑࡕࡏࡤ࡛ࡓࡆࡆࠪ๝")] = bstack11ll11l1l_opy_
  bstack11l1llllll_opy_ = bstack11ll11l1l_opy_
  global bstack11lllllll_opy_
  global bstack11l1l11l1_opy_
  if bstack11l111l1l_opy_:
    try:
      os.environ[bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡉࡖࡆࡓࡅࡘࡑࡕࡏࠬ๞")] = bstack11ll11l1l_opy_
      bstack1l1l11l1l1_opy_(bstack11l1ll1ll1_opy_, CONFIG)
    except Exception as e:
      logger.debug(bstack1ll1l111l_opy_.format(str(e)))
  global bstack1ll1ll111_opy_
  global bstack1l111l1lll_opy_
  global bstack1ll1l1l1l1_opy_
  global bstack1l11l11ll1_opy_
  global bstack11ll1ll11_opy_
  global bstack1l1ll1111_opy_
  global bstack11l1l1l11l_opy_
  global bstack1lll1ll1l_opy_
  global bstack1l1l1l1ll_opy_
  global bstack1111l1lll_opy_
  global bstack1lll11l11l_opy_
  global bstack1ll1111111_opy_
  global bstack1l11ll11l_opy_
  global bstack1ll1l1l1ll_opy_
  global bstack1ll11ll1ll_opy_
  global bstack111ll11l1_opy_
  global bstack11lll11l1l_opy_
  global bstack11lll1llll_opy_
  global bstack11l1llll11_opy_
  global bstack11llll1ll1_opy_
  global bstack1ll1l1lll_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1ll1ll111_opy_ = webdriver.Remote.__init__
    bstack1l111l1lll_opy_ = WebDriver.quit
    bstack1ll1111111_opy_ = WebDriver.close
    bstack1ll11ll1ll_opy_ = WebDriver.get
    bstack1ll1l1lll_opy_ = WebDriver.execute
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack11lllllll_opy_ = Popen.__init__
  except Exception as e:
    pass
  try:
    from bstack_utils.helper import bstack111lll11l_opy_
    bstack11l1l11l1_opy_ = bstack111lll11l_opy_()
  except Exception as e:
    pass
  try:
    global bstack1l11l1ll1_opy_
    from QWeb.keywords import browser
    bstack1l11l1ll1_opy_ = browser.close_browser
  except Exception as e:
    pass
  if bstack1l1llll111_opy_(CONFIG) and bstack11ll1llll_opy_():
    if bstack1ll11llll1_opy_() < version.parse(bstack1lll111ll_opy_):
      logger.error(bstack1ll11111ll_opy_.format(bstack1ll11llll1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack111ll11l1_opy_ = RemoteConnection._11l11l1lll_opy_
      except Exception as e:
        logger.error(bstack11l1l11l11_opy_.format(str(e)))
  if not CONFIG.get(bstack1l1111l_opy_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡆࡻࡴࡰࡅࡤࡴࡹࡻࡲࡦࡎࡲ࡫ࡸ࠭๟"), False) and not bstack11l111l1l_opy_:
    logger.info(bstack11ll111l11_opy_)
  if bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩ๠") in CONFIG and str(CONFIG[bstack1l1111l_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠪ๡")]).lower() != bstack1l1111l_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭๢"):
    bstack1111l1l11_opy_()
  elif bstack11ll11l1l_opy_ != bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ๣") or (bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ๤") and not bstack11l111l1l_opy_):
    bstack1llll1l1ll_opy_()
  if (bstack11ll11l1l_opy_ in [bstack1l1111l_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩ๥"), bstack1l1111l_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪ๦"), bstack1l1111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭๧")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack111ll1l1l_opy_
        bstack1l1ll1111_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack1ll1lll11_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack11ll1ll11_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack1lll11l11_opy_ + str(e))
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1ll1lll11_opy_)
    if bstack11ll11l1l_opy_ != bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧ๨"):
      bstack11l1l11111_opy_()
    bstack1ll1l1l1l1_opy_ = Output.start_test
    bstack1l11l11ll1_opy_ = Output.end_test
    bstack11l1l1l11l_opy_ = TestStatus.__init__
    bstack1l1l1l1ll_opy_ = pabot._run
    bstack1111l1lll_opy_ = QueueItem.__init__
    bstack1lll11l11l_opy_ = pabot._create_command_for_execution
    bstack11l1llll11_opy_ = pabot._report_results
  if bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ๩"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1l1l11lll1_opy_)
    bstack1l11ll11l_opy_ = Runner.run_hook
    bstack1ll1l1l1ll_opy_ = Step.run
  if bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ๪"):
    try:
      from _pytest.config import Config
      bstack11lll11l1l_opy_ = Config.getoption
      from _pytest import runner
      bstack11lll1llll_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack111lllll_opy_)
    try:
      from pytest_bdd import reporting
      bstack11llll1ll1_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡱࠣࡶࡺࡴࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹ࡫ࡳࡵࡵࠪ๫"))
  try:
    framework_name = bstack1l1111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ๬") if bstack11ll11l1l_opy_ in [bstack1l1111l_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪ๭"), bstack1l1111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ๮"), bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧ๯")] else bstack1l1ll1l1l_opy_(bstack11ll11l1l_opy_)
    bstack1lll1lll11_opy_ = {
      bstack1l1111l_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡲࡦࡳࡥࠨ๰"): bstack1l1111l_opy_ (u"ࠨࡽ࠳ࢁ࠲ࡩࡵࡤࡷࡰࡦࡪࡸࠧ๱").format(framework_name) if bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ๲") and bstack1llll1ll1_opy_() else framework_name,
      bstack1l1111l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ๳"): bstack1ll11l111_opy_(framework_name),
      bstack1l1111l_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ๴"): __version__,
      bstack1l1111l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡷࡶࡩࡩ࠭๵"): bstack11ll11l1l_opy_
    }
    if bstack11ll11l1l_opy_ in bstack11111111l_opy_:
      if bstack1ll1111lll_opy_ and bstack1l1111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭๶") in CONFIG and CONFIG[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧ๷")] == True:
        if bstack1l1111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨ๸") in CONFIG:
          os.environ[bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡥࡁࡄࡅࡈࡗࡘࡏࡂࡊࡎࡌࡘ࡞ࡥࡃࡐࡐࡉࡍࡌ࡛ࡒࡂࡖࡌࡓࡓࡥ࡙ࡎࡎࠪ๹")] = os.getenv(bstack1l1111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫ๺"), json.dumps(CONFIG[bstack1l1111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫ๻")]))
          CONFIG[bstack1l1111l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬ๼")].pop(bstack1l1111l_opy_ (u"࠭ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫ๽"), None)
          CONFIG[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧ๾")].pop(bstack1l1111l_opy_ (u"ࠨࡧࡻࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭๿"), None)
        bstack1lll1lll11_opy_[bstack1l1111l_opy_ (u"ࠩࡷࡩࡸࡺࡆࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ຀")] = {
          bstack1l1111l_opy_ (u"ࠪࡲࡦࡳࡥࠨກ"): bstack1l1111l_opy_ (u"ࠫࡸ࡫࡬ࡦࡰ࡬ࡹࡲ࠭ຂ"),
          bstack1l1111l_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭຃"): str(bstack1ll11llll1_opy_())
        }
    if bstack11ll11l1l_opy_ not in [bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧຄ")]:
      bstack1lllllll11_opy_ = bstack1l11l1l1_opy_.launch(CONFIG, bstack1lll1lll11_opy_)
  except Exception as e:
    logger.debug(bstack1ll1ll11l_opy_.format(bstack1l1111l_opy_ (u"ࠧࡕࡧࡶࡸࡍࡻࡢࠨ຅"), str(e)))
  if bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨຆ"):
    bstack1l1ll1ll1l_opy_ = True
    if bstack11l111l1l_opy_ and bstack1ll11llll_opy_:
      bstack111111ll1_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ງ"), {}).get(bstack1l1111l_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬຈ"))
      bstack11lll11l1_opy_(bstack1l11llll11_opy_)
    elif bstack11l111l1l_opy_:
      bstack111111ll1_opy_ = CONFIG.get(bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨຉ"), {}).get(bstack1l1111l_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧຊ"))
      global bstack11llll1ll_opy_
      try:
        if bstack11l11ll1ll_opy_(bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ຋")]) and multiprocessing.current_process().name == bstack1l1111l_opy_ (u"ࠧ࠱ࠩຌ"):
          bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫຍ")].remove(bstack1l1111l_opy_ (u"ࠩ࠰ࡱࠬຎ"))
          bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ຏ")].remove(bstack1l1111l_opy_ (u"ࠫࡵࡪࡢࠨຐ"))
          bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨຑ")] = bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩຒ")][0]
          with open(bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪຓ")], bstack1l1111l_opy_ (u"ࠨࡴࠪດ")) as f:
            file_content = f.read()
          bstack1lll111ll1_opy_ = bstack1l1111l_opy_ (u"ࠤࠥࠦ࡫ࡸ࡯࡮ࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡵࡧ࡯ࠥ࡯࡭ࡱࡱࡵࡸࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣ࡮ࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡥ࠼ࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠ࡫ࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡩ࠭ࢁࡽࠪ࠽ࠣࡪࡷࡵ࡭ࠡࡲࡧࡦࠥ࡯࡭ࡱࡱࡵࡸࠥࡖࡤࡣ࠽ࠣࡳ࡬ࡥࡤࡣࠢࡀࠤࡕࡪࡢ࠯ࡦࡲࡣࡧࡸࡥࡢ࡭࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡥࡧࡩࠤࡲࡵࡤࡠࡤࡵࡩࡦࡱࠨࡴࡧ࡯ࡪ࠱ࠦࡡࡳࡩ࠯ࠤࡹ࡫࡭ࡱࡱࡵࡥࡷࡿࠠ࠾ࠢ࠳࠭࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡹࡸࡹ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡤࡶ࡬ࠦ࠽ࠡࡵࡷࡶ࠭࡯࡮ࡵࠪࡤࡶ࡬࠯ࠫ࠲࠲ࠬࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡼࡨ࡫ࡰࡵࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡧࡳࠡࡧ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡵࡧࡳࡴࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡰࡩࡢࡨࡧ࠮ࡳࡦ࡮ࡩ࠰ࡦࡸࡧ࠭ࡶࡨࡱࡵࡵࡲࡢࡴࡼ࠭ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡒࡧࡦ࠳ࡪ࡯ࡠࡤࠣࡁࠥࡳ࡯ࡥࡡࡥࡶࡪࡧ࡫ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡕࡪࡢ࠯ࡦࡲࡣࡧࡸࡥࡢ࡭ࠣࡁࠥࡳ࡯ࡥࡡࡥࡶࡪࡧ࡫ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡕࡪࡢࠩࠫ࠱ࡷࡪࡺ࡟ࡵࡴࡤࡧࡪ࠮ࠩ࡝ࡰࠥࠦࠧຕ").format(str(bstack11l111l1l_opy_))
          bstack1l1lll111l_opy_ = bstack1lll111ll1_opy_ + file_content
          bstack1ll1l11ll1_opy_ = bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ຖ")] + bstack1l1111l_opy_ (u"ࠫࡤࡨࡳࡵࡣࡦ࡯ࡤࡺࡥ࡮ࡲ࠱ࡴࡾ࠭ທ")
          with open(bstack1ll1l11ll1_opy_, bstack1l1111l_opy_ (u"ࠬࡽࠧຘ")):
            pass
          with open(bstack1ll1l11ll1_opy_, bstack1l1111l_opy_ (u"ࠨࡷࠬࠤນ")) as f:
            f.write(bstack1l1lll111l_opy_)
          import subprocess
          process_data = subprocess.run([bstack1l1111l_opy_ (u"ࠢࡱࡻࡷ࡬ࡴࡴࠢບ"), bstack1ll1l11ll1_opy_])
          if os.path.exists(bstack1ll1l11ll1_opy_):
            os.unlink(bstack1ll1l11ll1_opy_)
          os._exit(process_data.returncode)
        else:
          if bstack11l11ll1ll_opy_(bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫປ")]):
            bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬຜ")].remove(bstack1l1111l_opy_ (u"ࠪ࠱ࡲ࠭ຝ"))
            bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧພ")].remove(bstack1l1111l_opy_ (u"ࠬࡶࡤࡣࠩຟ"))
            bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩຠ")] = bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪມ")][0]
          bstack11lll11l1_opy_(bstack1l11llll11_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫຢ")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack1l1111l_opy_ (u"ࠩࡢࡣࡳࡧ࡭ࡦࡡࡢࠫຣ")] = bstack1l1111l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ຤")
          mod_globals[bstack1l1111l_opy_ (u"ࠫࡤࡥࡦࡪ࡮ࡨࡣࡤ࠭ລ")] = os.path.abspath(bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ຦")])
          exec(open(bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩວ")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack1l1111l_opy_ (u"ࠧࡄࡣࡸ࡫࡭ࡺࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰ࠽ࠤࢀࢃࠧຨ").format(str(e)))
          for driver in bstack11llll1ll_opy_:
            bstack1ll111l111_opy_.append({
              bstack1l1111l_opy_ (u"ࠨࡰࡤࡱࡪ࠭ຩ"): bstack11l111l1l_opy_[bstack1l1111l_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬສ")],
              bstack1l1111l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩຫ"): str(e),
              bstack1l1111l_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪຬ"): multiprocessing.current_process().name
            })
            bstack11ll1111ll_opy_(driver, bstack1l1111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬອ"), bstack1l1111l_opy_ (u"ࠨࡓࡦࡵࡶ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦ࡜࡯ࠤຮ") + str(e))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack11llll1ll_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      percy.init(bstack11l1lll1l_opy_, CONFIG, logger)
      bstack1l11l11111_opy_()
      bstack11l1l111l1_opy_()
      bstack11111lll_opy_ = {
        bstack1l1111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪຯ"): args[0],
        bstack1l1111l_opy_ (u"ࠨࡅࡒࡒࡋࡏࡇࠨະ"): CONFIG,
        bstack1l1111l_opy_ (u"ࠩࡋ࡙ࡇࡥࡕࡓࡎࠪັ"): bstack11l11l111l_opy_,
        bstack1l1111l_opy_ (u"ࠪࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬາ"): bstack11l1lll1l_opy_
      }
      percy.bstack1l11llll1_opy_()
      if bstack1l1111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧຳ") in CONFIG:
        bstack1111l1l1_opy_ = []
        manager = multiprocessing.Manager()
        bstack111lll11_opy_ = manager.list()
        if bstack11l11ll1ll_opy_(args):
          for index, platform in enumerate(CONFIG[bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨິ")]):
            if index == 0:
              bstack11111lll_opy_[bstack1l1111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩີ")] = args
            bstack1111l1l1_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack11111lll_opy_, bstack111lll11_opy_)))
        else:
          for index, platform in enumerate(CONFIG[bstack1l1111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪຶ")]):
            bstack1111l1l1_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack11111lll_opy_, bstack111lll11_opy_)))
        for t in bstack1111l1l1_opy_:
          t.start()
        for t in bstack1111l1l1_opy_:
          t.join()
        bstack11ll1lll1l_opy_ = list(bstack111lll11_opy_)
      else:
        if bstack11l11ll1ll_opy_(args):
          bstack11111lll_opy_[bstack1l1111l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫື")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack11111lll_opy_,))
          test.start()
          test.join()
        else:
          bstack11lll11l1_opy_(bstack1l11llll11_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack1l1111l_opy_ (u"ࠩࡢࡣࡳࡧ࡭ࡦࡡࡢຸࠫ")] = bstack1l1111l_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣູࠬ")
          mod_globals[bstack1l1111l_opy_ (u"ࠫࡤࡥࡦࡪ࡮ࡨࡣࡤ຺࠭")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫົ") or bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬຼ"):
    percy.init(bstack11l1lll1l_opy_, CONFIG, logger)
    percy.bstack1l11llll1_opy_()
    try:
      from pabot import pabot
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1ll1lll11_opy_)
    bstack1l11l11111_opy_()
    bstack11lll11l1_opy_(bstack1lll1l1l1l_opy_)
    if bstack1ll1111lll_opy_:
      bstack11l111ll1l_opy_(bstack1lll1l1l1l_opy_, args)
      if bstack1l1111l_opy_ (u"ࠧ࠮࠯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬຽ") in args:
        i = args.index(bstack1l1111l_opy_ (u"ࠨ࠯࠰ࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭຾"))
        args.pop(i)
        args.pop(i)
      if bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ຿") not in CONFIG:
        CONFIG[bstack1l1111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ເ")] = [{}]
        bstack1l1llllll1_opy_ = 1
      if bstack111lll111_opy_ == 0:
        bstack111lll111_opy_ = 1
      args.insert(0, str(bstack111lll111_opy_))
      args.insert(0, str(bstack1l1111l_opy_ (u"ࠫ࠲࠳ࡰࡳࡱࡦࡩࡸࡹࡥࡴࠩແ")))
    if bstack1l11l1l1_opy_.on():
      try:
        from robot.run import USAGE
        from robot.utils import ArgumentParser
        from pabot.arguments import _parse_pabot_args
        bstack11lll111l1_opy_, pabot_args = _parse_pabot_args(args)
        opts, bstack11l1l1lll1_opy_ = ArgumentParser(
            USAGE,
            auto_pythonpath=False,
            auto_argumentfile=True,
            env_options=bstack1l1111l_opy_ (u"ࠧࡘࡏࡃࡑࡗࡣࡔࡖࡔࡊࡑࡑࡗࠧໂ"),
        ).parse_args(bstack11lll111l1_opy_)
        bstack1l111ll11_opy_ = args.index(bstack11lll111l1_opy_[0]) if len(bstack11lll111l1_opy_) > 0 else len(args)
        args.insert(bstack1l111ll11_opy_, str(bstack1l1111l_opy_ (u"࠭࠭࠮࡮࡬ࡷࡹ࡫࡮ࡦࡴࠪໃ")))
        args.insert(bstack1l111ll11_opy_ + 1, str(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l1111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡳࡱࡥࡳࡹࡥ࡬ࡪࡵࡷࡩࡳ࡫ࡲ࠯ࡲࡼࠫໄ"))))
        if bstack11ll111lll_opy_(os.environ.get(bstack1l1111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡓࡇࡕ࡙ࡓ࠭໅"))) and str(os.environ.get(bstack1l1111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡔࡈࡖ࡚ࡔ࡟ࡕࡇࡖࡘࡘ࠭ໆ"), bstack1l1111l_opy_ (u"ࠪࡲࡺࡲ࡬ࠨ໇"))) != bstack1l1111l_opy_ (u"ࠫࡳࡻ࡬࡭່ࠩ"):
          for bstack111ll1lll_opy_ in bstack11l1l1lll1_opy_:
            args.remove(bstack111ll1lll_opy_)
          bstack1l1lll11ll_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡗࡋࡒࡖࡐࡢࡘࡊ࡙ࡔࡔ້ࠩ")).split(bstack1l1111l_opy_ (u"࠭ࠬࠨ໊"))
          for bstack11l1111ll1_opy_ in bstack1l1lll11ll_opy_:
            args.append(bstack11l1111ll1_opy_)
      except Exception as e:
        logger.error(bstack1l1111l_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡷࡩ࡫࡯ࡩࠥࡧࡴࡵࡣࡦ࡬࡮ࡴࡧࠡ࡮࡬ࡷࡹ࡫࡮ࡦࡴࠣࡪࡴࡸࠠࡐࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿ࠮ࠡࡇࡵࡶࡴࡸࠠ࠮໋ࠢࠥ").format(e))
    pabot.main(args)
  elif bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠨࡴࡲࡦࡴࡺ࠭ࡪࡰࡷࡩࡷࡴࡡ࡭ࠩ໌"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1ll1lll11_opy_)
    for a in args:
      if bstack1l1111l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡒࡏࡅ࡙ࡌࡏࡓࡏࡌࡒࡉࡋࡘࠨໍ") in a:
        bstack11ll1111l1_opy_ = int(a.split(bstack1l1111l_opy_ (u"ࠪ࠾ࠬ໎"))[1])
      if bstack1l1111l_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡈࡊࡌࡌࡐࡅࡄࡐࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠨ໏") in a:
        bstack111111ll1_opy_ = str(a.split(bstack1l1111l_opy_ (u"ࠬࡀࠧ໐"))[1])
      if bstack1l1111l_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘ࠭໑") in a:
        bstack11l1l1lll_opy_ = str(a.split(bstack1l1111l_opy_ (u"ࠧ࠻ࠩ໒"))[1])
    bstack1l11111l1l_opy_ = None
    if bstack1l1111l_opy_ (u"ࠨ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠧ໓") in args:
      i = args.index(bstack1l1111l_opy_ (u"ࠩ࠰࠱ࡧࡹࡴࡢࡥ࡮ࡣ࡮ࡺࡥ࡮ࡡ࡬ࡲࡩ࡫ࡸࠨ໔"))
      args.pop(i)
      bstack1l11111l1l_opy_ = args.pop(i)
    if bstack1l11111l1l_opy_ is not None:
      global bstack1lll1lll1_opy_
      bstack1lll1lll1_opy_ = bstack1l11111l1l_opy_
    bstack11lll11l1_opy_(bstack1lll1l1l1l_opy_)
    run_cli(args)
    if bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡢࡩࡷࡸ࡯ࡳࡡ࡯࡭ࡸࡺࠧ໕") in multiprocessing.current_process().__dict__.keys():
      for bstack11l111111l_opy_ in multiprocessing.current_process().bstack_error_list:
        bstack1ll111l111_opy_.append(bstack11l111111l_opy_)
  elif bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫ໖"):
    percy.init(bstack11l1lll1l_opy_, CONFIG, logger)
    percy.bstack1l11llll1_opy_()
    bstack11l11l1l1_opy_ = bstack11l11111_opy_(args, logger, CONFIG, bstack1ll1111lll_opy_)
    bstack11l11l1l1_opy_.bstack1111111l_opy_()
    bstack1l11l11111_opy_()
    bstack1llll1lll_opy_ = True
    bstack1lll11lll1_opy_ = bstack11l11l1l1_opy_.bstack111l111l_opy_()
    bstack11l11l1l1_opy_.bstack11111lll_opy_(bstack11l1ll111_opy_)
    bstack11lllll111_opy_ = bstack11l11l1l1_opy_.bstack111ll111_opy_(bstack1lll1l1l11_opy_, {
      bstack1l1111l_opy_ (u"ࠬࡎࡕࡃࡡࡘࡖࡑ࠭໗"): bstack11l11l111l_opy_,
      bstack1l1111l_opy_ (u"࠭ࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨ໘"): bstack11l1lll1l_opy_,
      bstack1l1111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪ໙"): bstack1ll1111lll_opy_
    })
    try:
      bstack1l1111ll1l_opy_, bstack11l11llll_opy_ = map(list, zip(*bstack11lllll111_opy_))
      bstack11lllll11l_opy_ = bstack1l1111ll1l_opy_[0]
      for status_code in bstack11l11llll_opy_:
        if status_code != 0:
          bstack1l11lllll1_opy_ = status_code
          break
    except Exception as e:
      logger.debug(bstack1l1111l_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸࡧࡶࡦࠢࡨࡶࡷࡵࡲࡴࠢࡤࡲࡩࠦࡳࡵࡣࡷࡹࡸࠦࡣࡰࡦࡨ࠲ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࠼ࠣࡿࢂࠨ໚").format(str(e)))
  elif bstack11ll11l1l_opy_ == bstack1l1111l_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ໛"):
    try:
      from behave.__main__ import main as bstack1ll11l1ll1_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack11ll1ll1l1_opy_(e, bstack1l1l11lll1_opy_)
    bstack1l11l11111_opy_()
    bstack1llll1lll_opy_ = True
    bstack1111l111_opy_ = 1
    if bstack1l1111l_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪໜ") in CONFIG:
      bstack1111l111_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫໝ")]
    if bstack1l1111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨໞ") in CONFIG:
      bstack11ll1l1l11_opy_ = int(bstack1111l111_opy_) * int(len(CONFIG[bstack1l1111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩໟ")]))
    else:
      bstack11ll1l1l11_opy_ = int(bstack1111l111_opy_)
    config = Configuration(args)
    bstack11l111l1ll_opy_ = config.paths
    if len(bstack11l111l1ll_opy_) == 0:
      import glob
      pattern = bstack1l1111l_opy_ (u"ࠧࠫࠬ࠲࠮࠳࡬ࡥࡢࡶࡸࡶࡪ࠭໠")
      bstack1l1l111ll1_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack1l1l111ll1_opy_)
      config = Configuration(args)
      bstack11l111l1ll_opy_ = config.paths
    bstack111ll1ll_opy_ = [os.path.normpath(item) for item in bstack11l111l1ll_opy_]
    bstack1ll11ll11l_opy_ = [os.path.normpath(item) for item in args]
    bstack1l1l1lll11_opy_ = [item for item in bstack1ll11ll11l_opy_ if item not in bstack111ll1ll_opy_]
    import platform as pf
    if pf.system().lower() == bstack1l1111l_opy_ (u"ࠨࡹ࡬ࡲࡩࡵࡷࡴࠩ໡"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack111ll1ll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1lllll11ll_opy_)))
                    for bstack1lllll11ll_opy_ in bstack111ll1ll_opy_]
    bstack111l1l1l_opy_ = []
    for spec in bstack111ll1ll_opy_:
      bstack111l11ll_opy_ = []
      bstack111l11ll_opy_ += bstack1l1l1lll11_opy_
      bstack111l11ll_opy_.append(spec)
      bstack111l1l1l_opy_.append(bstack111l11ll_opy_)
    execution_items = []
    for bstack111l11ll_opy_ in bstack111l1l1l_opy_:
      if bstack1l1111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ໢") in CONFIG:
        for index, _ in enumerate(CONFIG[bstack1l1111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭໣")]):
          item = {}
          item[bstack1l1111l_opy_ (u"ࠫࡦࡸࡧࠨ໤")] = bstack1l1111l_opy_ (u"ࠬࠦࠧ໥").join(bstack111l11ll_opy_)
          item[bstack1l1111l_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ໦")] = index
          execution_items.append(item)
      else:
        item = {}
        item[bstack1l1111l_opy_ (u"ࠧࡢࡴࡪࠫ໧")] = bstack1l1111l_opy_ (u"ࠨࠢࠪ໨").join(bstack111l11ll_opy_)
        item[bstack1l1111l_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ໩")] = 0
        execution_items.append(item)
    bstack1l1l111l1l_opy_ = bstack11l11ll11l_opy_(execution_items, bstack11ll1l1l11_opy_)
    for execution_item in bstack1l1l111l1l_opy_:
      bstack1111l1l1_opy_ = []
      for item in execution_item:
        bstack1111l1l1_opy_.append(bstack11ll1l11ll_opy_(name=str(item[bstack1l1111l_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ໪")]),
                                             target=bstack11l1ll11l_opy_,
                                             args=(item[bstack1l1111l_opy_ (u"ࠫࡦࡸࡧࠨ໫")],)))
      for t in bstack1111l1l1_opy_:
        t.start()
      for t in bstack1111l1l1_opy_:
        t.join()
  else:
    bstack11ll1l1ll1_opy_(bstack11l111l11_opy_)
  if not bstack11l111l1l_opy_:
    bstack1l1lllll1l_opy_()
  bstack11lll111ll_opy_.bstack1l11ll1lll_opy_()
def browserstack_initialize(bstack11l11l111_opy_=None):
  run_on_browserstack(bstack11l11l111_opy_, None, True)
@measure(event_name=EVENTS.bstack111lllllll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1l1lllll1l_opy_():
  global CONFIG
  global bstack11l1llllll_opy_
  global bstack1l11lllll1_opy_
  global bstack111llll1ll_opy_
  global bstack11l11l11_opy_
  bstack1l11l1l1_opy_.stop()
  bstack1l11l1ll_opy_.bstack1l1l1l11l_opy_()
  if bstack1l1111l_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩ໬") in CONFIG and str(CONFIG[bstack1l1111l_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠪ໭")]).lower() != bstack1l1111l_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭໮"):
    bstack11l11l11ll_opy_, bstack1l1lll11l1_opy_ = bstack1l1ll1lll1_opy_()
  else:
    bstack11l11l11ll_opy_, bstack1l1lll11l1_opy_ = get_build_link()
  bstack1lll1ll1l1_opy_(bstack11l11l11ll_opy_)
  if bstack11l11l11ll_opy_ is not None and bstack1l1l1l1lll_opy_() != -1:
    sessions = bstack11ll11111_opy_(bstack11l11l11ll_opy_)
    bstack1l11l1111_opy_(sessions, bstack1l1lll11l1_opy_)
  if bstack11l1llllll_opy_ == bstack1l1111l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ໯") and bstack1l11lllll1_opy_ != 0:
    sys.exit(bstack1l11lllll1_opy_)
  if bstack11l1llllll_opy_ == bstack1l1111l_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ໰") and bstack111llll1ll_opy_ != 0:
    sys.exit(bstack111llll1ll_opy_)
def bstack1lll1ll1l1_opy_(new_id):
    global bstack1l1ll11ll_opy_
    bstack1l1ll11ll_opy_ = new_id
def bstack1l1ll1l1l_opy_(bstack1llllll1ll_opy_):
  if bstack1llllll1ll_opy_:
    return bstack1llllll1ll_opy_.capitalize()
  else:
    return bstack1l1111l_opy_ (u"ࠪࠫ໱")
@measure(event_name=EVENTS.bstack11l1ll1l11_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1l11ll111_opy_(bstack1ll11lll1_opy_):
  if bstack1l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ໲") in bstack1ll11lll1_opy_ and bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ໳")] != bstack1l1111l_opy_ (u"࠭ࠧ໴"):
    return bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ໵")]
  else:
    bstack1ll1l1ll1l_opy_ = bstack1l1111l_opy_ (u"ࠣࠤ໶")
    if bstack1l1111l_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩ໷") in bstack1ll11lll1_opy_ and bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࠪ໸")] != None:
      bstack1ll1l1ll1l_opy_ += bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࠫ໹")] + bstack1l1111l_opy_ (u"ࠧ࠲ࠠࠣ໺")
      if bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"࠭࡯ࡴࠩ໻")] == bstack1l1111l_opy_ (u"ࠢࡪࡱࡶࠦ໼"):
        bstack1ll1l1ll1l_opy_ += bstack1l1111l_opy_ (u"ࠣ࡫ࡒࡗࠥࠨ໽")
      bstack1ll1l1ll1l_opy_ += (bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠩࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭໾")] or bstack1l1111l_opy_ (u"ࠪࠫ໿"))
      return bstack1ll1l1ll1l_opy_
    else:
      bstack1ll1l1ll1l_opy_ += bstack1l1ll1l1l_opy_(bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬༀ")]) + bstack1l1111l_opy_ (u"ࠧࠦࠢ༁") + (
              bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ༂")] or bstack1l1111l_opy_ (u"ࠧࠨ༃")) + bstack1l1111l_opy_ (u"ࠣ࠮ࠣࠦ༄")
      if bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠩࡲࡷࠬ༅")] == bstack1l1111l_opy_ (u"࡛ࠥ࡮ࡴࡤࡰࡹࡶࠦ༆"):
        bstack1ll1l1ll1l_opy_ += bstack1l1111l_opy_ (u"ࠦ࡜࡯࡮ࠡࠤ༇")
      bstack1ll1l1ll1l_opy_ += bstack1ll11lll1_opy_[bstack1l1111l_opy_ (u"ࠬࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ༈")] or bstack1l1111l_opy_ (u"࠭ࠧ༉")
      return bstack1ll1l1ll1l_opy_
@measure(event_name=EVENTS.bstack11l111l11l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack11ll11ll1_opy_(bstack1l11l11l11_opy_):
  if bstack1l11l11l11_opy_ == bstack1l1111l_opy_ (u"ࠢࡥࡱࡱࡩࠧ༊"):
    return bstack1l1111l_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽࡫ࡷ࡫ࡥ࡯࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥ࡫ࡷ࡫ࡥ࡯ࠤࡁࡇࡴࡳࡰ࡭ࡧࡷࡩࡩࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ་")
  elif bstack1l11l11l11_opy_ == bstack1l1111l_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤ༌"):
    return bstack1l1111l_opy_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࡸࡥࡥ࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࡈࡤ࡭ࡱ࡫ࡤ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭།")
  elif bstack1l11l11l11_opy_ == bstack1l1111l_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦ༎"):
    return bstack1l1111l_opy_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡨࡴࡨࡩࡳࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡨࡴࡨࡩࡳࠨ࠾ࡑࡣࡶࡷࡪࡪ࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ༏")
  elif bstack1l11l11l11_opy_ == bstack1l1111l_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ༐"):
    return bstack1l1111l_opy_ (u"ࠧ࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࡵࡩࡩࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃࡋࡲࡳࡱࡵࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩ༑")
  elif bstack1l11l11l11_opy_ == bstack1l1111l_opy_ (u"ࠣࡶ࡬ࡱࡪࡵࡵࡵࠤ༒"):
    return bstack1l1111l_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠨ࡫ࡥࡢ࠵࠵࠺ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࠣࡦࡧࡤ࠷࠷࠼ࠢ࠿ࡖ࡬ࡱࡪࡵࡵࡵ࠾࠲ࡪࡴࡴࡴ࠿࠾࠲ࡸࡩࡄࠧ༓")
  elif bstack1l11l11l11_opy_ == bstack1l1111l_opy_ (u"ࠥࡶࡺࡴ࡮ࡪࡰࡪࠦ༔"):
    return bstack1l1111l_opy_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡢ࡭ࡣࡦ࡯ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࡢ࡭ࡣࡦ࡯ࠧࡄࡒࡶࡰࡱ࡭ࡳ࡭࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ༕")
  else:
    return bstack1l1111l_opy_ (u"ࠬࡂࡴࡥࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࡤ࡯ࡥࡨࡱ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡤ࡯ࡥࡨࡱࠢ࠿ࠩ༖") + bstack1l1ll1l1l_opy_(
      bstack1l11l11l11_opy_) + bstack1l1111l_opy_ (u"࠭࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ༗")
def bstack1ll1l11l1_opy_(session):
  return bstack1l1111l_opy_ (u"ࠧ࠽ࡶࡵࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡷࡵࡷࠣࡀ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠲ࡴࡡ࡮ࡧࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡻࡾࠤࠣࡸࡦࡸࡧࡦࡶࡀࠦࡤࡨ࡬ࡢࡰ࡮ࠦࡃࢁࡽ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀࡾࢁࢀࢃ࠼ࡵࡦࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࡁࡿࢂࡂ࠯ࡵࡦࡁࡀࡹࡪࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨ࠾ࡼࡿ࠿࠳ࡹࡪ࠾࠽ࡶࡧࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࡂࢀࢃ࠼࠰ࡶࡧࡂࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢ࠿ࡽࢀࡀ࠴ࡺࡤ࠿࠾࠲ࡸࡷࡄ༘ࠧ").format(
    session[bstack1l1111l_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡠࡷࡵࡰ༙ࠬ")], bstack1l11ll111_opy_(session), bstack11ll11ll1_opy_(session[bstack1l1111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡵࡷࡥࡹࡻࡳࠨ༚")]),
    bstack11ll11ll1_opy_(session[bstack1l1111l_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ༛")]),
    bstack1l1ll1l1l_opy_(session[bstack1l1111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬ༜")] or session[bstack1l1111l_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࠬ༝")] or bstack1l1111l_opy_ (u"࠭ࠧ༞")) + bstack1l1111l_opy_ (u"ࠢࠡࠤ༟") + (session[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪ༠")] or bstack1l1111l_opy_ (u"ࠩࠪ༡")),
    session[bstack1l1111l_opy_ (u"ࠪࡳࡸ࠭༢")] + bstack1l1111l_opy_ (u"ࠦࠥࠨ༣") + session[bstack1l1111l_opy_ (u"ࠬࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ༤")], session[bstack1l1111l_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ༥")] or bstack1l1111l_opy_ (u"ࠧࠨ༦"),
    session[bstack1l1111l_opy_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬ༧")] if session[bstack1l1111l_opy_ (u"ࠩࡦࡶࡪࡧࡴࡦࡦࡢࡥࡹ࠭༨")] else bstack1l1111l_opy_ (u"ࠪࠫ༩"))
@measure(event_name=EVENTS.bstack11ll1l111l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def bstack1l11l1111_opy_(sessions, bstack1l1lll11l1_opy_):
  try:
    bstack1llll1llll_opy_ = bstack1l1111l_opy_ (u"ࠦࠧ༪")
    if not os.path.exists(bstack11ll1ll1l_opy_):
      os.mkdir(bstack11ll1ll1l_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l1111l_opy_ (u"ࠬࡧࡳࡴࡧࡷࡷ࠴ࡸࡥࡱࡱࡵࡸ࠳࡮ࡴ࡮࡮ࠪ༫")), bstack1l1111l_opy_ (u"࠭ࡲࠨ༬")) as f:
      bstack1llll1llll_opy_ = f.read()
    bstack1llll1llll_opy_ = bstack1llll1llll_opy_.replace(bstack1l1111l_opy_ (u"ࠧࡼࠧࡕࡉࡘ࡛ࡌࡕࡕࡢࡇࡔ࡛ࡎࡕࠧࢀࠫ༭"), str(len(sessions)))
    bstack1llll1llll_opy_ = bstack1llll1llll_opy_.replace(bstack1l1111l_opy_ (u"ࠨࡽࠨࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠫࡽࠨ༮"), bstack1l1lll11l1_opy_)
    bstack1llll1llll_opy_ = bstack1llll1llll_opy_.replace(bstack1l1111l_opy_ (u"ࠩࡾࠩࡇ࡛ࡉࡍࡆࡢࡒࡆࡓࡅࠦࡿࠪ༯"),
                                              sessions[0].get(bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡࡱࡥࡲ࡫ࠧ༰")) if sessions[0] else bstack1l1111l_opy_ (u"ࠫࠬ༱"))
    with open(os.path.join(bstack11ll1ll1l_opy_, bstack1l1111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠱ࡷ࡫ࡰࡰࡴࡷ࠲࡭ࡺ࡭࡭ࠩ༲")), bstack1l1111l_opy_ (u"࠭ࡷࠨ༳")) as stream:
      stream.write(bstack1llll1llll_opy_.split(bstack1l1111l_opy_ (u"ࠧࡼࠧࡖࡉࡘ࡙ࡉࡐࡐࡖࡣࡉࡇࡔࡂࠧࢀࠫ༴"))[0])
      for session in sessions:
        stream.write(bstack1ll1l11l1_opy_(session))
      stream.write(bstack1llll1llll_opy_.split(bstack1l1111l_opy_ (u"ࠨࡽࠨࡗࡊ࡙ࡓࡊࡑࡑࡗࡤࡊࡁࡕࡃࠨࢁ༵ࠬ"))[1])
    logger.info(bstack1l1111l_opy_ (u"ࠩࡊࡩࡳ࡫ࡲࡢࡶࡨࡨࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠤࡧࡻࡩ࡭ࡦࠣࡥࡷࡺࡩࡧࡣࡦࡸࡸࠦࡡࡵࠢࡾࢁࠬ༶").format(bstack11ll1ll1l_opy_));
  except Exception as e:
    logger.debug(bstack11llll1l1_opy_.format(str(e)))
def bstack11ll11111_opy_(bstack11l11l11ll_opy_):
  global CONFIG
  try:
    host = bstack1l1111l_opy_ (u"ࠪࡥࡵ࡯࠭ࡤ࡮ࡲࡹࡩ༷࠭") if bstack1l1111l_opy_ (u"ࠫࡦࡶࡰࠨ༸") in CONFIG else bstack1l1111l_opy_ (u"ࠬࡧࡰࡪ༹ࠩ")
    user = CONFIG[bstack1l1111l_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨ༺")]
    key = CONFIG[bstack1l1111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪ༻")]
    bstack1l1llll11_opy_ = bstack1l1111l_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧ༼") if bstack1l1111l_opy_ (u"ࠩࡤࡴࡵ࠭༽") in CONFIG else (bstack1l1111l_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫ࠧ༾") if CONFIG.get(bstack1l1111l_opy_ (u"ࠫࡹࡻࡲࡣࡱࡶࡧࡦࡲࡥࠨ༿")) else bstack1l1111l_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡫ࠧཀ"))
    url = bstack1l1111l_opy_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡼࡿ࠽ࡿࢂࡆࡻࡾ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡥࡲࡱ࠴ࢁࡽ࠰ࡤࡸ࡭ࡱࡪࡳ࠰ࡽࢀ࠳ࡸ࡫ࡳࡴ࡫ࡲࡲࡸ࠴ࡪࡴࡱࡱࠫཁ").format(user, key, host, bstack1l1llll11_opy_,
                                                                                bstack11l11l11ll_opy_)
    headers = {
      bstack1l1111l_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭ག"): bstack1l1111l_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫགྷ"),
    }
    proxies = bstack1lll11llll_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies)
    if response.json():
      return list(map(lambda session: session[bstack1l1111l_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡥࡳࡦࡵࡶ࡭ࡴࡴࠧང")], response.json()))
  except Exception as e:
    logger.debug(bstack1ll11l11l_opy_.format(str(e)))
@measure(event_name=EVENTS.bstack1l11lll1l1_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def get_build_link():
  global CONFIG
  global bstack1l1ll11ll_opy_
  try:
    if bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ཅ") in CONFIG:
      host = bstack1l1111l_opy_ (u"ࠫࡦࡶࡩ࠮ࡥ࡯ࡳࡺࡪࠧཆ") if bstack1l1111l_opy_ (u"ࠬࡧࡰࡱࠩཇ") in CONFIG else bstack1l1111l_opy_ (u"࠭ࡡࡱ࡫ࠪ཈")
      user = CONFIG[bstack1l1111l_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩཉ")]
      key = CONFIG[bstack1l1111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫཊ")]
      bstack1l1llll11_opy_ = bstack1l1111l_opy_ (u"ࠩࡤࡴࡵ࠳ࡡࡶࡶࡲࡱࡦࡺࡥࠨཋ") if bstack1l1111l_opy_ (u"ࠪࡥࡵࡶࠧཌ") in CONFIG else bstack1l1111l_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ཌྷ")
      url = bstack1l1111l_opy_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡻࡾ࠼ࡾࢁࡅࢁࡽ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰ࠳ࢀࢃ࠯ࡣࡷ࡬ࡰࡩࡹ࠮࡫ࡵࡲࡲࠬཎ").format(user, key, host, bstack1l1llll11_opy_)
      headers = {
        bstack1l1111l_opy_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬཏ"): bstack1l1111l_opy_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪཐ"),
      }
      if bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪད") in CONFIG:
        params = {bstack1l1111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧདྷ"): CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ན")], bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡭ࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧཔ"): CONFIG[bstack1l1111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧཕ")]}
      else:
        params = {bstack1l1111l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫབ"): CONFIG[bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪབྷ")]}
      proxies = bstack1lll11llll_opy_(CONFIG, url)
      response = requests.get(url, params=params, headers=headers, proxies=proxies)
      if response.json():
        bstack11lll11111_opy_ = response.json()[0][bstack1l1111l_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࡤࡨࡵࡪ࡮ࡧࠫམ")]
        if bstack11lll11111_opy_:
          bstack1l1lll11l1_opy_ = bstack11lll11111_opy_[bstack1l1111l_opy_ (u"ࠩࡳࡹࡧࡲࡩࡤࡡࡸࡶࡱ࠭ཙ")].split(bstack1l1111l_opy_ (u"ࠪࡴࡺࡨ࡬ࡪࡥ࠰ࡦࡺ࡯࡬ࡥࠩཚ"))[0] + bstack1l1111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡶ࠳ࠬཛ") + bstack11lll11111_opy_[
            bstack1l1111l_opy_ (u"ࠬ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨཛྷ")]
          logger.info(bstack1l1l11l111_opy_.format(bstack1l1lll11l1_opy_))
          bstack1l1ll11ll_opy_ = bstack11lll11111_opy_[bstack1l1111l_opy_ (u"࠭ࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩཝ")]
          bstack1l111111l_opy_ = CONFIG[bstack1l1111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪཞ")]
          if bstack1l1111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪཟ") in CONFIG:
            bstack1l111111l_opy_ += bstack1l1111l_opy_ (u"ࠩࠣࠫའ") + CONFIG[bstack1l1111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬཡ")]
          if bstack1l111111l_opy_ != bstack11lll11111_opy_[bstack1l1111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩར")]:
            logger.debug(bstack1l1lll1l11_opy_.format(bstack11lll11111_opy_[bstack1l1111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪལ")], bstack1l111111l_opy_))
          return [bstack11lll11111_opy_[bstack1l1111l_opy_ (u"࠭ࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩཤ")], bstack1l1lll11l1_opy_]
    else:
      logger.warn(bstack111l11ll1_opy_)
  except Exception as e:
    logger.debug(bstack1l1lll1l1_opy_.format(str(e)))
  return [None, None]
def bstack111l1lll1_opy_(url, bstack1ll1ll1ll_opy_=False):
  global CONFIG
  global bstack111l11l1l_opy_
  if not bstack111l11l1l_opy_:
    hostname = bstack1ll111llll_opy_(url)
    is_private = bstack1lllll11l1_opy_(hostname)
    if (bstack1l1111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫཥ") in CONFIG and not bstack11ll111lll_opy_(CONFIG[bstack1l1111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬས")])) and (is_private or bstack1ll1ll1ll_opy_):
      bstack111l11l1l_opy_ = hostname
def bstack1ll111llll_opy_(url):
  return urlparse(url).hostname
def bstack1lllll11l1_opy_(hostname):
  for bstack1l1l111lll_opy_ in bstack11ll111ll_opy_:
    regex = re.compile(bstack1l1l111lll_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack1l11111l1_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False
@measure(event_name=EVENTS.bstack1llll1ll1l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def getAccessibilityResults(driver):
  global CONFIG
  global bstack11ll1111l1_opy_
  bstack1l111111l1_opy_ = not (bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠩ࡬ࡷࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭ཧ"), None) and bstack1l111ll1_opy_(
          threading.current_thread(), bstack1l1111l_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩཨ"), None))
  bstack1l111llll1_opy_ = getattr(driver, bstack1l1111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡅ࠶࠷ࡹࡔࡪࡲࡹࡱࡪࡓࡤࡣࡱࠫཀྵ"), None) != True
  if not bstack1111ll11_opy_.bstack111ll111l_opy_(CONFIG, bstack11ll1111l1_opy_) or (bstack1l111llll1_opy_ and bstack1l111111l1_opy_):
    logger.warning(bstack1l1111l_opy_ (u"ࠧࡔ࡯ࡵࠢࡤࡲࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡶࡩࡸࡹࡩࡰࡰ࠯ࠤࡨࡧ࡮࡯ࡱࡷࠤࡷ࡫ࡴࡳ࡫ࡨࡺࡪࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡲࡦࡵࡸࡰࡹࡹ࠮ࠣཪ"))
    return {}
  try:
    logger.debug(bstack1l1111l_opy_ (u"࠭ࡐࡦࡴࡩࡳࡷࡳࡩ࡯ࡩࠣࡷࡨࡧ࡮ࠡࡤࡨࡪࡴࡸࡥࠡࡩࡨࡸࡹ࡯࡮ࡨࠢࡵࡩࡸࡻ࡬ࡵࡵࠪཫ"))
    logger.debug(perform_scan(driver))
    results = driver.execute_async_script(bstack1l1llll1l1_opy_.bstack111ll11ll_opy_)
    return results
  except Exception:
    logger.error(bstack1l1111l_opy_ (u"ࠢࡏࡱࠣࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡼ࡫ࡲࡦࠢࡩࡳࡺࡴࡤ࠯ࠤཬ"))
    return {}
@measure(event_name=EVENTS.bstack1l1lll1lll_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def getAccessibilityResultsSummary(driver):
  global CONFIG
  global bstack11ll1111l1_opy_
  bstack1l111111l1_opy_ = not (bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠨ࡫ࡶࡅ࠶࠷ࡹࡕࡧࡶࡸࠬ཭"), None) and bstack1l111ll1_opy_(
          threading.current_thread(), bstack1l1111l_opy_ (u"ࠩࡤ࠵࠶ࡿࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ཮"), None))
  bstack1l111llll1_opy_ = getattr(driver, bstack1l1111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡄ࠵࠶ࡿࡓࡩࡱࡸࡰࡩ࡙ࡣࡢࡰࠪ཯"), None) != True
  if not bstack1111ll11_opy_.bstack111ll111l_opy_(CONFIG, bstack11ll1111l1_opy_) or (bstack1l111llll1_opy_ and bstack1l111111l1_opy_):
    logger.warning(bstack1l1111l_opy_ (u"ࠦࡓࡵࡴࠡࡣࡱࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡵࡨࡷࡸ࡯࡯࡯࠮ࠣࡧࡦࡴ࡮ࡰࡶࠣࡶࡪࡺࡲࡪࡧࡹࡩࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡸࡥࡴࡷ࡯ࡸࡸࠦࡳࡶ࡯ࡰࡥࡷࡿ࠮ࠣ཰"))
    return {}
  try:
    logger.debug(bstack1l1111l_opy_ (u"ࠬࡖࡥࡳࡨࡲࡶࡲ࡯࡮ࡨࠢࡶࡧࡦࡴࠠࡣࡧࡩࡳࡷ࡫ࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡴࡨࡷࡺࡲࡴࡴࠢࡶࡹࡲࡳࡡࡳࡻཱࠪ"))
    logger.debug(perform_scan(driver))
    bstack1lll1ll11l_opy_ = driver.execute_async_script(bstack1l1llll1l1_opy_.bstack11lll1ll11_opy_)
    return bstack1lll1ll11l_opy_
  except Exception:
    logger.error(bstack1l1111l_opy_ (u"ࠨࡎࡰࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡶࡹࡲࡳࡡࡳࡻࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩ࠴ིࠢ"))
    return {}
@measure(event_name=EVENTS.bstack1l111l111l_opy_, stage=STAGE.SINGLE, bstack1ll1l1ll1l_opy_=bstack1l1l11l1l_opy_)
def perform_scan(driver, *args, **kwargs):
  global CONFIG
  global bstack11ll1111l1_opy_
  bstack1l111111l1_opy_ = not (bstack1l111ll1_opy_(threading.current_thread(), bstack1l1111l_opy_ (u"ࠧࡪࡵࡄ࠵࠶ࡿࡔࡦࡵࡷཱིࠫ"), None) and bstack1l111ll1_opy_(
          threading.current_thread(), bstack1l1111l_opy_ (u"ࠨࡣ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳུࠧ"), None))
  bstack1l111llll1_opy_ = getattr(driver, bstack1l1111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡃ࠴࠵ࡾ࡙ࡨࡰࡷ࡯ࡨࡘࡩࡡ࡯ཱུࠩ"), None) != True
  if not bstack1111ll11_opy_.bstack111ll111l_opy_(CONFIG, bstack11ll1111l1_opy_) or (bstack1l111llll1_opy_ and bstack1l111111l1_opy_):
    logger.warning(bstack1l1111l_opy_ (u"ࠥࡒࡴࡺࠠࡢࡰࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡴࡧࡶࡷ࡮ࡵ࡮࠭ࠢࡦࡥࡳࡴ࡯ࡵࠢࡵࡹࡳࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡳࡤࡣࡱ࠲ࠧྲྀ"))
    return {}
  try:
    bstack1llll111l_opy_ = driver.execute_async_script(bstack1l1llll1l1_opy_.perform_scan, {bstack1l1111l_opy_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࠫཷ"): kwargs.get(bstack1l1111l_opy_ (u"ࠬࡪࡲࡪࡸࡨࡶࡤࡩ࡯࡮࡯ࡤࡲࡩ࠭ླྀ"), None) or bstack1l1111l_opy_ (u"࠭ࠧཹ")})
    return bstack1llll111l_opy_
  except Exception:
    logger.error(bstack1l1111l_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡶࡺࡴࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡴࡥࡤࡲ࠳ࠨེ"))
    return {}