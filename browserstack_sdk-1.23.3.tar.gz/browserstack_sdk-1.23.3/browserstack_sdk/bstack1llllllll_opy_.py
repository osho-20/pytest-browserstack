# coding: UTF-8
import sys
bstack1ll11_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1l1111l_opy_ (bstack11l1l11_opy_):
    global bstack1l1l1_opy_
    bstack1l1l_opy_ = ord (bstack11l1l11_opy_ [-1])
    bstack1l1l1ll_opy_ = bstack11l1l11_opy_ [:-1]
    bstack111lll1_opy_ = bstack1l1l_opy_ % len (bstack1l1l1ll_opy_)
    bstack1lllll1_opy_ = bstack1l1l1ll_opy_ [:bstack111lll1_opy_] + bstack1l1l1ll_opy_ [bstack111lll1_opy_:]
    if bstack1ll11_opy_:
        bstack1_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1lllllll_opy_ + bstack1l1l_opy_) % bstack11ll_opy_) for bstack1lllllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1_opy_)
import os
import json
import logging
logger = logging.getLogger(__name__)
class BrowserStackSdk:
    def get_current_platform():
        bstack11111111_opy_ = {}
        bstack1lllllll1_opy_ = os.environ.get(bstack1l1111l_opy_ (u"ࠨࡅࡘࡖࡗࡋࡎࡕࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡉࡇࡔࡂࠩয"), bstack1l1111l_opy_ (u"ࠩࠪর"))
        if not bstack1lllllll1_opy_:
            return bstack11111111_opy_
        try:
            bstack1llllll1l_opy_ = json.loads(bstack1lllllll1_opy_)
            if bstack1l1111l_opy_ (u"ࠥࡳࡸࠨ঱") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠦࡴࡹࠢল")] = bstack1llllll1l_opy_[bstack1l1111l_opy_ (u"ࠧࡵࡳࠣ঳")]
            if bstack1l1111l_opy_ (u"ࠨ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠥ঴") in bstack1llllll1l_opy_ or bstack1l1111l_opy_ (u"ࠢࡰࡵ࡙ࡩࡷࡹࡩࡰࡰࠥ঵") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠣࡱࡶ࡚ࡪࡸࡳࡪࡱࡱࠦশ")] = bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨষ"), bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠥࡳࡸ࡜ࡥࡳࡵ࡬ࡳࡳࠨস")))
            if bstack1l1111l_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࠧহ") in bstack1llllll1l_opy_ or bstack1l1111l_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠥ঺") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠦ঻")] = bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲ়ࠣ"), bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪࠨঽ")))
            if bstack1l1111l_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡢࡺࡪࡸࡳࡪࡱࡱࠦা") in bstack1llllll1l_opy_ or bstack1l1111l_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠦি") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠧী")] = bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠢু"), bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠢূ")))
            if bstack1l1111l_opy_ (u"ࠢࡥࡧࡹ࡭ࡨ࡫ࠢৃ") in bstack1llllll1l_opy_ or bstack1l1111l_opy_ (u"ࠣࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠧৄ") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠤࡧࡩࡻ࡯ࡣࡦࡐࡤࡱࡪࠨ৅")] = bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠥࡨࡪࡼࡩࡤࡧࠥ৆"), bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠦࡩ࡫ࡶࡪࡥࡨࡒࡦࡳࡥࠣে")))
            if bstack1l1111l_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢৈ") in bstack1llllll1l_opy_ or bstack1l1111l_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡏࡣࡰࡩࠧ৉") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪࠨ৊")] = bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥো"), bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡒࡦࡳࡥࠣৌ")))
            if bstack1l1111l_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ্") in bstack1llllll1l_opy_ or bstack1l1111l_opy_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳࠨৎ") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠢ৏")] = bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ৐"), bstack1llllll1l_opy_.get(bstack1l1111l_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠤ৑")))
            if bstack1l1111l_opy_ (u"ࠣࡥࡸࡷࡹࡵ࡭ࡗࡣࡵ࡭ࡦࡨ࡬ࡦࡵࠥ৒") in bstack1llllll1l_opy_:
                bstack11111111_opy_[bstack1l1111l_opy_ (u"ࠤࡦࡹࡸࡺ࡯࡮ࡘࡤࡶ࡮ࡧࡢ࡭ࡧࡶࠦ৓")] = bstack1llllll1l_opy_[bstack1l1111l_opy_ (u"ࠥࡧࡺࡹࡴࡰ࡯࡙ࡥࡷ࡯ࡡࡣ࡮ࡨࡷࠧ৔")]
        except Exception as error:
            logger.error(bstack1l1111l_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡰࡪࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡤࡷࡵࡶࡪࡴࡴࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠣࡨࡦࡺࡡ࠻ࠢࠥ৕") +  str(error))
        return bstack11111111_opy_